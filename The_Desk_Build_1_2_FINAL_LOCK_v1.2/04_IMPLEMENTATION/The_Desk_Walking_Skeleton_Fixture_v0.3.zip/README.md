# The Desk - Frozen Walking-Skeleton Fixture v0.3

**Status:** LOCKED EXECUTABLE CONTRACT  
**Supersedes:** v0.2. v0.1 failed the final implementation-readiness red team; v0.2 closed that review; v0.3 incorporates Supplement S1 and the accepted Operator Repair launch requirement.

This fixture is deliberately fictional. Northbridge FC, Southbank Athletic, the North Coast League, outlets, supporter sources, and all audio hashes are synthetic test data.

## Authority

The active specifications win over this fixture if a contradiction is ever found. A coding agent must not weaken a validator or change a spec to make fixture bytes pass.

Read `ACTIVE_SPECS_LOCKED_v1.1.md` and `The_Desk_Walking_Skeleton_Contract_Trace_v0.2.md` before implementing.

## What changed from v0.1

v0.3 extends the v0.2 rebuild and locks the autonomous-operation/operator-repair contract. v0.2 rebuilt the fixture from the active contracts rather than patching the old JSON:

- spec-correct domain-separated package/brief/script/direction/manifest hashes;
- explicit canonical-serialization contract;
- structured claim values and registry-valid kinds/states;
- four-mode evidence exposure and structural silent-claim withholding;
- two brief-owned program blocks;
- immutable Pass 1 + speech-texture Pass 2 scripts;
- span offsets rather than free-text span identity;
- valid Performance Direction intent vocabulary/shape;
- typed gate definitions/results plus semantic-audit provenance;
- versioned pronunciation with a stale negative vector;
- explicit `speaker_map`;
- spec-correct render request projections and `v1:` base hashes;
- immutable takes, intentional reroll, append-only selection history;
- assembly recipe/map and master-artifact schema;
- prompt-injection and provider-syntax escaping vectors;
- cost-control config;
- executable hash-conformance vectors.

## Hashing

`artifact_hash_conformance.json` and `base_request_hash_conformance.json` contain expected values.

Canonical JSON for this fixture follows Engineering Standards & Security v0.1.1-skeleton:

- NFC strings;
- UTF-8;
- literal non-ASCII, no `\u` escaping;
- Unicode-code-point-sorted object keys;
- no insignificant whitespace;
- no binary floats in hashed projections.

Package identity follows Evidence Package v0.2 §23 exactly.

## Provider-free audio

No real audio bytes are shipped. `render_takes.json` and `audio_artifacts.json` use explicit placeholder audio hashes so schema, take identity, reroll/selection logic, and assembly references can be tested without spending money.

The clean-master record remains `expected_not_materialized`; Build 2 must compute the real master content hash from actual assembled bytes when credentials/audio are used.

## Required implementation behavior

- Validate fixture artifacts against owning spec fields/enums before hashing.
- Recompute every expected hash/fingerprint.
- Run every negative vector for the named reason.
- Do not browse or enrich this fixture.
- Do not substitute live sports facts.
- Do not use v0.1 fixture values as compatibility targets.

## v0.3 launch-operation additions

- versioned launch show configuration, episode-mode registry, block-type registry, and post-event rundown template;
- versioned participant and voice-profile configuration;
- default automatic take approval on technical validation, with human override represented separately;
- no per-render-block human approval queue;
- a single optional whole-episode pre-publish review gate at READY, before REVALIDATED;
- durable suspend/resume on an external review decision, with timeout to halt rather than publish;
- review outcomes `approve`, `request_repair`, and `halt`;
- Operator Repair examples that translate natural-language feedback into a typed repair layer and earliest invalidated stage;
- repair feedback is instruction, never sports evidence, and cannot override claims, rights, sombre policy, or provenance;
- episode repair may nominate systemic improvement but may not silently mutate canonical prompts/policies/character configuration.
