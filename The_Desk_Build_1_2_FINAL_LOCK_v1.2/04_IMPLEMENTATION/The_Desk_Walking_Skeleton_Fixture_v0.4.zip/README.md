# The Desk - Frozen Walking-Skeleton Fixture v0.4

**Status:** ACTIVE EXECUTABLE CONTRACT FOR BUILD 1-2  
**Date:** September 26, 2026  
**Supersedes:** v0.3

This fixture preserves the v0.3 claims/render/review/repair path and adds the launch writing-craft decisions accepted on September 26:

- Showrunner Planning v0.1.3;
- Writing Spec v0.2.2;
- Writing Craft and Invisible Comprehension v0.1;
- Character Bible v0.1.4;
- `post-event-launch-v2` with the wrap clarified as a Tully **closing synthesis**;
- one claim-backed `comprehension_target` with no repetition count;
- an independent Craft Critic result inside SCRIPTED;
- one bounded substantive craft revision before speech texture;
- Simon written as an emotionally present supporter avatar without collective-membership language;
- Gaz written as a listening/processing thinker with dry anti-punchline personality;
- Gaz and Simon treated as warm complementary mates rather than compulsory antagonists;
- negative vectors for Good Thing x50, visible educational signposting, detached/compulsorily argumentative Simon, stat-vending or joke-quota Gaz, critic fact invention, repetition-count controls, formulaic closing synthesis, and fabricated character biography.

The Evidence Package is unchanged from v0.3, so its canonical package hash remains. Its frozen `version_refs.show_version` therefore remains `postmatch-fixture-v2`; v0.4 demonstrates valid downstream-only reuse under the later `postmatch-fixture-v3` show configuration rather than mutating historical package truth:

`8d3a6e82f506f09cb340a7702321e61fdf445f06789fcfc24a07e546b5a10746`

Current canonical hashes:

- brief: `feb3f34c93ffbefaaf59b1caa423e99a54c802c595e776b249068142fcd21042`
- script Pass 1 candidate: `22972b4ba6c3ba8f0e6b8c9e9557b876062c3357fdaef9249f4ca04962575625`
- craft review: `79bd538693d266a1474ade49360c28337466df51f2d112436b19146ad92a949c`
- substantive craft revision: `6987adc6e45b2c728f9c8729cf706e7bb7125ec77db5350ac07dc80f81dd98dc`
- final speech-texture script: `166abe9e8bd96c4e9981b1598641f82db32adca5fac60b8041c632bd23cf6a10`
- Performance Direction: `ad178abd56b689f96d526f8387f7b4da30d62b51ca69dc0be884fc242ac821e8`
- audit input fingerprint: `123ec78091ee2f8158137d20ad80556fb2be45c40d034c144b9cdfb9b2105abb`
- Render Manifest: `f7204ce1e9c112dae5bcc9f34fe5cf533e4c3db40357055a0e77d2e31b9abc1b`

The craft review does **not** add a lifecycle state. It runs within SCRIPTED. The fixture does not require a dedicated craft-review database table; the coding-agent dry run must first attempt to represent the immutable review through existing artifact/model-run provenance and script revision lineage.

No file in this fixture grants live-search authority. External evidence remains untrusted data. The Craft Critic may diagnose writing but may not add sports facts or rewrite the script.
