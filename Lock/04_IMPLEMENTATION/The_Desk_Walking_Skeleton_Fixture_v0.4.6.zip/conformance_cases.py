"""Executable conformance cases for the Fixture v0.4.6 inactive successor candidate (test logic only; NO generator code).

Every case declares its subjects as SELECTORS that the harness resolves uniquely BEFORE the mutation callable runs
(`selectors=` -> `S`). A selector that does not resolve to exactly one subject is a HARNESS failure (SELECTOR_FAILURE), never
evidence that the validator rejected something. Cases mutate an in-memory deep copy of the loaded bundle; no package byte is written.

Part 1: the 158 inherited I2B cases (ids, groups, needles, kinds unchanged; selectors made exact).
"""
import copy

CASES = []
# `V` (the validator module) is injected into this module's globals by the harness before any callable runs.


def case(cid, desc, group, needle, kind='reject', selectors=None, category='inherited_i2b'):
    def deco(fn):
        CASES.append(dict(id=cid, description=desc, group=group, needle=needle, kind=kind, selectors=selectors or {}, category=category, fn=fn))
        return fn
    return deco


def rows(B, t):
    return B['load'][t]


def at_list(lst, i, **expect):
    """list element selector that DECLARES the identity the element must have (raises the validator's SelectorError otherwise)"""
    if not isinstance(lst, list) or not (-len(lst) <= i < len(lst)):
        raise V.SelectorError('list selector [%s] is out of range' % i)
    el = lst[i]
    for k, v in expect.items():
        if not isinstance(el, dict) or el.get(k, object()) != v:
            raise V.SelectorError('list selector [%s] does not have %s=%r' % (i, k, v))
    return el


def both(B, name, fn):
    """mutate a member and its ONE equal artifact payload copy; both subjects are resolved before anything changes"""
    m = V.S_member(B, name)
    copies = [a for a in B['load']['artifacts'] if a['canonical_payload'] == m]
    if len(copies) != 1:
        raise V.SelectorError('member %s has %d equal artifact payload copies (need exactly 1)' % (name, len(copies)))
    fn(copies[0]['canonical_payload'])
    fn(m)


def recompute_ctx(V, B, S, seq, recipe, turn_anchors):
    """consistent attacker: rewrite block context refs, context projection file and digest together"""
    blk, e = S['blk'], S['ctx']
    ts = [V.S_turn(B, a) for a in turn_anchors]            # resolved (uniquely) before any write
    proj = {'recipe_version': recipe, 'turns': [{'semantic_turn_id': t['semantic_turn_id'], 'participant_id': t['participant_id'],
                                                 'spoken_text': t['spoken_text']} for t in ts]}
    dg = V.H(b'render-context-v1\n' + V.cb(proj))
    blk['context_recipe_version'] = recipe
    blk['resolved_context_refs'] = {'context_hash': dg, 'turn_ids': [t['turn_id'] for t in ts]}
    e['context_projection'] = proj
    e['context_hash'] = dg


# ---------------------------------------------------------------- scope framing / types  (G05)
def _sel_ctx(seq):
    return {'blk': ('block', seq), 'ctx': ('ctx', seq)}


@case('S01', 'scope_type changed to "events" (event-set shape is not authorised)', 'G05_package_scope', 'scope schema')
def _(B, V, S):
    both(B, 'evidence_package', lambda p: p['manifest']['scope'].update(scope_type='events'))


@case('S02', 'unrecognized extra scope field', 'G05_package_scope', 'scope schema')
def _(B, V, S):
    both(B, 'evidence_package', lambda p: p['manifest']['scope'].update(time_window='w'))


@case('S03', 'required scope field removed', 'G05_package_scope', 'scope schema')
def _(B, V, S):
    both(B, 'evidence_package', lambda p: p['manifest']['scope'].pop('locale'))


@case('S04', 'entity_ids replaced by a bare string', 'G05_package_scope', 'scope schema')
def _(B, V, S):
    both(B, 'evidence_package', lambda p: p['manifest']['scope'].update(entity_ids='entity_northbridge_fc'))


@case('S05', 'show_id is not a canonical v4 UUID', 'G05_package_scope', 'scope schema')
def _(B, V, S):
    both(B, 'evidence_package', lambda p: p['manifest']['scope'].update(show_id='d1250002-0000-5000-8000-000000000001'))


@case('S06', 'show_id is v4 but does not resolve to the bound show', 'G05_package_scope', 'scope schema')
def _(B, V, S):
    both(B, 'evidence_package', lambda p: p['manifest']['scope'].update(show_id='d1250002-0000-4000-8000-0000000000ff'))


@case('S07', 'blank locale string', 'G05_package_scope', 'scope schema')
def _(B, V, S):
    both(B, 'evidence_package', lambda p: p['manifest']['scope'].update(locale='  '))


@case('S08', 'scope_hash null', 'G05_package_scope', 'scope hash')
def _(B, V, S):
    both(B, 'evidence_package', lambda p: p.update(scope_hash=None))


@case('S09', 'scope_hash computed without the LF after the domain (consistent attacker)', 'G05_package_scope', 'scope hash')
def _(B, V, S):
    sc = B['members']['evidence_package']['manifest']['scope']
    both(B, 'evidence_package', lambda p: p.update(scope_hash=V.H(b'evidence-package-scope-v1' + V.cb(sc))))


@case('S10', 'scope_hash computed with a trailing LF', 'G05_package_scope', 'scope hash')
def _(B, V, S):
    sc = B['members']['evidence_package']['manifest']['scope']
    both(B, 'evidence_package', lambda p: p.update(scope_hash=V.H(b'evidence-package-scope-v1\n' + V.cb(sc) + b'\n')))


@case('S11', 'scope_hash under the package domain', 'G05_package_scope', 'scope hash')
def _(B, V, S):
    sc = B['members']['evidence_package']['manifest']['scope']
    both(B, 'evidence_package', lambda p: p.update(scope_hash=V.DH('evidence-package-v2', sc)))


@case('S12', 'scope_hash wrapped as sha256:<hex>', 'G05_package_scope', 'scope hash')
def _(B, V, S):
    both(B, 'evidence_package', lambda p: p.update(scope_hash='sha256:' + p['scope_hash']))


@case('S13', 'semantic scope change (locale en-US) with a consistently recomputed scope_hash', 'G05_package_scope', 'package')
def _(B, V, S):
    def f(p):
        p['manifest']['scope']['locale'] = 'en-US'
        p['scope_hash'] = V.H(b'evidence-package-scope-v1\n' + V.cb(p['manifest']['scope']))
    both(B, 'evidence_package', f)


@case('S14', 'scope_hash copy in the artifact payload diverges from the member', 'G05_package_scope', 'payload copy',
      selectors={'pkg': ('art', 'd1250005-0000-4000-8000-000000000011')})
def _(B, V, S):
    S['pkg']['canonical_payload']['scope_hash'] = '0' * 64


# ---------------------------------------------------------------- C0 / C2 selection, recipe, words, participant, order (G10)
@case('C01', 'rb01 relabelled C1-v1', 'G10_render_contexts_tts', 'rb01 is not C0', selectors=_sel_ctx(1))
def _(B, V, S):
    recompute_ctx(V, B, S, 1, 'C1-v1', [])


@case('C02', 'rb01 given a context turn (consistent digest)', 'G10_render_contexts_tts', 'rb01 is not C0', selectors=_sel_ctx(1))
def _(B, V, S):
    recompute_ctx(V, B, S, 1, 'C0-v1', ['t17'])


@case('C03', 'rb02 keeps the OLD C1-v1 label on the cross-block reference (consistent digest)', 'G10_render_contexts_tts', 'recipe is not C2-v1', selectors=_sel_ctx(2))
def _(B, V, S):
    recompute_ctx(V, B, S, 2, 'C1-v1', ['t02'])


@case('C04', 'rb04 context is a non-final turn of the previous block (t04 not t05)', 'G10_render_contexts_tts', 'final turn', selectors=_sel_ctx(4))
def _(B, V, S):
    recompute_ctx(V, B, S, 4, 'C2-v1', ['t04'])


@case('C05', 'rb06 context skips a block (t08, two blocks back)', 'G10_render_contexts_tts', 'final turn', selectors=_sel_ctx(6))
def _(B, V, S):
    recompute_ctx(V, B, S, 6, 'C2-v1', ['t08'])


@case('C06', 'rb09 context comes from its own block (C1 usage, t17)', 'G10_render_contexts_tts', 'final turn', selectors=_sel_ctx(9))
def _(B, V, S):
    recompute_ctx(V, B, S, 9, 'C2-v1', ['t17'])


@case('C07', 'rb07 two-turn tail (bound allows exactly one)', 'G10_render_contexts_tts', 'final turn', selectors=_sel_ctx(7))
def _(B, V, S):
    recompute_ctx(V, B, S, 7, 'C2-v1', ['t12', 't13'])


@case('C08', 'rb03 begins at its second turn only', 'G10_render_contexts_tts', 'turns/program block wrong', selectors={'blk': ('block', 3)})
def _(B, V, S):
    b = S['blk']
    b['ordered_turn_ids'] = b['ordered_turn_ids'][1:]
    b['speaker_map'] = b['speaker_map'][1:]


@case('C09', 'context digest computed over a swapped participant', 'G10_render_contexts_tts', 'context digest', selectors=_sel_ctx(3))
def _(B, V, S):
    e = S['ctx']
    e['context_projection']['turns'][0]['participant_id'] = 'simon'
    dg = V.H(b'render-context-v1\n' + V.cb(e['context_projection']))
    e['context_hash'] = dg
    S['blk']['resolved_context_refs']['context_hash'] = dg


@case('C10', 'context digest computed over altered words', 'G10_render_contexts_tts', 'context digest', selectors=_sel_ctx(5))
def _(B, V, S):
    e = S['ctx']
    e['context_projection']['turns'][0]['spoken_text'] += '!'
    dg = V.H(b'render-context-v1\n' + V.cb(e['context_projection']))
    e['context_hash'] = dg
    S['blk']['resolved_context_refs']['context_hash'] = dg


@case('C11', 'context digest stale after the block context changed', 'G10_render_contexts_tts', 'context digest', selectors={'blk': ('block', 8)})
def _(B, V, S):
    S['blk']['resolved_context_refs']['context_hash'] = '0' * 64


@case('C12', 'context digest hashed with storage UUIDs included', 'G10_render_contexts_tts', 'context digest', selectors=_sel_ctx(2))
def _(B, V, S):
    b = S['blk']
    proj = S['ctx']['context_projection']
    proj = {'recipe_version': proj['recipe_version'], 'turns': [dict(t, turn_id=b['resolved_context_refs']['turn_ids'][0]) for t in proj['turns']]}
    b['resolved_context_refs']['context_hash'] = V.H(b'render-context-v1\n' + V.cb(proj))


@case('C13', 'context digest under the wrong domain', 'G10_render_contexts_tts', 'context digest', selectors=_sel_ctx(2))
def _(B, V, S):
    S['blk']['resolved_context_refs']['context_hash'] = V.DH('render-manifest-v1', S['ctx']['context_projection'])


@case('C14', 'C0 empty-context digest left null', 'G10_render_contexts_tts', 'context digest', selectors={'blk': ('block', 1)})
def _(B, V, S):
    S['blk']['resolved_context_refs']['context_hash'] = None


@case('C15', 'two-way context order swap in the stored projection', 'G10_render_contexts_tts', 'context digest', selectors={'ctx': ('ctx', 4)})
def _(B, V, S):
    e = S['ctx']
    e['context_projection']['turns'] = list(reversed(e['context_projection']['turns'])) + [dict(e['context_projection']['turns'][0])]


@case('C16', 'render block spans two program blocks (t05 with t06)', 'G10_render_contexts_tts', 'turns/program block wrong',
      selectors={'blk': ('block', 3), 't6': ('turn', 't06', 'script_pass2')})
def _(B, V, S):
    b = S['blk']
    b['ordered_turn_ids'] = b['ordered_turn_ids'] + [S['t6']['turn_id']]


# ---------------------------------------------------------------- direction: enum, ownership, lineage, fingerprints (G08)
PACE_INTENT_ID = '0eabc30c-9a85-4e7a-86b0-036bba4bd1b2'


def _ints(B):
    return B['members']['performance_direction__successor']['performance_intents']


def _pace(B):
    return at_list([i for i in _ints(B) if i['performance_intent_id'] == PACE_INTENT_ID], 0, intent_type='pace')


def _direction_rehash(V, B, S):
    """consistent attacker: recompute direction_hash for the mutated corrected direction"""
    new = B['members']['performance_direction__successor']
    s = B['src']['script_pass2']
    amap = {t['turn_id']: t['semantic_turn_id'] for t in s['turns']}
    h = V.DH('performance-direction-v1', V._dir_proj(new['script_hash'], new['direction_spec_version'], new['performance_intents'], amap))
    both(B, 'performance_direction__successor', lambda p: p.update(direction_hash=h))
    S['dirart']['content_hash'] = h


SUCC_DIR_ART_ID = 'feb55d72-6b70-4857-9b4b-d99f4e0dfc91'
SUCC_DIR_VERSION_ID = '815f80aa-d9ca-4ddd-9e65-41b46bf5e138'
NEW_INTENT0_ID = '153c0fc0-98dd-4819-b7dc-87c7c9fb3942'


def _sel_succ_dir():
    return {'dirart': ('art', SUCC_DIR_ART_ID)}


@case('D01', 'active pace value reverted to the invalid "measured" (consistent direction hash)', 'G08_correction_direction', 'closed vocabulary',
      selectors=dict(_sel_succ_dir(), pace_row=('row', 'performance_intents', {'performance_intent_id': PACE_INTENT_ID})))
def _(B, V, S):
    both(B, 'performance_direction__successor', lambda p: [i.update(value='measured') for i in p['performance_intents'] if i['performance_intent_id'] == PACE_INTENT_ID])
    S['pace_row']['intent']['value'] = 'measured'
    _direction_rehash(V, B, S)


@case('D02', 'active pace value replaced by another unknown enum ("fast")', 'G08_correction_direction', 'closed vocabulary', selectors=_sel_succ_dir())
def _(B, V, S):
    both(B, 'performance_direction__successor', lambda p: [i.update(value='fast') for i in p['performance_intents'] if i['performance_intent_id'] == PACE_INTENT_ID])
    _direction_rehash(V, B, S)


@case('D03', 'an unrelated intent (t02 dry -> warm) altered with consistent hash', 'G08_correction_direction', 'other than the bounded pace change', selectors=_sel_succ_dir())
def _(B, V, S):
    at_list(_ints(B), 1, intent_type='delivery_affect', value='dry')
    both(B, 'performance_direction__successor', lambda p: p['performance_intents'][1].update(value='warm'))
    _direction_rehash(V, B, S)


@case('D04', 'intent strength changed', 'G08_correction_direction', 'other than the bounded pace change', selectors=_sel_succ_dir())
def _(B, V, S):
    at_list(_ints(B), 0, intent_type='energy_intensity', value='heightened')
    both(B, 'performance_direction__successor', lambda p: p['performance_intents'][0].update(strength='strong'))
    _direction_rehash(V, B, S)


@case('D05', 'corrected direction bound to a different script hash', 'G08_correction_direction', 'corrected direction hash')
def _(B, V, S):
    both(B, 'performance_direction__successor', lambda p: p.update(script_hash=V.source_chain(B)['script_pass1']))


@case('D06', 'corrected direction version bound to the pass-1 script version', 'G08_correction_direction', 'not bound to the final script',
      selectors={'dv': ('row', 'performance_direction_versions', {'performance_direction_version_id': SUCC_DIR_VERSION_ID})})
def _(B, V, S):
    S['dv'].update(script_version_id='68f67af6-73bd-4f20-9d50-fb32ee732728')


@case('D07', 'new intent row reparented to the historical direction version', 'G08_correction_direction', 'intent ownership',
      selectors={'pi': ('row', 'performance_intents', {'performance_intent_id': NEW_INTENT0_ID})})
def _(B, V, S):
    S['pi']['performance_direction_version_id'] = 'd1250016-0000-4000-8000-000000000001'


@case('D08', 'historical intent value silently corrected (history mutated in the archive of the historical direction rows)', 'G15_archive_historical', 'differs from preserved source')
def _(B, V, S):
    hits = [r for r in B['hist'] if r['family'] == 'performance_intents' and r['source_id'] == 'd1250017-0000-4000-8000-000000000006']
    if len(hits) != 1:
        raise V.SelectorError('historical pace intent archive row does not resolve uniquely')
    hits[0]['source_row']['intent']['value'] = 'slower'


@case('D09', 'historical direction gets a fabricated non-null producer fingerprint', 'G08_correction_direction', 'historical direction nested null')
def _(B, V, S):
    both(B, 'performance_direction__historical', lambda p: p.update(input_fingerprint='a' * 64))


@case('D10', 'historical disposition marker removed', 'G08_correction_direction', 'historical direction nested null')
def _(B, V, S):
    both(B, 'performance_direction__historical', lambda p: p.pop('input_fingerprint_disposition'))


@case('D11', 'corrected direction input_fingerprint null (blanket-null attempt)', 'G08_correction_direction', 'input_fingerprint')
def _(B, V, S):
    both(B, 'performance_direction__successor', lambda p: p.update(input_fingerprint=None))


@case('D12', 'corrected input_fingerprint substituted by the performance gate fingerprint', 'G08_correction_direction', 'input_fingerprint')
def _(B, V, S):
    fp = V.stage_projections(B, V.source_chain(B))[0]['performance']
    both(B, 'performance_direction__successor', lambda p: p.update(input_fingerprint=V.DH(fp[0], fp[1])))


@case('D13', 'correction sidecar bytes altered (trailing newline)', 'G08_correction_direction', 'input_fingerprint')
def _(B, V, S):
    B['corr_bytes'] = B['corr_bytes'] + b'\n'


@case('D14', 'correction projection with a sixth key (direction hash) - cycle', 'G08_correction_direction', 'five top-level keys')
def _(B, V, S):
    import json
    p = json.loads(B['corr_bytes'].decode())
    p['corrected_direction_hash'] = B['members']['performance_direction__successor']['direction_hash']
    B['corr_bytes'] = V.cb(p)


@case('D15', 'correction projection expected_value changed', 'G08_correction_direction', 'correction operation content')
def _(B, V, S):
    import json
    p = json.loads(B['corr_bytes'].decode())
    p['correction']['expected_value'] = 'standard'
    B['corr_bytes'] = V.cb(p)


@case('D16', 'correction projection binds another source direction hash', 'G08_correction_direction', 'source/script binding')
def _(B, V, S):
    import json
    p = json.loads(B['corr_bytes'].decode())
    p['source_direction_hash'] = '1' * 64
    B['corr_bytes'] = V.cb(p)


@case('D17', 'frozen record bytes altered after the fingerprint was computed', 'G02_frozen_record_and_cycles', 'frozen record')
def _(B, V, S):
    B['record'] = B['record'] + b'x'


@case('D18', 'record contains the corrected direction hash (dependency cycle)', 'G02_frozen_record_and_cycles', 'cycle')
def _(B, V, S):
    B['record'] = B['record'] + B['members']['performance_direction__successor']['direction_hash'].encode()


@case('D19', 'record contains a successor UUID allocation', 'G02_frozen_record_and_cycles', 'successor')
def _(B, V, S):
    B['record'] = B['record'] + b' feb55d72-6b70-4857-9b4b-d99f4e0dfc91'


@case('D20', 'record contains the correction sidecar digest', 'G02_frozen_record_and_cycles', 'cycle')
def _(B, V, S):
    B['record'] = B['record'] + V.H(B['corr_bytes']).encode()


@case('D21', 'direction hash recomputed WITH the producer fingerprint inside (fingerprint must be excluded)', 'G08_correction_direction', 'corrected direction hash')
def _(B, V, S):
    new = B['members']['performance_direction__successor']
    h = V.DH('performance-direction-v1', dict(new, performance_intents=new['performance_intents']))
    both(B, 'performance_direction__successor', lambda p: p.update(direction_hash=h))


@case('D22', 'corrected artifact does not supersede the historical artifact', 'G08_correction_direction', 'supersedes lineage', selectors=_sel_succ_dir())
def _(B, V, S):
    S['dirart']['supersedes_artifact_id'] = None


@case('D23', 'corrected artifact supersedes an archived carrier instead', 'G03_plan_counts_fk', 'dangling FK', selectors=_sel_succ_dir())
def _(B, V, S):
    S['dirart']['supersedes_artifact_id'] = 'd1250005-0000-4000-8000-000000000013'   # an archived (replaced) source carrier: not in the successor load


@case('D24', 'inherited producer label presented as a new execution', 'G08_correction_direction', 'inherited producer label')
def _(B, V, S):
    both(B, 'performance_direction__successor', lambda p: p.update(producer_run_id='fixture_direction_manual_v3'))


@case('D25', 'render manifest row bound to the historical direction version', 'G08_correction_direction', 'historical direction referenced',
      selectors={'rm': ('at', 'render_manifests', 0, 'df45e9ca-9166-44d9-85db-9e8c5645805a')})
def _(B, V, S):
    S['rm']['performance_direction_version_id'] = 'd1250016-0000-4000-8000-000000000001'


@case('D26', 'a script word changed in the final script member (ownership/hash chain)', 'G06_brief_writer_scripts', 'script')
def _(B, V, S):
    both(B, 'script_pass2', lambda p: p['turns'][0].update(spoken_text=p['turns'][0]['spoken_text'].replace('small', 'large')))


@case('D27', 'audit input names the historical direction hash', 'G09_audit', 'audit result input')
def _(B, V, S):
    hh = B['members']['performance_direction__historical']['direction_hash']
    both(B, 'semantic_audit_result__successor', lambda p: p['input_projection'].update(performance_direction_hash=hh))


# ---------------------------------------------------------------- audit (G09)
@case('A01', 'audit result claims fail without findings', 'G09_audit', 'audit result')
def _(B, V, S):
    both(B, 'semantic_audit_result__successor', lambda p: p.update(result='fail'))


@case('A02', 'prior audit fingerprint copied onto the new result', 'G09_audit', 'audit result')
def _(B, V, S):
    both(B, 'semantic_audit_result__successor', lambda p: p.update(input_fingerprint='0' * 64))


@case('A03', 'audit report claims a human override', 'G09_audit', 'human override')
def _(B, V, S):
    B['audit_report']['human_override'] = {'reviewer': 'Mike', 'decision': 'override'}


@case('A04', 'audit_runs row without the shared result carrier', 'G09_audit', 'audit_runs',
      selectors={'ar': ('at', 'audit_runs', 1, '086597f1-76f6-4ce2-9720-9a1615ab6a83')})
def _(B, V, S):
    S['ar']['result_artifact_id'] = None


@case('A05', 'audit report omits method and limitations', 'G09_audit', 'method')
def _(B, V, S):
    B['audit_report']['limitations'] = []


@case('A06', 'audit_runs reuses a source audit id', 'G09_audit', 'reuses a source id',
      selectors={'ar': ('at', 'audit_runs', 0, '20d87118-3576-4b14-8169-61a166bf8ff8')})
def _(B, V, S):
    S['ar']['audit_run_id'] = 'd1250018-0000-4000-8000-000000000001'   # the accepted source audit run id (archived; every audit row is fresh)


# ---------------------------------------------------------------- requests / audio / mapping (G10-G12)
MAP = [(0, '89623913-16e4-4476-9a41-9064531de896'), (2, 'fe0f051e-8f55-4c24-b6ae-e54ff1c3ca26'), (3, '8f91c8a2-b737-43c6-81a1-a020b483399a'),
       (5, '53745adf-5b66-4e73-a8c1-0d484f7751e5')]


def _map(B, i, call_id):
    return at_list(B['proj']['fixture_tts_mapping']['entries'], i, provider_call_id=call_id)


@case('R01', 'mapping entry with a wrong WAV sha', 'G12_audio_assembly_mapping', 'mapping does not reconcile')
def _(B, V, S):
    _map(B, 3, '8f91c8a2-b737-43c6-81a1-a020b483399a')['wav_sha256'] = '0' * 64


@case('R02', 'mapping entry for an unknown request (base hash changed)', 'G12_audio_assembly_mapping', 'unknown request')
def _(B, V, S):
    _map(B, 2, 'fe0f051e-8f55-4c24-b6ae-e54ff1c3ca26')['base_request_hash'] = 'v1:' + '0' * 64


@case('R03', 'mapping receipt claims live provider generation', 'G12_audio_assembly_mapping', 'disclaim')
def _(B, V, S):
    _map(B, 0, '89623913-16e4-4476-9a41-9064531de896')['receipt']['live_provider_contacted'] = True


@case('R04', 'mapping relabels the predecessor receipt as new generation', 'G12_audio_assembly_mapping', 'disclaim')
def _(B, V, S):
    _map(B, 5, '53745adf-5b66-4e73-a8c1-0d484f7751e5')['receipt']['predecessor_receipt_relabeled_as_new_generation'] = True


TTS_CALLS = ['89623913-16e4-4476-9a41-9064531de896', 'c2171bf3-1d44-40c9-8396-6921aa42993f', 'fe0f051e-8f55-4c24-b6ae-e54ff1c3ca26',
             '8f91c8a2-b737-43c6-81a1-a020b483399a', '778a9c2b-8f9c-41d7-b28f-ea647d539213', '53745adf-5b66-4e73-a8c1-0d484f7751e5',
             '18024cbd-c455-4cae-a90b-b0a0bd880583', '33528f68-3198-47dc-968e-923fa1896f15', 'f425519d-1c97-40a1-b103-9ffc9e43eeb7',
             '32d92fdd-dc12-47fb-8bab-e2e9c25c2371']


@case('R05', 'provider call fingerprint taken from another block', 'G11_ledger_takes', 'request binding',
      selectors={'c0': ('row', 'provider_calls', {'provider_call_id': TTS_CALLS[0]}), 'c1': ('row', 'provider_calls', {'provider_call_id': TTS_CALLS[1]})})
def _(B, V, S):
    S['c0']['request_fingerprint'] = S['c1']['request_fingerprint']


@case('R06', 'take points at another block\'s audio artifact', 'G12_audio_assembly_mapping', 'mapping does not reconcile',
      selectors={'t0': ('at', 'render_takes', 0, '5765fcec-6881-4f9a-afb3-9214b400f497'), 't1': ('at', 'render_takes', 1, '6cb56ce2-a796-467b-93cb-293847c78bfb')})
def _(B, V, S):
    S['t0']['audio_artifact_id'], S['t1']['audio_artifact_id'] = S['t1']['audio_artifact_id'], S['t0']['audio_artifact_id']


@case('R07', 'WAV bytes mutated (one PCM byte flipped)', 'G12_audio_assembly_mapping', 'WAV bytes/hash')
def _(B, V, S):
    k = 'fixture_audio/rb03_take0.wav'
    if k not in B['wav']:
        raise V.SelectorError('no such WAV member ' + k)
    b = bytearray(B['wav'][k])
    b[-5] ^= 0x01
    B['wav'][k] = bytes(b)


@case('R08', 'rb06 take0 audio substituted with a different frame count claim', 'G12_audio_assembly_mapping', 'frame',
      selectors={'a': ('art', '66666666-6666-4666-8666-000000000106')})
def _(B, V, S):
    S['a']['canonical_payload']['frame_count'] = 6959


@case('R09', 'event response artifact swapped between two TTS calls', 'G12_audio_assembly_mapping', 'mapping',
      selectors={'e0': ('row', 'provider_call_events', {'provider_call_event_id': '460a28a7-abe8-454b-9adb-020bfa878fc2'}),
                 'e1': ('row', 'provider_call_events', {'provider_call_event_id': 'fc749e97-49c3-4ac7-a774-72561e57accd'})})
def _(B, V, S):
    S['e0']['response_artifact_id'], S['e1']['response_artifact_id'] = S['e1']['response_artifact_id'], S['e0']['response_artifact_id']


@case('R10', 'selected PCM plus sting no longer equals the preserved master (master bytes altered)', 'G12_audio_assembly_mapping', 'preserved 57,119-frame master')
def _(B, V, S):
    k = 'fixture_audio/master.wav'
    if k not in B['wav']:
        raise V.SelectorError('no such WAV member ' + k)
    b = bytearray(B['wav'][k])
    b[100] ^= 0x01
    B['wav'][k] = bytes(b)


# ---------------------------------------------------------------- ledger / takes / selections (G11) and inherited negatives
FAIL_TAKE = '8473f24b-4032-45f8-bb9d-af191b8aad5a'
REJ_SEL = 'f4d18414-6e71-41d9-ad9d-5695684e826f'
TRIGGER = '998e0a15-6b0b-48e1-9296-dc74d36b97e9'


@case('L01', 'source TTS reservation co-loaded (duplicate rb01 reservation)', 'G11_ledger_takes', 'source TTS reservation')
def _(B, V, S):
    rows(B, 'provider_calls').append(copy.deepcopy(B['src_tables']['provider_calls'][0]))


@case('L02', 'operational try number 2', 'G11_ledger_takes', 'try 1', selectors={'c': ('at', 'provider_calls', 7, 'fe0f051e-8f55-4c24-b6ae-e54ff1c3ca26')})
def _(B, V, S):
    S['c']['operational_try_number'] = 2


@case('L03', 'non-zero actual cost', 'G11_ledger_takes', 'zero-cost', selectors={'e': ('at', 'provider_call_events', 7, '6e7046c3-2422-4b69-8bdf-d4b3a4565b20')})
def _(B, V, S):
    S['e']['actual_cost'] = '0.0100'


@case('L04', 'provider terminal event duplicated for one call', 'G11_ledger_takes', 'exactly one succeeded',
      selectors={'e5': ('at', 'provider_call_events', 5, '460a28a7-abe8-454b-9adb-020bfa878fc2'), 'e6': ('at', 'provider_call_events', 6, 'fc749e97-49c3-4ac7-a774-72561e57accd')})
def _(B, V, S):
    S['e6']['provider_call_id'] = S['e5']['provider_call_id']


@case('L05', 'terminal failure recorded for the retained rejected take (must remain a provider success)', 'G11_ledger_takes', 'exactly one succeeded',
      selectors={'take': ('row', 'render_takes', {'render_take_id': FAIL_TAKE})})
def _(B, V, S):
    c6 = S['take']['provider_call_id']
    hits = [e for e in rows(B, 'provider_call_events') if e['provider_call_id'] == c6]
    if len(hits) != 1:
        raise V.SelectorError('rejected take provider call has %d events' % len(hits))
    hits[0]['event_type'] = 'terminal_failure'


@case('L06', 'reroll trigger source call points at another call', 'G11_ledger_takes', 'reroll causal chain',
      selectors={'trg': ('row', 'reroll_triggers', {'reroll_trigger_id': TRIGGER}), 'c0': ('row', 'provider_calls', {'provider_call_id': TTS_CALLS[0]})})
def _(B, V, S):
    S['trg']['source_provider_call_id'] = S['c0']['provider_call_id']


@case('L07', 'rejected rb06 selection deleted (approval no longer supersedes a rejection)', 'G11_ledger_takes', 'rejection/approval chain',
      selectors={'rej': ('row', 'take_selections', {'take_selection_id': REJ_SEL})})
def _(B, V, S):
    sels = rows(B, 'take_selections')
    nxt = [s for s in sels if s['supersedes_selection_id'] == REJ_SEL]
    if len(nxt) != 1:
        raise V.SelectorError('rejected selection is superseded by %d selections' % len(nxt))
    sels.remove(S['rej'])
    nxt[0]['supersedes_selection_id'] = None


@case('L08', 'selection points at a take from another block', 'G11_ledger_takes', 'another block',
      selectors={'sel': ('at', 'take_selections', 0, '867002c6-aef4-42c4-8716-c378ea516317'), 'blk': ('at', 'render_blocks', 1, '7dd54595-208d-44cd-9334-00f1e66b855a')})
def _(B, V, S):
    S['sel']['render_block_id'] = S['blk']['render_block_id']


@case('L09', 'rb06 reroll timestamps not causal', 'G11_ledger_takes', 'timestamps', selectors={'trg': ('row', 'reroll_triggers', {'reroll_trigger_id': TRIGGER})})
def _(B, V, S):
    S['trg']['created_at'] = '2026-09-27T13:16:00Z'


@case('L10', 'scenario clock: corrected direction dated before the historical one', 'G11_ledger_takes', 'scenario clock')
def _(B, V, S):
    both(B, 'performance_direction__successor', lambda p: p.update(created_at='2026-09-27T13:06:00Z'))


@case('L11', 'premature/placeholder request fingerprint', 'G11_ledger_takes', 'request binding',
      selectors={'c': ('row', 'provider_calls', {'provider_call_id': TTS_CALLS[3]})})
def _(B, V, S):
    S['c']['request_fingerprint'] = 'v1:' + '0' * 64


@case('L12', 'take with the same provider call as another take (unique violation)', 'G11_ledger_takes', 'unique provider calls',
      selectors={'t0': ('at', 'render_takes', 0, '5765fcec-6881-4f9a-afb3-9214b400f497'), 't1': ('at', 'render_takes', 1, '6cb56ce2-a796-467b-93cb-293847c78bfb')})
def _(B, V, S):
    S['t1']['provider_call_id'] = S['t0']['provider_call_id']


# ---------------------------------------------------------------- assembly / gates / READY (G12, G13)
GATE_FIRST = {'performance': '6b450c9b-e33a-45ae-bc6f-b4fa67f7e5b4', 'render': '1e3576eb-f9e4-4bc8-b499-29e8a1865a0c',
              'assembly': '76af5cc9-fd75-41d2-a931-843b147873bd', 'claims_writing': '7a1dc802-2f7d-4590-950e-2b429274f594'}


def _seg(B, i, **exp):
    return at_list(B['members']['master_assembly_map__successor']['segments'], i, **exp)


@case('M01', 'segment end frame off by one', 'G12_audio_assembly_mapping', 'segment')
def _(B, V, S):
    at_list(B['members']['master_assembly_map__successor']['segments'], 4, kind='speech')
    both(B, 'master_assembly_map__successor', lambda p: p['segments'][4].update(end_frame=p['segments'][4]['end_frame'] + 1))


@case('M02', 'assembly recipe hash altered', 'G12_audio_assembly_mapping', 'recipe hash')
def _(B, V, S):
    both(B, 'assembly_recipe', lambda p: p.update(assembly_recipe_hash='0' * 64))


@case('M03', 'map segment references a superseded (archived) block id', 'G12_audio_assembly_mapping', 'segment')
def _(B, V, S):
    at_list(B['members']['master_assembly_map__successor']['segments'], 0, kind='speech')
    both(B, 'master_assembly_map__successor', lambda p: p['segments'][0].update(render_block_id='d1250020-0000-4000-8000-000000000001'))


@case('M04', 'map segment carries the rejected rb06 take instead of take1', 'G12_audio_assembly_mapping', 'segment',
      selectors={'rej': ('row', 'take_selections', {'take_selection_id': REJ_SEL})})
def _(B, V, S):
    rej = S['rej']
    if len([sg for sg in B['members']['master_assembly_map__successor']['segments'] if sg['render_block_id'] == rej['render_block_id']]) != 1:
        raise V.SelectorError('the rejected selection block has not exactly one segment')
    both(B, 'master_assembly_map__successor', lambda p: [sg.update(take_selection_id=rej['take_selection_id'], render_take_id=rej['render_take_id'])
                                                        for sg in p['segments'] if sg['render_block_id'] == rej['render_block_id']])


@case('M05', 'performance gate fingerprint still uses the historical direction hash', 'G13_gates_ready', 'gate row fingerprint',
      selectors={'g': ('row', 'gate_results', {'gate_result_id': GATE_FIRST['performance']})})
def _(B, V, S):
    hh = B['members']['performance_direction__historical']['direction_hash']
    R = V.source_chain(B)
    stale = V.DH('performance-gate-input-v1', {'script_hash': R['script_pass2'], 'performance_direction_hash': hh,
                                               'performance_policy_version': 'performance-render-0.1.4', 'gate_set_version': V.GATE_SET})
    S['g']['input_fingerprint'] = stale


@case('M06', 'a superseded gate row id is co-loaded', 'G13_gates_ready', 'replaced gate row co-loaded',
      selectors={'g': ('row', 'gate_results', {'gate_result_id': GATE_FIRST['render']})})
def _(B, V, S):
    S['g']['gate_result_id'] = 'd125001a-0000-4000-8000-000000000026'   # an accepted source gate row id (archived; every gate row is fresh)


@case('M07', 'a replacement gate row dropped (61 rows)', 'G13_gates_ready', 'gate rows not 62',
      selectors={'g': ('row', 'gate_results', {'gate_result_id': GATE_FIRST['assembly']})})
def _(B, V, S):
    rows(B, 'gate_results').remove(S['g'])


@case('M08', 'READY expectations carry another candidate fingerprint', 'G13_gates_ready', 'READY expectations')
def _(B, V, S):
    B['members']['ready_expectations']['ready_candidate_fingerprint'] = '0' * 64


@case('M09', 'revalidation result bound to another READY candidate', 'G13_gates_ready', 'revalidation')
def _(B, V, S):
    both(B, 'revalidation_result__successor', lambda p: p.update(ready_candidate_fingerprint='0' * 64))


@case('M10', 'a claims/writing gate row keeps its accepted source id (every gate row owns a fresh attempt)', 'G13_gates_ready', 'source gate row id was retained',
      selectors={'g': ('row', 'gate_results', {'gate_result_id': GATE_FIRST['claims_writing']})})
def _(B, V, S):
    S['g']['gate_result_id'] = 'd125001a-0000-4000-8000-000000000001'


@case('M11', 'render gate binds the previous (archived) manifest hash', 'G13_gates_ready', 'gate row fingerprint',
      selectors={'g': ('row', 'gate_results', {'gate_result_id': GATE_FIRST['render']})})
def _(B, V, S):
    R = V.source_chain(B)
    st, _ = V.stage_projections(B, R)
    p = dict(st['render'][1])
    p['render_manifest_hash'] = 'f' * 64
    S['g']['input_fingerprint'] = V.DH(st['render'][0], p)


@case('M12', 'attempt state forged READY', 'G11_ledger_takes', 'PENDING',
      selectors={'at': ('at', 'program_run_attempts', 0, 'e5aaee76-ec19-4917-b293-24a0435b3a92')})
def _(B, V, S):
    S['at']['state'] = 'READY'


# ---------------------------------------------------------------- inherited I2A structural negatives (ported)
@case('I01', 'turn PK with a non-v4 version nibble', 'G03_plan_counts_fk', 'noncanonical v4 PK',
      selectors={'t': ('at', 'turns', 0, 'ceb16263-a004-49d2-a9be-41d9eda49b92')})
def _(B, V, S):
    S['t']['turn_id'] = 'd1250013-0000-5000-8000-000000000001'


@case('I02', 'duplicate turn PK', 'G03_plan_counts_fk', 'duplicate PK',
      selectors={'t0': ('at', 'turns', 0, 'ceb16263-a004-49d2-a9be-41d9eda49b92'), 't1': ('at', 'turns', 1, '0d9b2ac0-7b33-4a4a-938d-9760a963967b')})
def _(B, V, S):
    S['t1']['turn_id'] = S['t0']['turn_id']


@case('I03', 'turn_evidence_uses points at a claim id', 'G03_plan_counts_fk', 'dangling FK',
      selectors={'u': ('at', 'turn_evidence_uses', 0, 'ede03027-94fb-4566-a0fd-46425324f3c2'), 'c': ('at', 'claims', 0, 'd1250008-0000-4000-8000-000000000001')})
def _(B, V, S):
    S['u']['evidence_unit_id'] = S['c']['claim_id']


@case('I04', 'artifact removed', 'G03_plan_counts_fk', 'family count mismatch')
def _(B, V, S):
    rows(B, 'artifacts').pop()


@case('I05', 'runtime Episode family seeded', 'G03_plan_counts_fk', 'family set')
def _(B, V, S):
    B['load']['episodes'] = []


@case('I06', 'claim initial status contested', 'G04_knowledge_hashes', 'claim initial status',
      selectors={'c': ('at', 'claims', 0, 'd1250008-0000-4000-8000-000000000001')})
def _(B, V, S):
    S['c']['initial_status'] = 'contested'


@case('I07', 'base claim event inserted', 'G04_knowledge_hashes', 'base claim events')
def _(B, V, S):
    rows(B, 'claim_state_events').append({'claim_state_event_id': 'd1250025-0000-4000-8000-000000000009'})


@case('I08', 'non-null base state cursor in the package', 'G04_knowledge_hashes', 'non-null base cursor')
def _(B, V, S):
    at_list(B['members']['evidence_package']['manifest']['claims'], 0, claim_id='d1250008-0000-4000-8000-000000000001')['state_event_cursor'] = {
        'claim_state_event_id': 'd1250025-0000-4000-8000-000000000001', 'event_sequence': 1}


@case('I09', 'support rows with swapped target kinds', 'G04_knowledge_hashes', 'target kind',
      selectors={'d': ('row', 'claim_supports', {'claim_support_id': 'd125000a-0000-4000-8000-000000000007'}),
                 'e': ('at', 'claim_supports', 0, 'd125000a-0000-4000-8000-000000000001')})
def _(B, V, S):
    S['d']['support_kind'] = 'evidence'
    S['e']['support_kind'] = 'derivation'


@case('I10', 'rights version does not cover the evidence source', 'G04_knowledge_hashes', 'rights version')
def _(B, V, S):
    for rv in rows(B, 'rights_versions'):   # declared subject: EVERY rights version
        rv['policy']['covered_source_identities'] = []


@case('I11', 'prompt manifest paired with another manifest\'s artifact', 'G07_prompts_models', 'pairing',
      selectors={'p0': ('at', 'prompt_manifests', 0, 'd125000b-0000-4000-8000-000000000001'), 'p1': ('at', 'prompt_manifests', 1, '98ea20bd-ab0c-4292-9fda-6db5df9b326e')})
def _(B, V, S):
    S['p0']['artifact_id'] = S['p1']['artifact_id']


@case('I12', 'pronunciation application span no longer matches the entity text', 'G10_render_contexts_tts', 'projection failed')
def _(B, V, S):
    a = at_list(B['src']['pronunciations']['resolved_applications'], 0, semantic_turn_id='t03')
    a['span_start'] += 1
    a['span_end'] += 1


@case('I13', 'audio row id substituted where an artifact id is required', 'G03_plan_counts_fk', 'dangling FK',
      selectors={'t': ('at', 'render_takes', 0, '5765fcec-6881-4f9a-afb3-9214b400f497'), 'a': ('at', 'audio_artifacts', 0, '88888888-8888-4888-8888-000000000001')})
def _(B, V, S):
    S['t']['audio_artifact_id'] = S['a']['audio_artifact_id']


@case('I14', 'isolated repair child forged READY', 'G16_scenarios_gap', 'not PENDING')
def _(B, V, S):
    S_ = B['members']['scenarios']['scenarios']['performance_repair']['rows']['program_run_attempts']
    at_list(S_, 0, state='PENDING')['state'] = 'READY'


@case('I15', 'isolated usage-change event sequence zero', 'G16_scenarios_gap', 'event sequence')
def _(B, V, S):
    at_list(B['members']['scenarios']['scenarios']['usage_change']['rows']['claim_state_events'], 0, event_sequence=1)['event_sequence'] = 0


@case('I16', 'isolated scenario still targets the archived manifest artifact', 'G16_scenarios_gap', 'superseded id')
def _(B, V, S):
    rp = B['members']['scenarios']['scenarios']['performance_repair']['rows']['repair_plans']
    at_list(rp, 0)['typed_plan']['affected_artifact_refs'].append('d1250005-0000-4000-8000-000000000014')   # the accepted source manifest artifact id (archived)


@case('I17', 'archive-only source row co-loaded', 'G03_plan_counts_fk', 'archive-only source row co-loaded')
def _(B, V, S):
    rows(B, 'take_selections').append(copy.deepcopy(B['src_tables']['take_selections'][0]))


@case('I18', 'load is short a fresh row (405)', 'G03_plan_counts_fk', 'family count mismatch')
def _(B, V, S):
    rows(B, 'render_blocks').pop()


# ---------------------------------------------------------------- predecessor negative vectors applicable offline
@case('N01', 'NV01 wrong claim value: "43 percent" -> "48 percent" in the spoken span (final script t04)', 'G06_brief_writer_scripts', 'claim value not supported',
      selectors={'t': ('row', 'turns', {'turn_id': '67bb27be-e82e-4290-8e77-656d2a55cfd3'})})
def _(B, V, S):
    t = S['t']
    if '43 percent' not in t['spoken_text']:
        raise V.SelectorError('declared turn does not contain the 43 percent value')
    t['spoken_text'] = t['spoken_text'].replace('43 percent', '48 percent')


@case('N02', 'NV02 silent leak: market probability spoken in a turn', 'G06_brief_writer_scripts', 'silent value leaked',
      selectors={'t': ('at', 'turns', -1, 'd45d42b2-0a89-4beb-a3f4-5ac62f63d19c')})
def _(B, V, S):
    S['t']['spoken_text'] += ' The market has Northbridge at 58 percent.'


@case('N03', 'NV04 stale pronunciation: v1 rendering applied where v2 is current', 'G10_render_contexts_tts', 'base request hash')
def _(B, V, S):
    hits = [a for a in B['src']['pronunciations']['resolved_applications'] if a['pronunciation_rendering_id'] == 'd125001e-0000-4000-8000-000000000002']
    if not hits:
        raise V.SelectorError('no application of the current rendering')
    a = hits[0]
    a['pronunciation_rendering_id'] = 'd125001e-0000-4000-8000-000000000001'
    a['pronunciation_id'] = 'd125001d-0000-4000-8000-000000000001'


@case('N04', 'NV07 diff-lock: score changed 2-1 to 3-1 in the final script member', 'G06_brief_writer_scripts', 'script')
def _(B, V, S):
    both(B, 'script_pass2', lambda p: [t.update(spoken_text=t['spoken_text'].replace('2-1', '3-1')) for t in p['turns']])


@case('N05', 'NV15 timestamp stability (STABLE): package created_at/frozen_at change leaves package hash', 'G05_package_scope', '', 'stable',
      selectors={'pkg': ('art', 'd1250005-0000-4000-8000-000000000011')})
def _(B, V, S):
    B['members']['evidence_package']['created_at'] = '2031-01-01T00:00:00Z'
    S['pkg']['canonical_payload']['created_at'] = '2031-01-01T00:00:00Z'


@case('N06', 'NV10 non-render metadata (STABLE): QA note on a voice version does not change any base hash', 'G10_render_contexts_tts', '', 'stable')
def _(B, V, S):
    v = at_list(B['src']['voice_profiles']['voice_profile_versions'], 0, voice_profile_version_id='d125001c-0000-4000-8000-000000000001')
    v['qa_note'] = 'sounds fine'
    v['admin_label'] = 'v1-final'


@case('N07', 'block state label change (STABLE): excluded from the manifest hash', 'G10_render_contexts_tts', '', 'stable',
      selectors={'rm': ('art', 'd95e48e4-a47d-444c-9f59-f858e5482c7c')})
def _(B, V, S):
    for b in B['members']['render_manifest__successor']['render_blocks']:
        b['state'] = 'synthesized'
    S['rm']['canonical_payload'] = B['members']['render_manifest__successor']


@case('N08', 'NV11 voice version change: render field must change the base identity (bundle cannot keep the old hash)', 'G10_render_contexts_tts', 'base request hash')
def _(B, V, S):
    v = at_list(B['src']['voice_profiles']['voice_profile_versions'], 1)
    v['render_fields']['request_side_voice_controls'] = {'stability': 'low'}


@case('N09', 'NV12 context text change on rb03 source turn changes rb03 (and only dependents)', 'G10_render_contexts_tts', 'base request hash',
      selectors={'t': ('turn', 't03', 'script_pass2')})
def _(B, V, S):
    S['t']['spoken_text'] += ' Really.'


@case('N10', 'adapter version bump would change rb01 (bundle keeps v2; bump to v3 must not validate)', 'G10_render_contexts_tts', 'adapter contract version bumped')
def _(B, V, S):
    B['members']['render_manifest__successor']['adapter_contract_version'] = 'fixture-adapter-contract-v3'


# ---------------------------------------------------------------- additional cases for the reconstruction counts / bindings
@case('E01', 'a hedged claim reclassified assertable (usage class census)', 'G04_knowledge_hashes', 'usage classes',
      selectors={'c': ('row', 'claims', {'claim_id': 'd1250008-0000-4000-8000-000000000004'})})
def _(B, V, S):
    if S['c']['initial_usage_class'] != 'hedged_only':
        raise V.SelectorError('declared claim is not the hedged claim')
    S['c']['initial_usage_class'] = 'assertable'


@case('E02', 'a rights version removed', 'G04_knowledge_hashes', 'counts are not 16/7/9/1/9')
def _(B, V, S):
    rows(B, 'rights_versions').pop()


@case('E03', 'a signal support edge recast as evidence kind', 'G04_knowledge_hashes', 'support edges',
      selectors={'s': ('row', 'claim_supports', {'claim_support_id': 'd125000a-0000-4000-8000-000000000005'})})
def _(B, V, S):
    if S['s']['support_kind'] != 'signal':
        raise V.SelectorError('declared support is not the signal support')
    S['s']['support_kind'] = 'evidence'


@case('E04', 'craft revision bound to a different Brief hash', 'G06_brief_writer_scripts', 'exact Brief/package')
def _(B, V, S):
    both(B, 'script_craft_revision', lambda p: p.update(brief_hash='0' * 64))


@case('E05', 'script package binding removed from the final script', 'G06_brief_writer_scripts', 'exact Brief/package')
def _(B, V, S):
    both(B, 'script_pass2', lambda p: p.update(package_hash='1' * 64))


@case('E06', 'parent content identity of the craft revision points at itself', 'G06_brief_writer_scripts', 'parent content identity')
def _(B, V, S):
    h = B['members']['script_craft_revision']['script_hash']
    both(B, 'script_craft_revision', lambda p: p.update(revision_parent_content_identity=h))


@case('E07', 'retained synthetic revalidation snapshot dropped from the load', 'G13_gates_ready', 'snapshot',
      selectors={'a': ('art', 'd1250005-0000-4000-8000-000000000022')})
def _(B, V, S):
    rows(B, 'artifacts').remove(S['a'])


@case('E08', 'master map audio row points at a different underlying artifact', 'G12_audio_assembly_mapping', 'typed id',
      selectors={'m': ('at', 'audio_artifacts', 11, '88888888-8888-4888-8888-000000000012'), 'a0': ('at', 'audio_artifacts', 0, '88888888-8888-4888-8888-000000000001')})
def _(B, V, S):
    S['m']['artifact_id'] = S['a0']['artifact_id']


@case('E09', 'authored WAV copy differs from the predecessor member (replaced with sting bytes)', 'G12_audio_assembly_mapping', 'byte-identical to the predecessor')
def _(B, V, S):
    for k in ('fixture_audio/rb02_take0.wav', 'fixture_audio/sting.wav'):
        if k not in B['wav']:
            raise V.SelectorError('no such WAV member ' + k)
    B['wav']['fixture_audio/rb02_take0.wav'] = B['wav']['fixture_audio/sting.wav']


@case('K01', 'orphaned audit-result carrier (no audit_runs consumer)', 'G18_artifact_consumers', 'orphan artifact')
def _(B, V, S):
    for r in rows(B, 'audit_runs'):   # declared subject: both audit_runs rows
        r['result_artifact_id'] = 'd1250005-0000-4000-8000-000000000011'


@case('K02', 'orphaned mechanical-validation carrier (trigger points elsewhere)', 'G18_artifact_consumers', 'orphan artifact',
      selectors={'trg': ('row', 'reroll_triggers', {'reroll_trigger_id': TRIGGER})})
def _(B, V, S):
    S['trg']['validation_artifact_id'] = 'd1250005-0000-4000-8000-000000000011'


@case('K03', 'captured writer data bytes altered', 'G06_brief_writer_scripts', 'captured writer data bytes')
def _(B, V, S):
    B['writer_bytes'] = B['writer_bytes'] + b'\n'


@case('K04', 'captured scope projection bytes carry a trailing LF', 'G05_package_scope', 'captured scope projection bytes')
def _(B, V, S):
    B['scope_bytes'] = B['scope_bytes'] + b'\n'


@case('K05', 'captured model semantic projection has a fourth field', 'G07_prompts_models', 'three-field model semantic projection')
def _(B, V, S):
    at_list(B['proj']['model_semantic_inputs']['inputs'], 0)['projection']['provider'] = 'fixture_stub'


@case('T01', 'family totals row altered (render_takes loaded 9)', 'G19_identity_totals_provenance', 'family totals row wrong')
def _(B, V, S):
    t = B['totals']
    hits = [r for r in t['families'] if r['family'] == 'render_takes']
    if len(hits) != 1:
        raise V.SelectorError('family totals row render_takes does not resolve uniquely')
    hits[0]['successor_loaded_rows'] = 9


@case('T02', 'identity registry loses a fresh row', 'G19_identity_totals_provenance', 'identity registry differs')
def _(B, V, S):
    if 'gate_results' not in B['registry']['families']:
        raise V.SelectorError('identity registry has no gate_results family')
    B['registry']['families']['gate_results']['rows'].pop()


@case('T03', 'provenance binds a different correction fingerprint', 'G19_identity_totals_provenance', 'provenance bindings')
def _(B, V, S):
    B['provenance']['bindings']['correction_input_fingerprint'] = '0' * 64


@case('T04', 'provenance presents the inherited producer label as freshly executed', 'G19_identity_totals_provenance', 'inherited label as executed')
def _(B, V, S):
    B['provenance']['inherited_producer_labels']['statement'] = 'executed again'


@case('T05', 'provenance attributes technical approval to Mike', 'G19_identity_totals_provenance', 'misattributes authorship')
def _(B, V, S):
    B['provenance']['technical_adjudicator'] = 'Mike approved the technical particulars'


@case('T06', 'observed times out of dependency order (freeze after the build)', 'G19_identity_totals_provenance', 'dependency order')
def _(B, V, S):
    B['provenance']['observed_times_utc']['resolution_record_frozen'] = '2099-01-01T00:00:00Z'


@case('D28', 'pre-execution verification output altered after the record cited its hash', 'G02_frozen_record_and_cycles', 'pre-execution verification output')
def _(B, V, S):
    B['preexec'] = B['preexec'] + b' '


@case('I19', 'pronunciation application bound to another speaker\'s voice version (ported I2A negative)', 'G10_render_contexts_tts', 'wrong speaker voice')
def _(B, V, S):
    at_list(B['src']['pronunciations']['resolved_applications'], 0, semantic_turn_id='t03')['voice_profile_version_id'] = 'd125001c-0000-4000-8000-000000000003'


@case('I20', 'rendering derives from a stale canonical version (v1 rendering with a v2 application)', 'G10_render_contexts_tts', 'does not derive from the applied canonical')
def _(B, V, S):
    at_list(B['src']['pronunciations']['resolved_applications'], 0, semantic_turn_id='t03')['pronunciation_id'] = 'd125001d-0000-4000-8000-000000000001'


# ---------------------------------------------------------------- R1 regression: captured request specimens must declare bytes available
PM = [('d1250005-0000-4000-8000-000000000006', 'showrunner_planner', 'prompt_manifest_1'),
      ('b72b67e0-74f8-4d7e-8eb9-1d5af1306c03', 'writer', 'prompt_manifest_2'),
      ('269abc64-c317-4a07-87e6-fccd526172c0', 'craft_critic', 'prompt_manifest_3'),
      ('91004b76-0072-4168-a8b0-ad98ddffd8c0', 'writer_revision', 'prompt_manifest_4'),
      ('04782410-3bbc-4609-8c13-ceda193e415a', 'speech_texture', 'prompt_manifest_5')]


def _avail(aid, label, mode):
    def fn(B, V, S):
        a = S['a']
        pl = a['canonical_payload']
        if mode == 'false':
            pl['retention']['request_bytes_available'] = False
        else:
            pl['retention'].pop('request_bytes_available')
        B['members'][label] = copy.deepcopy(pl)                          # member copy stays equal
        a['content_hash'] = V.DH('prompt-manifest-artifact-v1', pl)      # complete artifact hash consistently recomputed
    return fn


for _i, (_aid, _purpose, _label) in enumerate(PM):
    case('V%02d' % (2 * _i + 1), '%s manifest: request_bytes_available declared false although the captured specimen exists (member/artifact copies equal, hash recomputed)' % _purpose,
         'G07_prompts_models', 'retention availability must be true', selectors={'a': ('art', _aid)})(_avail(_aid, _label, 'false'))
    case('V%02d' % (2 * _i + 2), '%s manifest: request_bytes_available declaration missing (member/artifact copies equal, hash recomputed)' % _purpose,
         'G07_prompts_models', 'retention availability must be true', selectors={'a': ('art', _aid)})(_avail(_aid, _label, 'missing'))


# ====================================================================== Part 2: cases ADDED in I2C (category 'added_domain')
# Complete-manifest acceptance negatives use a CONSISTENT ATTACKER: member copy, artifact payload copy, container entry and the complete
# artifact hash are all rewritten together, so a stale-hash check cannot be the only defence.
import json

G25 = 'G25_complete_manifest_acceptance'
PLANNER, WRITER, CRITIC, REVISION, SPEECH = ('d1250005-0000-4000-8000-000000000006', 'b72b67e0-74f8-4d7e-8eb9-1d5af1306c03', '269abc64-c317-4a07-87e6-fccd526172c0', '91004b76-0072-4168-a8b0-ad98ddffd8c0', '04782410-3bbc-4609-8c13-ceda193e415a')   # planner retained; the other four are the CONFIG-330 fresh manifest artifacts
LABEL = {PLANNER: 'prompt_manifest_1', WRITER: 'prompt_manifest_2', CRITIC: 'prompt_manifest_3', REVISION: 'prompt_manifest_4', SPEECH: 'prompt_manifest_5'}
ROW = {PLANNER: 'd125000b-0000-4000-8000-000000000001', WRITER: '98ea20bd-ab0c-4292-9fda-6db5df9b326e', CRITIC: '7edb5876-57b5-4f87-a2d8-e46d0a4c593c',
       REVISION: 'dc665598-5290-4bd8-970d-1d7108c32835', SPEECH: 'ee178d53-43d1-4a17-96b9-ab6d9e350860'}
BRIEF, PASS1 = '595870e7-1b3c-4abc-a794-fc864e0c95b2', '6a1d7871-b770-42ee-9adb-8023e9148db8'
WRITER_RUN = 'b95b015c-e69f-4b02-8b6f-038d55b320dc'
EV_LORE = 'd1250007-0000-4000-8000-000000000009'
EV_ANALYSIS = 'd1250007-0000-4000-8000-000000000004'


def _dumpb(o):
    return (json.dumps(o, indent=2, sort_keys=True, ensure_ascii=False) + '\n').encode('utf-8')


def _sel_ma(aid):
    return {'a': ('art', aid), 'row': ('row', 'prompt_manifests', {'prompt_manifest_id': ROW[aid]}),
            'ev': ('row', 'evidence_units', {'evidence_unit_id': EV_LORE})}


def attack(B, S, aid, fn, typed=()):
    """consistent attacker for one complete manifest: payload, member copy, container entry and artifact hash rewritten together"""
    a = S['a']
    pl = a['canonical_payload']
    fn(pl)
    B['members'][LABEL[aid]] = copy.deepcopy(pl)
    a['content_hash'] = V.DH('prompt-manifest-artifact-v1', pl)
    for k in typed:
        S['row'][k] = copy.deepcopy(pl[k])
    cont = json.loads(B['pack'].data['prompt_payloads.json'].decode('utf-8'))
    hits = [e for e in cont['manifests'] if e['artifact_id'] == aid]
    if len(hits) != 1:
        raise V.SelectorError('container entry for %s is not unique' % aid)
    hits[0]['canonical_payload'] = copy.deepcopy(pl)
    B['pack'].data['prompt_payloads.json'] = _dumpb(cont)


def excerpt(S):
    words = S['ev']['canonical_content'].split()
    if len(words) < 9:
        raise V.SelectorError('declared evidence body is too short to excerpt (%d words)' % len(words))
    return ' '.join(words[:9])


def ma(cid, desc, needle, fn, aid=WRITER, typed=(), group=G25):
    case(cid, desc, group, needle, selectors=_sel_ma(aid), category='added_domain')(lambda B, V_, S: attack(B, S, aid, lambda pl: fn(pl, S, B), typed))


# ---- valid-fixture ACCEPTANCE negatives: missing retention, rights-bearing excerpts, hidden output provenance, invalid declarations (all rehashed consistently)
ma('MA01', 'complete manifest without its retention object (every copy and hash rewritten consistently)', '16-field', lambda pl, S, B: pl.pop('retention'))
ma('MA02', 'retention declaration lacks raw_output_retention_policy', 'retention declaration is missing or incomplete', lambda pl, S, B: pl['retention'].pop('raw_output_retention_policy'))
ma('MA03', 'retention.request_bytes_available declared false although the exact specimen is shipped', 'disagrees with the actual captured specimen',
   lambda pl, S, B: pl['retention'].update(request_bytes_available=False))
ma('MA04', 'retention.request_bytes_available encoded as the string "true"', 'not a JSON boolean', lambda pl, S, B: pl['retention'].update(request_bytes_available='true'))
ma('MA05', 'rights-bearing source excerpt copied into exposure_instructions.instructions', 'rights-bearing source excerpt',
   lambda pl, S, B: pl['exposure_instructions'].update(instructions=pl['exposure_instructions']['instructions'] + ' ' + excerpt(S)))
ma('MA06', 'rights-bearing source excerpt copied into non_source_text', 'rights-bearing source excerpt',
   lambda pl, S, B: pl['non_source_text'][0].update(text=pl['non_source_text'][0]['text'] + ' ' + excerpt(S)))
ma('MA07', 'rights-bearing source excerpt copied into settings', 'rights-bearing source excerpt', lambda pl, S, B: pl['settings'].update(note=excerpt(S)))
ma('MA08', 'rights-bearing source excerpt copied into retention text', 'rights-bearing source excerpt',
   lambda pl, S, B: pl['retention'].update(request_byte_retention=pl['retention']['request_byte_retention'] + ' ' + excerpt(S)))
ma('MA10', 'hidden output provenance: output_artifact_id key inside settings', 'output provenance keys', lambda pl, S, B: pl['settings'].update(output_artifact_id=PASS1))
ma('MA11', 'hidden output provenance: fixture_model_provenance key inside settings', 'output provenance keys', lambda pl, S, B: pl['settings'].update(fixture_model_provenance={'x': 1}))
ma('MA12', 'hidden output provenance: the model output artifact id appears as text', 'leaks output artifact id',
   lambda pl, S, B: pl['exposure_instructions'].update(instructions=pl['exposure_instructions']['instructions'] + ' output ' + PASS1))
ma('MA13', 'hidden provenance: the manifest names its own artifact id', 'leaks own artifact id',
   lambda pl, S, B: pl['settings'].update(note='self ' + WRITER))
ma('MA14', 'hidden provenance: the model run id appears in non_source_text', 'leaks model run id',
   lambda pl, S, B: pl['non_source_text'][0].update(text=pl['non_source_text'][0]['text'] + ' ' + WRITER_RUN))
ma('MA15', 'a 17th top-level field (hidden provenance tail)', '16-field', lambda pl, S, B: pl.update(fixture_model_provenance={'note': 'hidden'}))
ma('MA16', 'a required top-level field missing (settings) - 15 fields', '16-field', lambda pl, S, B: pl.pop('settings'))
ma('MA17', 'schema_version is not prompt-manifest/1', 'schema_version is not', lambda pl, S, B: pl.update(schema_version='prompt-manifest/2'))
ma('MA18', 'ordered inputs include the manifest\'s own model output (script pass 1)', 'own artifact, its own output or a later output',
   lambda pl, S, B: pl['ordered_input_artifacts'].append({'artifact_id': PASS1, 'artifact_type': 'script_pass1', 'content_hash': [a for a in B['load']['artifacts'] if a['artifact_id'] == PASS1][0]['content_hash']}))
ma('MA19', 'ordered input content_hash is stale', 'differ from the durable artifact', lambda pl, S, B: pl['ordered_input_artifacts'][0].update(content_hash='0' * 64))
ma('MA20', 'ordered inputs reordered relative to the exact request specimen', 'differ from the exact request specimen',
   lambda pl, S, B: pl['ordered_input_artifacts'].reverse())
ma('MA21', 'an ordered input artifact id does not resolve', 'does not resolve', lambda pl, S, B: pl['ordered_input_artifacts'][0].update(artifact_id='d1250005-0000-4000-8000-0000000000ff'))
ma('MA22', 'exposure instructions belong to another consumer', 'belong to another consumer', lambda pl, S, B: pl['exposure_instructions'].update(consumer='craft_critic'))
ma('MA23', 'exposure instructions lack the profile version', 'incomplete', lambda pl, S, B: pl['exposure_instructions'].pop('profile_version'))
ma('MA24', 'manifest purpose changed to another role (output type no longer matches)', 'does not match the manifest purpose', lambda pl, S, B: pl.update(purpose='craft_critic'))
ma('MA25', 'manifest provider differs from the model run', 'provider/model_identifier disagree', lambda pl, S, B: pl.update(provider='live_provider'))
ma('MA26', 'component_versions changed in the complete payload only (typed row untouched)', 'typed three-field reconciliation failed on component_versions',
   lambda pl, S, B: pl['component_versions'].update(fixture_prompt='writer-fixture-v2'))
ma('MA27', 'policy_source_hashes changed in the complete payload only', 'typed three-field reconciliation failed on policy_source_hashes',
   lambda pl, S, B: pl['policy_source_hashes'].update(claims_policy='0' * 64))
ma('MA28', 'rendered_request_hash changed in the complete payload only', 'typed three-field reconciliation failed on rendered_request_hash',
   lambda pl, S, B: pl.update(rendered_request_hash='0' * 64))
ma('MA34', 'ordered_input_evidence entry has the wrong shape', 'ordered input evidence entry has the wrong shape', lambda pl, S, B: pl['ordered_input_evidence'].append({'evidence_unit_id': EV_LORE}))
ma('MA35', 'ordered_input_claims entry does not resolve to a durable claim', 'does not resolve to its durable claim',
   lambda pl, S, B: pl['ordered_input_claims'].append({'claim_id': 'd1250008-0000-4000-8000-0000000000ff', 'claim_content_hash': '0' * 64, 'frozen_state_hash': '1' * 64, 'package_hash': '2' * 64}))
ma('MA36', 'non_source_text entry lacks its role', 'non_source_text is not an ordered list', lambda pl, S, B: pl['non_source_text'][0].pop('role'))
ma('MA37', 'settings is not an object', 'settings is not an object', lambda pl, S, B: pl.update(settings=[]))
ma('MA38', 'rendered_request_ref carries an extra key', 'exact three-field reference', lambda pl, S, B: pl['rendered_request_ref'].update(url='https://example.invalid/req'))


@case('MA09', 'rights-bearing source excerpt inside the retained request specimen', G25, 'rights-bearing source excerpt', category='added_domain', selectors={'ev': ('row', 'evidence_units', {'evidence_unit_id': EV_LORE})})
def _(B, V_, S):
    hits = [r for r in B['requests']['requests'] if r['specimen_key'] == 'writer']
    if len(hits) != 1:
        raise V.SelectorError('writer specimen does not resolve uniquely')
    hits[0]['rendered_request'] = hits[0]['rendered_request'] + ' ' + excerpt(S)


@case('MA29', 'one manifest artifact bound by two prompt rows (unique FK violated)', G25, 'not five distinct', category='added_domain',
      selectors={'p0': ('row', 'prompt_manifests', {'prompt_manifest_id': ROW[PLANNER]}), 'p1': ('row', 'prompt_manifests', {'prompt_manifest_id': ROW[WRITER]})})
def _(B, V_, S):
    S['p0']['artifact_id'] = S['p1']['artifact_id']


@case('MA30', 'a prompt row bound to a model OUTPUT artifact instead of a manifest artifact', G25, 'types are not prompt_manifest', category='added_domain',
      selectors={'p1': ('row', 'prompt_manifests', {'prompt_manifest_id': ROW[WRITER]})})
def _(B, V_, S):
    S['p1']['artifact_id'] = BRIEF


@case('MA31', 'a prompt row whose complete-manifest artifact is missing', G25, 'a prompt manifest artifact is missing', category='added_domain',
      selectors={'p1': ('row', 'prompt_manifests', {'prompt_manifest_id': ROW[WRITER]})})
def _(B, V_, S):
    S['p1']['artifact_id'] = 'd1250005-0000-4000-8000-0000000000ff'


@case('MA32', 'hidden request provenance carried by a model OUTPUT artifact (retention key in the Brief)', G25, 'hidden request provenance keys', category='added_domain',
      selectors={'brief': ('art', BRIEF)})
def _(B, V_, S):
    S['brief']['canonical_payload']['retention'] = {'request_bytes_available': True}


@case('MA33', 'two manifests share one template_version (not purpose-specific)', G25, 'template_version is not purpose-specific', category='added_domain',
      selectors={'pl': ('art', PLANNER), 'wr': ('art', WRITER)})
def _(B, V_, S):
    S['pl']['canonical_payload']['template_version'] = S['wr']['canonical_payload']['template_version']


# ---- G23 reference resolution / G22 layout (domain-level; ZIP-level negatives are in part 3)
G23 = 'G23_reference_resolution'


@case('RF01', 'artifact storage_uri points at a member that is not in the pack', G23, 'dangling storage_uri', category='added_domain',
      selectors={'a': ('art', '595870e7-1b3c-4abc-a794-fc864e0c95b2')})
def _(B, V_, S):
    S['a']['storage_uri'] = 'showrunner_brief_missing.json'


@case('RF02', 'rendered_request_ref.member points at a member that is not in the pack (copies/hash rewritten consistently)', G23, 'rendered_request_ref.member is not a member', category='added_domain',
      selectors=_sel_ma(WRITER))
def _(B, V_, S):
    attack(B, S, WRITER, lambda pl: pl['rendered_request_ref'].update(member='fixture_model_requests_v2.json'))


@case('RF03', 'rendered_request_ref.specimen_key names no specimen (copies/hash rewritten consistently)', G23, 'resolves to 0 specimens', category='added_domain',
      selectors=_sel_ma(WRITER))
def _(B, V_, S):
    attack(B, S, WRITER, lambda pl: pl['rendered_request_ref'].update(specimen_key='writer_two'))


@case('RF04', 'duplicate specimen_key in the request specimen member', G23, 'duplicate specimen_key', category='added_domain')
def _(B, V_, S):
    rq = B['requests']['requests']
    if len(rq) != 5:
        raise V.SelectorError('specimen member does not hold five specimens')
    B['pack'].data[V.PATH['requests']] = _dumpb(dict(B['requests'], requests=rq + [dict(rq[0])]))
    B['requests'] = json.loads(B['pack'].data[V.PATH['requests']].decode('utf-8'))


@case('RF05', 'a shared container holds two entries for one artifact id', G23, 'duplicate artifact_id entry', category='added_domain')
def _(B, V_, S):
    cont = json.loads(B['pack'].data['support_payloads.json'].decode('utf-8'))
    cont['artifacts'].append(copy.deepcopy(cont['artifacts'][0]))
    B['pack'].data['support_payloads.json'] = _dumpb(cont)


@case('RF06', 'ARTIFACT_INVENTORY row altered', G23, 'ARTIFACT_INVENTORY.json differs', category='added_domain')
def _(B, V_, S):
    B['artifact_inventory']['artifacts'][0]['storage_uri'] = 'elsewhere.json'


@case('RF07', 'an artifact storage_uri names an archival member', G23, 'archival/provenance member', category='added_domain',
      selectors={'a': ('art', '595870e7-1b3c-4abc-a794-fc864e0c95b2')})
def _(B, V_, S):
    S['a']['storage_uri'] = 'archive/ARCHIVE_ONLY_85.json'


@case('RF08', 'inventory referenced_by disagrees with the real references', G23, 'referenced_by differs', category='added_domain')
def _(B, V_, S):
    m = [x for x in B['pack_members']['members'] if x['path'] == 'showrunner_brief.json']
    if len(m) != 1:
        raise V.SelectorError('inventory entry showrunner_brief.json is not unique')
    m[0]['referenced_by'] = []


@case('RF09', 'audio artifact byte_size disagrees with the shipped WAV bytes', G23, 'audio member bytes disagree', category='added_domain',
      selectors={'a': ('art', '66666666-6666-4666-8666-000000000103')})
def _(B, V_, S):
    S['a']['byte_size'] += 1


# ---- G24 prospective policy / authority binding
G24 = 'G24_policy_authority_binding'


@case('PL01', 'policy source_sha256 altered', G24, 'does not match the shipped authority bytes', category='added_domain')
def _(B, V_, S):
    B['policy']['policies']['claims_policy']['source_sha256'] = '0' * 64


@case('PL02', 'authority source bytes altered (hash left as pinned)', G24, 'does not match the shipped authority bytes', category='added_domain')
def _(B, V_, S):
    k = B['policy']['policies']['claims_policy']['shipped_at']
    if k not in B['pack'].data:
        raise V.SelectorError('authority member not shipped: ' + k)
    B['pack'].data[k] = B['pack'].data[k] + b'\n'


@case('PL03', 'policy map silently retains the obsolete active claims version', G24, 'obsolete active-profile binding', category='added_domain')
def _(B, V_, S):
    B['policy']['policies']['claims_policy']['version_id'] = 'claims-0.1.1'


@case('PL04', 'policy map no longer declares itself prospective', G24, 'prospective', category='added_domain')
def _(B, V_, S):
    B['policy']['status'] = 'ACTIVE'


@case('PL05', 'a policy missing from the map', G24, 'ten expected policies', category='added_domain')
def _(B, V_, S):
    del B['policy']['policies']['hashing_contract']


@case('PL06', 'prompt manifest binds a policy hash that is not the source bytes (typed row and payload rewritten together)', G24, 'does not bind the exact source bytes', category='added_domain',
      selectors=_sel_ma(WRITER))
def _(B, V_, S):
    attack(B, S, WRITER, lambda pl: pl['policy_source_hashes'].update(writing_policy='0' * 64), typed=('policy_source_hashes',))


@case('PL07', 'prompt manifest binds an obsolete component version (typed row and payload rewritten together)', G24, 'is not the policy map version', category='added_domain',
      selectors=_sel_ma(WRITER))
def _(B, V_, S):
    attack(B, S, WRITER, lambda pl: pl['component_versions'].update(writing_policy='writing-0.2.2'), typed=('component_versions',))


@case('PL08', 'audit input names an obsolete performance policy version', G24, 'not the prospective policy version', category='added_domain')
def _(B, V_, S):
    B['members']['semantic_audit_result__successor']['input_projection']['performance_policy_version'] = 'performance-render-0.1.3'


# ---- G26 / G27 / G28: the vector machinery itself (tampered vectors must be reported; broken selectors are harness failures)
@case('VC01', 'manifest vector baseline hash altered', 'G26_manifest_hash_vectors', 'baseline', category='added_domain')
def _(B, V_, S):
    B['v_manifest']['baseline']['complete_hash'] = '0' * 64


@case('VC02', 'a manifest vector\'s recorded complete hash altered', 'G26_manifest_hash_vectors', 'complete hash: expected', category='added_domain')
def _(B, V_, S):
    v = [x for x in B['v_manifest']['vectors'] if x['id'] == 'PM-L01']
    if len(v) != 1:
        raise V.SelectorError('vector PM-L01 is not unique')
    v[0]['expect']['complete_hash'] = '0' * 64


@case('VC03', 'a manifest vector whose selector path does not exist', 'G26_manifest_hash_vectors', 'SELECTOR FAILURE in manifest vector', category='added_domain')
def _(B, V_, S):
    v = [x for x in B['v_manifest']['vectors'] if x['id'] == 'PM-L01']
    if len(v) != 1:
        raise V.SelectorError('vector PM-L01 is not unique')
    v[0]['mutations'][0]['path'] = '/retention/no_such_field'


@case('VC04', 'an envelope vector naming an envelope field that does not exist', 'G26_manifest_hash_vectors', 'SELECTOR FAILURE in envelope vector', category='added_domain')
def _(B, V_, S):
    B['v_manifest']['envelope_vectors'][0]['change'] = {'no_such_envelope_field': 1}


@case('VC05', 'a manifest vector claims an unchanged hash for a mutation that changes it', 'G26_manifest_hash_vectors', 'complete hash: expected same', category='added_domain')
def _(B, V_, S):
    v = [x for x in B['v_manifest']['vectors'] if x['id'] == 'PM-L01']
    if len(v) != 1:
        raise V.SelectorError('vector PM-L01 is not unique')
    v[0]['expect']['complete'] = 'same'


@case('TV01', 'a TTS vector\'s recorded hash altered', 'G27_tts_request_vectors', 'TTS vector', category='added_domain')
def _(B, V_, S):
    v = [x for x in B['v_base_request']['vectors'] if x['id'] == 'P24-3']
    if len(v) != 1:
        raise V.SelectorError('vector P24-3 is not unique')
    v[0]['expect']['hash'] = 'v1:' + '0' * 64


@case('TV02', 'a TTS vector whose selector path does not exist', 'G27_tts_request_vectors', 'SELECTOR FAILURE in TTS vector', category='added_domain')
def _(B, V_, S):
    v = [x for x in B['v_base_request']['vectors'] if x['id'] == 'P24-3']
    if len(v) != 1:
        raise V.SelectorError('vector P24-3 is not unique')
    v[0]['mutations'][0]['path'] = '/turns/9/spoken_text'


@case('TV03', 'the closed mapping loses the entry for a real block', 'G27_tts_request_vectors', 'has no frozen mapping entry', category='added_domain')
def _(B, V_, S):
    ents = B['proj']['fixture_tts_mapping']['entries']
    at_list(ents, 2, provider_call_id='fe0f051e-8f55-4c24-b6ae-e54ff1c3ca26')
    del ents[2]


@case('TV04', 'an actual block record no longer reproduces its stored projection', 'G27_tts_request_vectors', 'select_projection does not reproduce', category='added_domain')
def _(B, V_, S):
    blk = at_list(B['v_base_request']['actual_blocks'], 2, render_block_sequence=3)
    blk['input_record']['turns'][0]['spoken_text'] += ' extra'


@case('TV05', 'an ownership vector expects the wrong rejection code', 'G27_tts_request_vectors', 'rejected with', category='added_domain')
def _(B, V_, S):
    v = [x for x in B['v_base_request']['vectors'] if x['id'] == 'OW001']
    if len(v) != 1:
        raise V.SelectorError('vector OW001 is not unique')
    v[0]['expect']['error'] = 'context_from_own_block'


@case('TV06', 'a known-request vector whose mapping names a WAV that is not shipped', 'G27_tts_request_vectors', 'mapping entry names a missing WAV', category='added_domain')
def _(B, V_, S):
    ents = B['proj']['fixture_tts_mapping']['entries']
    at_list(ents, 2, provider_call_id='fe0f051e-8f55-4c24-b6ae-e54ff1c3ca26')['wav_member_path'] = 'fixture_audio/not_shipped.wav'


@case('TV07', 'a stability vector that actually changes the hash is reported', 'G27_tts_request_vectors', 'TTS vector ST', category='added_domain')
def _(B, V_, S):
    v = [x for x in B['v_base_request']['vectors'] if x['id'] == 'ST001']
    if len(v) != 1:
        raise V.SelectorError('vector ST001 is not unique')
    v[0]['mutations'] = [{'op': 'set', 'path': '/turns/0/spoken_text', 'value': B['v_base_request']['baseline']['input_record']['turns'][0]['spoken_text'] + '!'}]


@case('CE01', 'a base claim state event is inserted (base must have zero events)', 'G28_claim_event_vectors', 'base load contains claim state events', category='added_domain')
def _(B, V_, S):
    B['load']['claim_state_events'].append({'claim_state_event_id': 'd1250025-0000-4000-8000-000000000009'})


@case('CE02', 'a base package claim carries a non-null cursor', 'G28_claim_event_vectors', 'nine null cursors', category='added_domain')
def _(B, V_, S):
    at_list(B['members']['evidence_package']['manifest']['claims'], 0, claim_id='d1250008-0000-4000-8000-000000000001')['state_event_cursor'] = {
        'claim_state_event_id': 'd1250025-0000-4000-8000-000000000001', 'event_sequence': 1}


@case('CE03', 'a claim vector\'s expected reduction altered', 'G28_claim_event_vectors', 'claim vector CE-R01 step 1', category='added_domain')
def _(B, V_, S):
    v = [x for x in B['v_claims']['vectors'] if x['id'] == 'CE-R01']
    if len(v) != 1:
        raise V.SelectorError('vector CE-R01 is not unique')
    v[0]['steps'][0]['expect']['state'] = 'contested'


@case('CE04', 'isolated usage-change scenario event at sequence 2 (must start at 1)', 'G28_claim_event_vectors', 'isolated usage-change scenario', category='added_domain')
def _(B, V_, S):
    at_list(B['members']['scenarios']['scenarios']['usage_change']['rows']['claim_state_events'], 0, event_sequence=1)['event_sequence'] = 2


@case('CE05', 'a claim vector with an unknown step operation', 'G28_claim_event_vectors', 'SELECTOR FAILURE in claim vector', category='added_domain')
def _(B, V_, S):
    v = [x for x in B['v_claims']['vectors'] if x['id'] == 'CE-R01']
    if len(v) != 1:
        raise V.SelectorError('vector CE-R01 is not unique')
    v[0]['steps'][0]['op'] = 'teleport'


@case('CE06', 'a claim vector expecting an accepted append where the append must be rejected', 'G28_claim_event_vectors', 'claim vector CE-A03 step 1', category='added_domain')
def _(B, V_, S):
    v = [x for x in B['v_claims']['vectors'] if x['id'] == 'CE-A03']
    if len(v) != 1:
        raise V.SelectorError('vector CE-A03 is not unique')
    v[0]['steps'][0]['expect'] = 'ok:appended'


# ---- G29: support roles, five-match window, tenor, continuity, Brief targets
G29 = 'G29_support_window_continuity'


@case('SR01', 'a support role outside the closed five-value vocabulary', G29, 'closed five-value vocabulary', category='added_domain',
      selectors={'s': ('row', 'claim_supports', {'claim_support_id': 'd125000a-0000-4000-8000-000000000002'})})
def _(B, V_, S):
    S['s']['support_role'] = 'supports_everything'


@case('SR02', 'package support snapshot role differs from the durable support row', G29, 'package support snapshot differs', category='added_domain')
def _(B, V_, S):
    c = at_list(B['members']['evidence_package']['manifest']['claims'], 1, claim_id='d1250008-0000-4000-8000-000000000002')
    at_list(c['support_refs'], 0, claim_support_id='d125000a-0000-4000-8000-000000000002')['support_role'] = 'context_only'


@case('SR03', 'a claim whose only support is context_only (cannot establish a value)', G29, 'no supports_value support', category='added_domain',
      selectors={'s': ('row', 'claim_supports', {'claim_support_id': 'd125000a-0000-4000-8000-000000000002'})})
def _(B, V_, S):
    S['s']['support_role'] = 'context_only'


@case('MW01', 'the selected window gains a sixth prior match', G29, 'selected five-match window', category='added_domain')
def _(B, V_, S):
    B['members']['evidence_package']['manifest']['selection_provenance']['match_window_proof']['selected_event_identities'].append('event_fixture_previous_6')


@case('MW02', 'prior schedule entries swapped (not strictly descending)', G29, 'strictly descending', category='added_domain')
def _(B, V_, S):
    sch = B['members']['evidence_package']['manifest']['selection_provenance']['match_window_proof']['ordered_prior_schedule']
    at_list(sch, 0, event_identity='event_fixture_previous_1')
    at_list(sch, 1, event_identity='event_fixture_previous_2')
    sch[0], sch[1] = sch[1], sch[0]


@case('MW03', 'a derivation input names an event outside the selected window', G29, 'derivation input provenance disagrees', category='added_domain')
def _(B, V_, S):
    at_list(B['load']['derivation_runs'][0]['exact_input_refs'], 0)['selected_provenance']['event_identity'] = 'event_fixture_previous_6'


@case('MW04', 'derivation parameters changed (after_minute 80 -> 75)', G29, 'derivation parameters', category='added_domain')
def _(B, V_, S):
    B['load']['derivation_runs'][0]['parameters']['after_minute'] = 75


@case('CT01', 'continuity carrier marked withdrawn', G29, 'withdrawn', category='added_domain', selectors={'a': ('art', 'd1250005-0000-4000-8000-000000000018')})
def _(B, V_, S):
    S['a']['canonical_payload']['projection']['withdrawn'] = True


@case('CT02', 'continuity publication attestation not in the published state', G29, 'withdrawn or lacks a published synthetic attestation', category='added_domain',
      selectors={'a': ('art', 'd1250005-0000-4000-8000-000000000018')})
def _(B, V_, S):
    S['a']['canonical_payload']['projection']['publication_attestation']['state'] = 'draft'


@case('CT03', 'package continuity entry names another topic thread', G29, 'package continuity entry does not match', category='added_domain')
def _(B, V_, S):
    at_list(B['members']['evidence_package']['manifest']['continuity'], 0, withdrawn=False)['topic_thread_id'] = 'thr_other'


@case('TT01', 'tenor observation count disagrees with its observations', G29, 'tenor observation count/order', category='added_domain', selectors={'a': ('art', 'd1250005-0000-4000-8000-000000000017')})
def _(B, V_, S):
    S['a']['canonical_payload']['projection']['observation_count'] = 5


@case('TT02', 'tenor observation names a different source than its evidence row', G29, 'tenor observation does not match its evidence row', category='added_domain',
      selectors={'a': ('art', 'd1250005-0000-4000-8000-000000000017')})
def _(B, V_, S):
    at_list(S['a']['canonical_payload']['projection']['observations'], 0)['source_identity'] = 'src_other'


@case('NV20', 'predecessor NV20: a desired_reinforcement repetition-count field on a comprehension target', G29, 'repetition-count/density field', category='added_domain')
def _(B, V_, S):
    B['members']['showrunner_brief']['comprehension_targets'][0]['desired_reinforcement'] = 3


# ---- G30: exact decimal / frame timing
G30 = 'G30_exact_timing'


def _aud(aid):
    return {'a': ('art', aid), 'r': ('row', 'audio_artifacts', {'artifact_id': aid})}


@case('DT01', 'declared duration_seconds is not frame_count/sample_rate rounded to its precision', G30, 'rounded to', category='added_domain', selectors=_aud('66666666-6666-4666-8666-000000000101'))
def _(B, V_, S):
    S['a']['canonical_payload']['duration_seconds'] = '0.106'


@case('DT02', 'audio row duration_ms disagrees with floor(seconds*1000+0.5)', G30, 'audio row duration_ms', category='added_domain', selectors=_aud('66666666-6666-4666-8666-000000000107'))
def _(B, V_, S):
    S['r']['duration_ms'] = 144


@case('DT03', 'duration_seconds in exponent notation', G30, 'not nonnegative decimal text', category='added_domain', selectors=_aud('66666666-6666-4666-8666-000000000101'))
def _(B, V_, S):
    S['a']['canonical_payload']['duration_seconds'] = '1.05e-1'


@case('DT04', 'negative duration_seconds', G30, 'not nonnegative decimal text', category='added_domain', selectors=_aud('66666666-6666-4666-8666-000000000102'))
def _(B, V_, S):
    S['a']['canonical_payload']['duration_seconds'] = '-0.11'


@case('DT05', 'frame_count changed without the declared decimal', G30, 'rounded to', category='added_domain', selectors=_aud('66666666-6666-4666-8666-000000000112'))
def _(B, V_, S):
    S['a']['canonical_payload']['frame_count'] = 57120


@case('DT06', 'master map segment frames no longer contiguous', G30, 'not contiguous positive integers', category='added_domain')
def _(B, V_, S):
    sg = at_list(B['members']['master_assembly_map__successor']['segments'], 3, kind='speech')
    sg['start_frame'] += 1


@case('DT07', 'rb06 take1 decimal rounded the wrong way (0.144980 instead of 0.144979)', G30, 'rounded to', category='added_domain', selectors=_aud('66666666-6666-4666-8666-000000000107'))
def _(B, V_, S):
    S['a']['canonical_payload']['duration_seconds'] = '0.144980'


# ---- remaining existing-contract negatives that had no direct case
@case('ED01', 'equal-body scenario evidence reuses an existing evidence UUID (equal body must keep a DIFFERENT identity)', 'G04_knowledge_hashes', 'equal-body scenario evidence hash/identity', category='added_domain')
def _(B, V_, S):
    rows_ = B['members']['scenarios']['scenarios']['equal_body_distinct_identity']['rows']['evidence_units']
    at_list(rows_, 0)['evidence_unit_id'] = 'd1250007-0000-4000-8000-000000000001'


@case('ED02', 'equal-body scenario evidence hash no longer equals the shared body hash', 'G04_knowledge_hashes', 'equal-body scenario evidence hash/identity', category='added_domain')
def _(B, V_, S):
    rows_ = B['members']['scenarios']['scenarios']['equal_body_distinct_identity']['rows']['evidence_units']
    at_list(rows_, 0)['content_hash'] = '0' * 64


@case('TR01', 'a revision turn row removed (50 distinct turn ids)', 'G06_brief_writer_scripts', 'turn ids not 51 distinct', category='added_domain',
      selectors={'t': ('at', 'turns', 10, 'ef1fda6a-314a-49f0-aaca-c90d5f0e494e')})
def _(B, V_, S):
    B['load']['turns'].remove(S['t'])


@case('PC01', 'a voice version no longer lists the concrete model as compatible (projection identity changes)', 'G10_render_contexts_tts', 'base request hash', category='added_domain')
def _(B, V_, S):
    v = at_list(B['src']['voice_profiles']['voice_profile_versions'], 0, voice_profile_version_id='d125001c-0000-4000-8000-000000000001')
    v['render_fields']['provider_model_compatibility'] = ['fixture-model-0.9']


@case('PC02', 'pronunciation rendering provider differs from the voice provider (projection identity changes)', 'G10_render_contexts_tts', 'base request hash', category='added_domain')
def _(B, V_, S):
    r = at_list(B['src']['pronunciations']['pronunciation_renderings'], 1, pronunciation_rendering_id='d125001e-0000-4000-8000-000000000002')
    r['provider'] = 'fixture_tts_b'


@case('GT01', 'a gate row references the wrong fingerprint stage value', 'G13_gates_ready', 'gate row fingerprint', category='added_domain',
      selectors={'g': ('row', 'gate_results', {'gate_result_id': GATE_FIRST['assembly']})})
def _(B, V_, S):
    S['g']['input_fingerprint'] = '0' * 64


@case('RD01', 'READY candidate binds a different master audio hash (assembly gate unaffected)', 'G13_gates_ready', 'READY expectations', category='added_domain')
def _(B, V_, S):
    B['members']['ready_expectations']['query_parameters']['3'] = '0' * 64


# ---- unresolved required hashes must fail; the approved historical null and the runtime-bound scenario nulls are the ONLY classified nulls
G14 = 'G14_obligations_nulls'


@case('UH01', 'a pending placeholder marker left in a required hash field of the load', G14, 'unresolved pending marker remains', category='added_domain',
      selectors={'a': ('art', '595870e7-1b3c-4abc-a794-fc864e0c95b2')})
def _(B, V_, S):
    S['a']['content_hash'] = 'pending_I2B'


@case('UH02', 'a child script version without its revision-parent content identity', G14, 'child script lacks parent content identity', category='added_domain',
      selectors={'sv': ('row', 'script_versions', {'script_version_id': 'a0773e27-df66-4010-9870-20609db6b740'})})
def _(B, V_, S):
    S['sv']['revision_parent_content_identity'] = None


@case('UH03', 'a hash-shaped field left null where a computed value is required (render block base_request_hash)', G14, 'typed obligation not a computed value', category='added_domain',
      selectors={'rb': ('at', 'render_blocks', 1, '7dd54595-208d-44cd-9334-00f1e66b855a')})
def _(B, V_, S):
    S['rb']['base_request_hash'] = None


@case('UH04', 'an unclassified hash-shaped null inside an isolated scenario row', G14, 'unclassified hash-shaped nulls', category='added_domain')
def _(B, V_, S):
    at_list(B['members']['scenarios']['scenarios']['approve']['rows']['review_decisions'], 0)['plan_hash'] = None


@case('UH05', 'the approved historical producer fingerprint null appears a third time (only one field / two copies are approved)', G14, 'historical input_fingerprint null must appear exactly twice', category='added_domain')
def _(B, V_, S):
    B['members']['scenarios']['scenarios']['usage_change']['expectations']['input_fingerprint'] = None


# ====================================================================== Part 3: G03 narrowness probes, invalid-selector checks, package (ZIP) corruption cases
import stat as _stat
import zipfile as _zf
import io as _io

# ---------------------------------------------------------------- the eight G03 R1-exception narrowness probes (accepted I2B probes, ported)
G03_PROBES = []
_AID = 'd1250005-0000-4000-8000-000000000006'


def _probe(name, reject=True):
    def deco(fn):
        G03_PROBES.append({'id': 'P%02d' % (len(G03_PROBES) + 1), 'name': name, 'reject': reject, 'fn': fn})
        return fn
    return deco


def _art(B, aid, key='load'):
    rows_ = B['load']['artifacts'] if key == 'load' else B['src_tables']['artifacts']
    hits = [a for a in rows_ if a['artifact_id'] == aid]
    if len(hits) != 1:
        raise V.SelectorError('artifact %s does not resolve uniquely in %s' % (aid, key))
    return hits[0]


@_probe('repaired v2 as shipped (false -> true on the five, specimens matching)', reject=False)
def _(B, V_):
    pass


@_probe('a different retention field changed on an allowed artifact')
def _(B, V_):
    _art(B, _AID)['canonical_payload']['retention'].update(raw_output_retention_policy='x')


@_probe('an extra key added under retention')
def _(B, V_):
    _art(B, _AID)['canonical_payload']['retention'].update(extra=True)


@_probe('captured specimen bytes tampered (raw hash no longer matches)')
def _(B, V_):
    hits = [r for r in B['requests']['requests'] if r['specimen_key'] == 'showrunner_planner']
    if len(hits) != 1:
        raise V.SelectorError('specimen showrunner_planner does not resolve uniquely')
    hits[0]['rendered_request'] += ' '


@_probe('availability encoded as integer 1 instead of JSON true')
def _(B, V_):
    _art(B, _AID)['canonical_payload']['retention'].update(request_bytes_available=1)


@_probe('false -> true on an artifact outside the five literal ids')
def _(B, V_):
    for key, val in (('src', False), ('load', True)):
        a = _art(B, 'd1250005-0000-4000-8000-000000000011', key)
        a['canonical_payload'] = dict(a['canonical_payload'], retention={'request_bytes_available': val})


@_probe('adjacent path variant request_bytes_available_x')
def _(B, V_):
    _art(B, _AID)['canonical_payload']['retention'].update(request_bytes_available_x=True)


@_probe('typed prompt row hash no longer matches the captured specimen')
def _(B, V_):
    hits = [r for r in B['load']['prompt_manifests'] if r['artifact_id'] == _AID]
    if len(hits) != 1:
        raise V.SelectorError('prompt row for the planner manifest does not resolve uniquely')
    hits[0]['rendered_request_hash'] = '0' * 64


# ---------------------------------------------------------------- deliberately INVALID selectors: must fail at selector resolution, before any mutation
SELECTOR_CHECKS = []


def _sc(cid, desc, kind, **kw):
    SELECTOR_CHECKS.append(dict(id=cid, description=desc, kind=kind, **kw))


def _brief(B):
    return B['members']['showrunner_brief']


_sc('SC01', 'row selector that matches zero rows', 'declared', selectors={'x': ('row', 'provider_calls', {'provider_call_id': 'no-such-call'})})
_sc('SC02', 'row selector that matches ten rows (ambiguous)', 'declared', selectors={'x': ('row', 'provider_calls', {'operation': 'tts'})})
_sc('SC03', 'positional selector beyond the end of the table', 'declared', selectors={'x': ('at', 'turns', 999, 'ceb16263-a004-49d2-a9be-41d9eda49b92')})
_sc('SC04', 'positional selector whose declared primary key is not the row at that position', 'declared', selectors={'x': ('at', 'turns', 0, '0d9b2ac0-7b33-4a4a-938d-9760a963967b')})
_sc('SC05', 'selector naming a table that is not in the load', 'declared', selectors={'x': ('row', 'no_such_table', {})})
_sc('SC06', 'artifact selector for an id that is not in the load', 'declared', selectors={'x': ('art', 'd1250005-0000-4000-8000-0000000000ff')})
_sc('SC07', 'member selector for a member that does not exist', 'declared', selectors={'x': ('member', 'no_such_member')})
_sc('SC08', 'render block selector beyond rb09', 'declared', selectors={'x': ('block', 10)})
_sc('SC09', 'render context selector for sequence 0', 'declared', selectors={'x': ('ctx', 0)})
_sc('SC10', 'turn selector for an anchor that does not exist', 'declared', selectors={'x': ('turn', 't99', 'script_pass2')})
_sc('SC11', 'a selector of an unknown kind', 'declared', selectors={'x': ('teleport', 1)})
_sc('SC12', 'JSON pointer to a key that does not exist', 'pointer', target=_brief, mutation={'op': 'set', 'path': '/no_such_key', 'value': 1})
_sc('SC13', 'JSON pointer that descends into a scalar', 'pointer', target=_brief, mutation={'op': 'set', 'path': '/central_question/deeper', 'value': 1})
_sc('SC14', 'JSON pointer whose array index is out of range', 'pointer', target=_brief, mutation={'op': 'set', 'path': '/comprehension_targets/7', 'value': 1})
_sc('SC15', 'selector that is not an absolute JSON pointer', 'pointer', target=_brief, mutation={'op': 'set', 'path': 'central_question', 'value': 'x'})
_sc('SC16', 'a mutation that would change nothing (set to the current value)', 'pointer', target=_brief,
    mutation=lambda t: {'op': 'set', 'path': '/central_question', 'value': t['central_question']})
_sc('SC17', 'add onto a key that already exists', 'pointer', target=_brief, mutation={'op': 'add', 'path': '/central_question', 'value': 'x'})
_sc('SC18', 'swap of two equal entries', 'pointer', target=lambda B: {'a': [1, 1]}, mutation={'op': 'swap', 'path': '/a/0', 'with': '/a/1'})
_sc('SC19', 'a mutation with an unknown operation', 'pointer', target=_brief, mutation={'op': 'teleport', 'path': '/central_question'})
_sc('SC20', 'insert position beyond the end of the list', 'pointer', target=lambda B: {'a': [1, 2]}, mutation={'op': 'insert', 'path': '/a/5', 'value': 9})
_sc('SC21', 'reorder_keys on an object with a single key', 'pointer', target=lambda B: {'a': {'k': 1}}, mutation={'op': 'reorder_keys', 'path': '/a'})
_sc('SC22', 'append onto something that is not a list', 'pointer', target=_brief, mutation={'op': 'append', 'path': '/central_question', 'value': 'x'})
_sc('SC23', 'deleting the document root', 'pointer', target=_brief, mutation={'op': 'delete', 'path': '/'})
_sc('SC24', 'a VALID selector resolves (control: the harness does not reject every selector)', 'declared', selectors={'x': ('row', 'provider_calls', {'provider_call_id': 'fe0f051e-8f55-4c24-b6ae-e54ff1c3ca26'})}, expect='RESOLVED')


# ---------------------------------------------------------------- ZIP-level package corruption cases
PACKAGE_CASES = []


def _pc(cid, desc, needle, expect_override=None):
    def deco(fn):
        PACKAGE_CASES.append({'id': cid, 'description': desc, 'needle': needle, 'build': fn, 'expect_override': expect_override})
        return fn
    return deco


def _E(entries, name):
    hits = [e for e in entries if e['name'] == name]
    if len(hits) != 1:
        raise V.SelectorError('ZIP entry %r resolves to %d entries' % (name, len(hits)))
    return hits[0]


def _edit_json(entries, name, fn):
    e = _E(entries, name)
    o = json.loads(e['data'].decode('utf-8'))
    fn(o)
    e['data'] = _dumpb(o)


def _zip(entries, fix=True):
    if fix:
        V.refresh_inventory(entries)
    return V.make_zip(entries)


def _inv_entry(entries, name):
    o = json.loads(_E(entries, V.PATH['pack_members'])['data'].decode('utf-8'))
    hits = [m for m in o['members'] if m['path'] == name]
    if len(hits) != 1:
        raise V.SelectorError('inventory entry %s does not resolve uniquely' % name)
    return o, hits[0]


def _set_inventory(entries, o):
    _E(entries, V.PATH['pack_members'])['data'] = _dumpb(o)


@_pc('J01', 'duplicate ZIP member (same name twice, different bytes)', 'duplicate ZIP member name')
def _(entries, V_, base):
    entries.append({'name': 'showrunner_brief.json', 'data': b'{}', 'mode': 0o644})
    return _zip(entries, fix=False)


@_pc('J02', 'path-traversal member name', 'unsafe ZIP member name')
def _(entries, V_, base):
    entries.append({'name': '../evil.json', 'data': b'{}', 'mode': 0o644})
    return _zip(entries, fix=False)


@_pc('J03', 'absolute member name', 'unsafe ZIP member name')
def _(entries, V_, base):
    entries.append({'name': '/etc/evil.json', 'data': b'{}', 'mode': 0o644})
    return _zip(entries, fix=False)


@_pc('J04', 'backslash in a member name', 'unsafe ZIP member name')
def _(entries, V_, base):
    entries.append({'name': 'config\\evil.json', 'data': b'{}', 'mode': 0o644})
    return _zip(entries, fix=False)


@_pc('J05', 'symlink member', 'symlink member in ZIP')
def _(entries, V_, base):
    entries.append({'name': 'link.json', 'data': b'showrunner_brief.json', 'attr': (_stat.S_IFLNK | 0o777) << 16})
    return _zip(entries, fix=False)


@_pc('J06', 'directory entry in the ZIP', 'directory entry in ZIP')
def _(entries, V_, base):
    entries.append({'name': 'config/', 'data': b'', 'attr': (_stat.S_IFDIR | 0o755) << 16})
    return _zip(entries, fix=False)


@_pc('J07', 'unlisted extra member', 'unlisted member present')
def _(entries, V_, base):
    entries.append({'name': 'extra.json', 'data': b'{}', 'mode': 0o644})
    return _zip(entries, fix=False)


@_pc('J08', 'listed member missing from the ZIP', 'listed member missing')
def _(entries, V_, base):
    entries.remove(_E(entries, 'showrunner_brief.json'))
    return _zip(entries, fix=False)


@_pc('J09', 'inventory byte count wrong for one member', 'wrong byte count')
def _(entries, V_, base):
    o, m = _inv_entry(entries, 'audit_result.json')
    m['bytes'] += 1
    _set_inventory(entries, o)
    return _zip(entries, fix=False)


@_pc('J10', 'inventory SHA-256 wrong for one member', 'wrong SHA-256')
def _(entries, V_, base):
    o, m = _inv_entry(entries, 'audit_result.json')
    m['sha256'] = '0' * 64
    _set_inventory(entries, o)
    return _zip(entries, fix=False)


@_pc('J11', 'member content changed while the inventory is left unchanged', 'wrong SHA-256')
def _(entries, V_, base):
    _E(entries, 'audit_result.json')['data'] += b' '
    return _zip(entries, fix=False)


@_pc('J12', 'a stored byte flipped inside the compressed data (CRC failure)', 'unreadable ZIP member')
def _(entries, V_, base):
    raw = V.make_zip(entries)
    z = _zf.ZipFile(_io.BytesIO(raw))
    zi = z.getinfo('writing_craft_review.json')
    off = zi.header_offset + 30 + len(zi.filename.encode()) + len(zi.extra) + min(8, zi.compress_size - 1)
    b = bytearray(raw)
    b[off] ^= 0xFF
    return bytes(b)


@_pc('J13', 'truncated ZIP (central directory lost)', 'ZIP cannot be opened')
def _(entries, V_, base):
    return V.make_zip(entries)[:-40]


@_pc('J14', 'an artifact row names a storage_uri that is not a member (inventory rewritten consistently)', 'dangling storage_uri')
def _(entries, V_, base):
    def f(o):
        a = [x for x in o['tables']['artifacts'] if x['artifact_id'] == '595870e7-1b3c-4abc-a794-fc864e0c95b2']
        a[0]['storage_uri'] = 'nonexistent_brief.json'
    _edit_json(entries, 'foundation_rows_398.json', f)
    return _zip(entries)


def _edit_manifest(entries, aid, fn):
    """consistent attacker at pack level: container entry, load artifact payload copy and its complete hash all rewritten, inventory refreshed"""
    def cont(o):
        hit = [e for e in o['manifests'] if e['artifact_id'] == aid]
        fn(hit[0]['canonical_payload'])
    _edit_json(entries, 'prompt_payloads.json', cont)
    box = {}

    def rows_(o):
        a = [x for x in o['tables']['artifacts'] if x['artifact_id'] == aid][0]
        fn(a['canonical_payload'])
        a['content_hash'] = V.DH('prompt-manifest-artifact-v1', a['canonical_payload'])
    _edit_json(entries, 'foundation_rows_398.json', rows_)


@_pc('J15', 'rendered_request_ref.member names a member that is not shipped (payload copies and hash rewritten consistently)', 'rendered_request_ref.member is not a member')
def _(entries, V_, base):
    _edit_manifest(entries, 'b72b67e0-74f8-4d7e-8eb9-1d5af1306c03', lambda pl: pl['rendered_request_ref'].update(member='requests_v2.json'))
    return _zip(entries)


@_pc('J16', 'rendered_request_ref.specimen_key names no specimen (payload copies and hash rewritten consistently)', 'resolves to 0 specimens')
def _(entries, V_, base):
    _edit_manifest(entries, 'b72b67e0-74f8-4d7e-8eb9-1d5af1306c03', lambda pl: pl['rendered_request_ref'].update(specimen_key='writer_2'))
    return _zip(entries)


@_pc('J17', 'two specimens share one specimen_key', 'duplicate specimen_key')
def _(entries, V_, base):
    _edit_json(entries, 'fixture_model_requests.json', lambda o: o['requests'].append(dict(o['requests'][0])))
    return _zip(entries)


@_pc('J18', 'a shared container holds two entries for one artifact id', 'duplicate artifact_id entry')
def _(entries, V_, base):
    _edit_json(entries, 'support_payloads.json', lambda o: o['artifacts'].append(dict(o['artifacts'][0])))
    return _zip(entries)


@_pc('J19', 'a WAV member replaced by other WAV bytes (inventory rewritten consistently)', 'audio member bytes disagree')
def _(entries, V_, base):
    _E(entries, 'fixture_audio/rb02_take0.wav')['data'] = _E(entries, 'fixture_audio/sting.wav')['data']
    return _zip(entries)


@_pc('J20', 'a second member declared as active_load (396-row source co-loaded)', 'exactly one active_load')
def _(entries, V_, base):
    src = _E(entries, 'archive/i2a_source/foundation_rows.json')['data']
    entries.append({'name': 'foundation_rows_396.json', 'data': src, 'mode': 0o644})
    o = json.loads(_E(entries, V.PATH['pack_members'])['data'].decode('utf-8'))
    o['members'].append({'path': 'foundation_rows_396.json', 'bytes': len(src), 'sha256': V.H(src), 'mode': '0644', 'role': 'active_load', 'purpose': 'x', 'referenced_by': []})
    _set_inventory(entries, o)
    return _zip(entries, fix=False)


@_pc('J21', 'a second row-set member present without an archival declaration', 'second row-set member')
def _(entries, V_, base):
    entries.append({'name': 'foundation_rows_396.json', 'data': _E(entries, 'archive/i2a_source/foundation_rows.json')['data'], 'mode': 0o644})
    return _zip(entries, fix=False)


@_pc('J22', 'README carries the SHA-256 of the pack inventory (checksum cycle)', 'checksum cycle')
def _(entries, V_, base):
    h = V.H(_E(entries, V.PATH['pack_members'])['data'])
    _E(entries, 'README.md')['data'] += ('\nPACK_MEMBERS.json sha256 %s\n' % h).encode()
    return _zip(entries, fix=False)


@_pc('J23', 'README lists a member SHA-256 (inventory rewritten consistently)', 'README lists a member SHA-256')
def _(entries, V_, base):
    h = V.H(_E(entries, 'audit_result.json')['data'])
    _E(entries, 'README.md')['data'] += ('\naudit_result.json sha256 %s\n' % h).encode()
    return _zip(entries)


@_pc('J24', 'PACK_MEMBERS.json missing', 'PACK_MEMBERS.json')
def _(entries, V_, base):
    entries.remove(_E(entries, V.PATH['pack_members']))
    return _zip(entries, fix=False)


@_pc('J25', 'frozen record archived mode changed to 0644 in the ZIP while the inventory says 0444', 'archived mode differs from the inventory')
def _(entries, V_, base):
    _E(entries, 'provenance/frozen/technical_resolution_record_v2.md')['mode'] = 0o644
    return _zip(entries, fix=False)


@_pc('J26', 'frozen record mode 0644 in both the ZIP and the inventory (consistent)', 'archived mode is writable')
def _(entries, V_, base):
    _E(entries, 'provenance/frozen/technical_resolution_record_v2.md')['mode'] = 0o644
    o, m = _inv_entry(entries, 'provenance/frozen/technical_resolution_record_v2.md')
    m['mode'] = '0644'
    _set_inventory(entries, o)
    return _zip(entries, fix=False)


@_pc('J27', 'frozen record bytes changed (inventory rewritten consistently)', 'frozen record')
def _(entries, V_, base):
    _E(entries, 'provenance/frozen/technical_resolution_record_v2.md')['data'] += b'\nappended after freeze\n'
    return _zip(entries)


@_pc('J28', 'source accounting pin no longer matches a copied member (inventory rewritten consistently)', 'differs from its pinned source hash')
def _(entries, V_, base):
    def f(o):
        hits = [m for m in o['members'] if m['member'] == 'audit_result.json']
        hits[0]['source_sha256'] = '0' * 64
    _edit_json(entries, 'SOURCE_PROVENANCE.json', f)
    return _zip(entries)


@_pc('J29', 'authority source bytes changed (inventory rewritten consistently)', 'does not match the shipped authority bytes')
def _(entries, V_, base):
    _E(entries, 'authority/02_ACTIVE_SPECS/The_Desk_Claims_Policy_v0.1.2.md')['data'] += b'\n'
    return _zip(entries)


@_pc('J30', 'the case module imports a non-standard-library module (inventory rewritten consistently)', 'non-allowlisted module')
def _(entries, V_, base):
    _E(entries, 'conformance_cases.py')['data'] += b'\nimport subprocess\n'
    return _zip(entries)


@_pc('J31', 'the validator contains an absolute-path literal (inventory rewritten consistently)', 'absolute-path literal')
def _(entries, V_, base):
    _E(entries, 'validate_fixture.py')['data'] += b"\nREACH_BACK = '/" + b"home/codespace'\n"
    return _zip(entries)


@_pc('J32', 'case-colliding member names', 'case-colliding')
def _(entries, V_, base):
    entries.append({'name': 'Showrunner_Brief.json', 'data': b'{}', 'mode': 0o644})
    return _zip(entries, fix=False)


@_pc('J33', 'encrypted-flag member', 'encrypted ZIP member')
def _(entries, V_, base):
    entries.append({'name': 'secret.json', 'data': b'{}', 'mode': 0o644, 'flag': 0x1})
    return _zip(entries, fix=False)


@_pc('J34', 'externally supplied ZIP SHA-256 anchor does not match', 'externally supplied anchor', expect_override={'zip_sha256': '0' * 64})
def _(entries, V_, base):
    return V.make_zip(entries)


@_pc('J35', 'externally supplied PACK_MEMBERS.json SHA-256 anchor does not match', 'externally supplied anchor', expect_override={'pack_members_sha256': '0' * 64})
def _(entries, V_, base):
    return V.make_zip(entries)


@_pc('J36', 'non-regular member (FIFO)', 'non-regular ZIP member')
def _(entries, V_, base):
    entries.append({'name': 'pipe.json', 'data': b'', 'attr': (_stat.S_IFIFO | 0o644) << 16})
    return _zip(entries, fix=False)


@_pc('J37', 'a required archive member missing (inventory rewritten consistently)', 'required member missing')
def _(entries, V_, base):
    entries.remove(_E(entries, 'archive/ARCHIVE_ONLY_85.json'))
    o = json.loads(_E(entries, V.PATH['pack_members'])['data'].decode('utf-8'))
    o['members'] = [m for m in o['members'] if m['path'] != 'archive/ARCHIVE_ONLY_85.json']
    _set_inventory(entries, o)
    return _zip(entries, fix=False)


@_pc('J38', 'an artifact payload member edited so it no longer equals its artifact payload copy (inventory rewritten consistently)', 'member payload differs from artifact payload copy')
def _(entries, V_, base):
    _edit_json(entries, 'showrunner_brief.json', lambda o: o.update(central_question=o['central_question'] + ' (edited)'))
    return _zip(entries)


@_pc('J39', 'the 396-row source file renamed into the active-load position (archive file swapped into foundation_rows_398.json)', 'profile')
def _(entries, V_, base):
    _E(entries, 'foundation_rows_398.json')['data'] = _E(entries, 'archive/i2a_source/foundation_rows.json')['data']
    return _zip(entries)


@_pc('J40', 'validator member bytes changed without refreshing the inventory', 'wrong SHA-256')
def _(entries, V_, base):
    _E(entries, 'validate_fixture.py')['data'] += b'\n# tampered\n'
    return _zip(entries, fix=False)


# ====================================================================== Part 4 (R2): programming-configuration closure (G31) and the runtime-budget checker (G32)
G31 = 'G31_programming_configuration'
G32 = 'G32_runtime_budget'


def _tpl(B):
    hits = [t for _, t in B['cfg']['templates'] if t.get('rundown_template_version_id') == 'post-event-launch-v2']
    if len(hits) != 1:
        raise V.SelectorError('selected template does not resolve uniquely in the bundle')
    return hits[0]


def _brief_blocks(B):
    return B['members']['showrunner_brief']['program_blocks']


def _block(B, slot):
    hits = [b for b in _brief_blocks(B) if b['template_slot_id'] == slot]
    if len(hits) != 1:
        raise V.SelectorError('Brief block for slot %s does not resolve uniquely' % slot)
    return hits[0]


def _slot(B, slot):
    hits = [s for s in _tpl(B)['slots'] if s['slot_id'] == slot]
    if len(hits) != 1:
        raise V.SelectorError('template slot %s does not resolve uniquely' % slot)
    return hits[0]


def _show_both(B, fn):
    """mutate the CURRENT loaded show configuration payload (the single version bound by every attempt) and its member copy together"""
    hits = [r for r in B['load']['show_config_versions'] if r['version_number'] == 2]
    if len(hits) != 1:
        raise V.SelectorError('show_config_versions does not hold exactly one current (version 2) row')
    fn(hits[0]['canonical_payload'])
    fn(B['members']['config_show_version']['canonical_payload'])


def cf(cid, desc, needle, fn, kind='reject'):
    case(cid, desc, G31, needle, kind=kind, category='added_domain')(fn)


cf('CF01', 'Brief selects a template version that is not configured', 'Brief selects template',
   lambda B, V_, S: B['members']['showrunner_brief'].update(rundown_template_version_id='post-event-launch-v3'))
cf('CF02', 'show configuration selects a different template than the Brief (copies kept equal)', 'Brief selects template',
   lambda B, V_, S: _show_both(B, lambda p: p.update(default_rundown_template_version_id='post-event-launch-v3')))
cf('CF03', 'the selected template is not shipped at all', 'template selection is not unique: 0 shipped templates',
   lambda B, V_, S: B['cfg'].update(templates=[]))
cf('CF04', 'the selected template is shipped twice (identical duplicate)', 'duplicate template version ids',
   lambda B, V_, S: B['cfg']['templates'].append(('config/rundown_template_copy.json', copy.deepcopy(_tpl(B)))))
cf('CF05', 'two different templates claim the same version id', 'duplicate template version ids',
   lambda B, V_, S: B['cfg']['templates'].append(('config/rundown_template_other.json', dict(copy.deepcopy(_tpl(B)), slots=_tpl(B)['slots'][:3]))))
cf('CF06', 'template mode is not compatible with the Brief selected mode', 'not compatible with the Brief selected mode',
   lambda B, V_, S: _tpl(B).update(mode='roundup'))
cf('CF07', 'Brief selected mode is an alias string that is not an enum value', 'is not in the episode-mode registry',
   lambda B, V_, S: B['members']['showrunner_brief'].update(selected_mode='normal_post_match'))
cf('CF08', 'Brief block names an unknown template slot', 'names unknown template slot',
   lambda B, V_, S: _block(B, 'analysis_1').update(template_slot_id='analysis_3'))
cf('CF09', 'Brief fills one template slot twice', 'more than once',
   lambda B, V_, S: _block(B, 'recap_turn').update(template_slot_id='analysis_1'))
cf('CF10', 'a required template slot (orientation) is not filled', 'required template slot orientation is not filled',
   lambda B, V_, S: _brief_blocks(B).remove(_block(B, 'orientation')))
cf('CF11', 'STABLE: an OPTIONAL slot (sign_off made optional by the template) may be omitted', '',
   lambda B, V_, S: (_slot(B, 'sign_off').update(required=False), _brief_blocks(B).remove(_block(B, 'sign_off'))), kind='stable')
cf('CF12', 'Brief block type differs from its slot block type', 'has block type',
   lambda B, V_, S: _block(B, 'analysis_1').update(block_type='wrap'))
cf('CF13', 'a block type used by the template is missing from the block-type registry', 'is not in the block-type registry',
   lambda B, V_, S: B['cfg']['blocks'].update(values=[v for v in B['cfg']['blocks']['values'] if v['id'] != 'predictions']))
cf('CF14', 'Brief lead names a participant that is not configured', 'is not in the participant configuration',
   lambda B, V_, S: _block(B, 'cold_open')['participant_leads'][0].update(participant_id='zed'))
cf('CF15', 'a participant used by the scripts is removed from the participant profiles', "participant 'simon' is not in the participant configuration",
   lambda B, V_, S: B['cfg']['participants'].update(profiles=[p for p in B['cfg']['participants']['profiles'] if p['participant_id'] != 'simon']))
cf('CF16', 'a participant profile names a different Character Bible version than the shipped source', 'names Character Bible',
   lambda B, V_, S: B['cfg']['participants']['profiles'][0].update(character_bible_version='0.1.3'))
cf('CF17', 'configured runtime band malformed (min above max)', 'configured_runtime_seconds is not',
   lambda B, V_, S: _show_both(B, lambda p: p['configured_runtime_seconds'].update(min=300, max=60)))
cf('CF18', 'fixture_override used but the selected template does not allow it', 'does not allow it',
   lambda B, V_, S: _tpl(B)['runtime'].update(fixture_override_allowed=False))
cf('CF19', 'Brief runtime_target outside the configured band', 'outside the configured runtime band',
   lambda B, V_, S: B['members']['showrunner_brief']['runtime_target'].update(seconds=400))
cf('CF20', 'a used closed enum value is removed from the preserved registry', 'is not in the closed registry',
   lambda B, V_, S: B['cfg']['enums']['closed'].update(usage_class=['hedged_only', 'silent']))
cf('CF21', 'a configuration member\'s bytes differ from the pinned preserved bytes', 'differs from its pinned preserved bytes',
   lambda B, V_, S: B['pack'].data.update({'config/block_types.json': B['pack'].data['config/block_types.json'] + b' '}))
cf('CF22', 'a configuration member is missing from the pack', 'configuration member missing',
   lambda B, V_, S: B['pack'].data.pop('config/episode_modes.json'))
cf('CF23', 'an active voice row carries a predecessor vp_* label instead of its literal Foundation UUID', 'predecessor vp_* label',
   lambda B, V_, S: B['load']['voice_profile_versions'][0].update(voice_profile_version_id='vp_tully_v1'))
cf('CF24', 'duplicate ids in the episode-mode registry', 'duplicate ids',
   lambda B, V_, S: B['cfg']['modes']['values'].append(dict(B['cfg']['modes']['values'][0])))
cf('CF25', 'show configuration member copy differs from the loaded payload', 'show configuration member differs',
   lambda B, V_, S: B['members']['config_show_version']['canonical_payload'].update(default_episode_mode='roundup'))
cf('CF26', 'two participant profiles share one participant id', 'duplicate participant/profile ids',
   lambda B, V_, S: B['cfg']['participants']['profiles'].append(dict(B['cfg']['participants']['profiles'][0])))
cf('CF27', 'a template slot names a block type outside the registry', 'that is not in the block-type registry',
   lambda B, V_, S: _slot(B, 'wrap').update(block_type='closing_synthesis'))
cf('CF28', 'template slots out of sequence order', 'not in sequence order',
   lambda B, V_, S: _tpl(B)['slots'].reverse())


@case('CF29', 'supporting authority (Character Bible) bytes altered while the policy map still pins them', G24, 'supporting authority', category='added_domain')
def _(B, V_, S):
    k = 'authority/02_ACTIVE_SPECS/The_Desk_Character_Bible_v0.1.4.md'
    B['pack'].data[k] = B['pack'].data[k] + b'\n'


@case('CF30', 'the Character Bible hash appears among the prompt policy sources', G24, 'supporting authority hash appears among the prompt policy sources', category='added_domain')
def _(B, V_, S):
    B['policy']['policies']['claims_policy']['source_sha256'] = B['policy']['supporting_authority']['character_bible']['source_sha256']


# ---- runtime-budget checker (G32). On the CURRENT data the gate passes (positive group); these cases show the CHECKER discriminates on mutated copies.
def _bud(B):
    return _brief_blocks(B)


@case('RB01', 'CHECKER DISCRIMINATION (stable): a band maximum of 330 s admits the nine budgets (the actual current configuration)', G32, '', kind='stable', category='added_domain')
def _(B, V_, S):
    _show_both(B, lambda p: p['configured_runtime_seconds'].update(max=330))


@case('RB02', 'CHECKER DISCRIMINATION (stable on a mutated copy): lowering one 60 s block to 30 s makes the budgets sum to 300 s', G32, '', kind='stable', category='added_domain')
def _(B, V_, S):
    _block(B, 'analysis_1')['target_duration_or_words'] = {'seconds': 30}


@case('RB03', 'a block budget is malformed (seconds as text)', G32, 'block budget malformed', category='added_domain')
def _(B, V_, S):
    _block(B, 'analysis_1')['target_duration_or_words'] = {'seconds': '60'}


@case('RB04', 'runtime band malformed (min above max)', G32, 'runtime band malformed', category='added_domain')
def _(B, V_, S):
    _show_both(B, lambda p: p['configured_runtime_seconds'].update(min=300, max=60))


@case('RB05', 'budgets sum BELOW the configured minimum', G32, 'outside the configured band', category='added_domain')
def _(B, V_, S):
    for b in _bud(B):
        b['target_duration_or_words'] = {'seconds': 5}


@case('RB06', 'an INVENTED tolerance key is not honoured: with max restored to 300 and tolerance_seconds 30, the 330 s budgets are still rejected (no governing source defines a tolerance)', G32, 'outside the configured band', category='added_domain')
def _(B, V_, S):
    _show_both(B, lambda p: p['configured_runtime_seconds'].update(max=300, tolerance_seconds=30))


# ---- ZIP-level closure negatives (inventory rewritten consistently so byte/hash accounting cannot hide them)
def _pcs(cid, desc, needle):
    def deco(fn):
        PACKAGE_CASES.append({'id': cid, 'description': desc, 'needle': needle, 'build': fn, 'expect_override': None})
        return fn
    return deco




# ====================================================================== Part 5 (R2): ZIP-level configuration-closure negatives
@_pcs('J41', 'the selected template file edited (slot block type changed) with the inventory rewritten consistently', 'differs from its pinned preserved bytes')
def _(entries, V_, base):
    _edit_json(entries, 'config/rundown_template_post_event_launch_v2.json', lambda o: o['slots'][3].update(block_type='wrap'))
    return _zip(entries)


@_pcs('J42', 'a second template with the selected version id added and listed (inventory rewritten consistently)', 'template selection is not unique')
def _(entries, V_, base):
    src = _E(entries, 'config/rundown_template_post_event_launch_v2.json')['data']
    entries.append({'name': 'config/rundown_template_copy.json', 'data': src, 'mode': 0o644})
    o = json.loads(_E(entries, V.PATH['pack_members'])['data'].decode('utf-8'))
    o['members'].append({'path': 'config/rundown_template_copy.json', 'bytes': len(src), 'sha256': V.H(src), 'mode': '0644', 'role': 'programming_configuration', 'purpose': 'x', 'referenced_by': []})
    _set_inventory(entries, o)
    return _zip(entries, fix=False)


@_pcs('J43', 'the episode-mode registry removed and the inventory rewritten consistently', 'required member missing')
def _(entries, V_, base):
    entries.remove(_E(entries, 'config/episode_modes.json'))
    o = json.loads(_E(entries, V.PATH['pack_members'])['data'].decode('utf-8'))
    o['members'] = [m for m in o['members'] if m['path'] != 'config/episode_modes.json']
    _set_inventory(entries, o)
    return _zip(entries, fix=False)


@_pcs('J44', 'the Character Bible bytes changed (inventory rewritten consistently)', 'supporting authority')
def _(entries, V_, base):
    _E(entries, 'authority/02_ACTIVE_SPECS/The_Desk_Character_Bible_v0.1.4.md')['data'] += b'\n'
    return _zip(entries)


@_pcs('J45', 'the participant configuration edited (a participant removed) with the inventory rewritten consistently', 'differs from its pinned preserved bytes')
def _(entries, V_, base):
    _edit_json(entries, 'config/participant_profiles.json', lambda o: o['profiles'].pop())
    return _zip(entries)


@_pcs('J46', 'the Brief member and its artifact copy select another template (inventory rewritten consistently)', 'Brief selects template')
def _(entries, V_, base):
    _edit_json(entries, 'showrunner_brief.json', lambda o: o.update(rundown_template_version_id='post-event-launch-v3'))
    def rows_(o):
        a = [x for x in o['tables']['artifacts'] if x['artifact_id'] == '595870e7-1b3c-4abc-a794-fc864e0c95b2'][0]
        a['canonical_payload']['rundown_template_version_id'] = 'post-event-launch-v3'
    _edit_json(entries, 'foundation_rows_398.json', rows_)
    return _zip(entries)


@_pcs('J47', 'the preserved enum registry edited (a closed value removed) with the inventory rewritten consistently', 'differs from its pinned preserved bytes')
def _(entries, V_, base):
    _edit_json(entries, 'config/enum_registries.json', lambda o: o['closed'].update(usage_class=['hedged_only', 'silent']))
    return _zip(entries)


# ====================================================================== Part 6 (CONFIG-330): corrected runtime-budget gate (CB) and show-configuration lineage / ownership (CC)
G34 = 'G34_show_config_lineage'


def _cfg_pair(B):
    rs = B['load']['show_config_versions']
    v1 = [r for r in rs if r['version_number'] == 1]
    v2 = [r for r in rs if r['version_number'] == 2]
    if len(rs) != 2 or len(v1) != 1 or len(v2) != 1:
        raise V.SelectorError('show_config_versions does not hold exactly versions 1 and 2')
    return v1[0], v2[0]


def _atts(B):
    a = B['load']['program_run_attempts']
    if len(a) != 2:
        raise V.SelectorError('program_run_attempts does not hold exactly two attempts')
    return a


def _scen_child(B, name):
    rows_ = B['members']['scenarios']['scenarios'][name]['rows']['program_run_attempts']
    if len(rows_) != 1:
        raise V.SelectorError('scenario %s does not hold exactly one repair child attempt' % name)
    return rows_[0]


def cb(cid, desc, group, needle, fn, kind='reject'):
    case(cid, desc, group, needle, kind=kind, category='config330_budget')(fn)


def cc(cid, desc, group, needle, fn, kind='reject'):
    case(cid, desc, group, needle, kind=kind, category='config330_lineage')(fn)


# ---- CB: the corrected G32 behaviour (no equality with runtime_target; ordinary pass/fail inside the corrected band)
cb('CB01', 'STABLE: the current configuration admits the authored 330 s budgets with the 240 s runtime_target retained (positive behaviour, no mutation)', G31 + '+' + G32, '',
   lambda B, V_, S: None, kind='stable')
cb('CB02', 'the budgets total 331 s against the corrected band maximum 330 s', G32, 'outside the configured band',
   lambda B, V_, S: _block(B, 'analysis_1').update(target_duration_or_words={'seconds': 61}))
cb('CB03', 'the budgets total below the band minimum (nine blocks of 6 s = 54 s)', G32, 'outside the configured band',
   lambda B, V_, S: [b.update(target_duration_or_words={'seconds': 6}) for b in _brief_blocks(B)])
cb('CB04', 'a block budget is not a positive integer (0 seconds)', G32, 'block budget malformed',
   lambda B, V_, S: _block(B, 'analysis_1').update(target_duration_or_words={'seconds': 0}))
cb('CB05', 'the runtime band is malformed (min 0)', G32, 'runtime band malformed',
   lambda B, V_, S: _show_both(B, lambda p: p['configured_runtime_seconds'].update(min=0)))
cb('CB06', 'an ungoverned tolerance field is present on the configured band', G31, 'configured_runtime_seconds is not',
   lambda B, V_, S: _show_both(B, lambda p: p['configured_runtime_seconds'].update(tolerance_seconds=30)))


@case('CB07', 'max restored to 300 while the budgets stay 330 s (configuration member, row copy and recomputed hash kept consistent)', G32, 'outside the configured band', category='config330_budget')
def _(B, V_, S):
    v1, v2 = _cfg_pair(B)
    v2['canonical_payload']['configured_runtime_seconds']['max'] = 300
    B['members']['config_show_version']['canonical_payload']['configured_runtime_seconds']['max'] = 300
    v2['config_hash'] = V_.DH('show-config-v1', v2['canonical_payload'])
    B['members']['config_show_version']['config_hash'] = v2['config_hash']


@case('CB08', 'the launch template is mutated (standard 10 -> 11 minutes): outside the authorised correction and the pinned preserved bytes', G31, 'differs from its pinned preserved bytes', category='config330_budget')
def _(B, V_, S):
    k = 'config/rundown_template_post_event_launch_v2.json'
    if k not in B['pack'].data:
        raise V.SelectorError('launch template member missing')
    o = json.loads(B['pack'].data[k].decode('utf-8'))
    if o['runtime'] != {'quiet_minutes': 8, 'standard_minutes': 10, 'big_minutes': 12, 'fixture_override_allowed': True}:
        raise V.SelectorError('launch template runtime is not 8/10/12')
    o['runtime']['standard_minutes'] = 11
    B['pack'].data[k] = (json.dumps(o, indent=2, sort_keys=True) + '\n').encode('utf-8')


cb('CB09', 'STABLE (G32 alone): runtime_target below the budget sum (100 s) does not affect the budget gate - no equality with the target is required', G32, '',
   lambda B, V_, S: B['members']['showrunner_brief']['runtime_target'].update(seconds=100), kind='stable')
cb('CB10', 'runtime_target above the corrected band maximum (331 s)', G31, 'outside the configured runtime band',
   lambda B, V_, S: B['members']['showrunner_brief']['runtime_target'].update(seconds=331))
cb('CB11', 'runtime_target purpose is not evaluation_fixture', G31, 'not evaluation_fixture',
   lambda B, V_, S: B['members']['showrunner_brief']['runtime_target'].update(purpose='production'))
cb('CB12', 'STABLE (G32 alone): runtime_target 99999 is ignored by the budget gate', G32, '',
   lambda B, V_, S: B['members']['showrunner_brief']['runtime_target'].update(seconds=99999), kind='stable')


# ---- CC: configuration versioning, ownership and READY / revalidation propagation
def _set(o, **kw):
    o.update(kw)


cc('CC01', 'configuration version 2 without a parent', G34, 'configuration parent chain',
   lambda B, V_, S: _set(_cfg_pair(B)[1], parent_version_id=None))
cc('CC02', 'configuration parent cycle (version 1 names version 2 as parent)', G34, 'configuration parent chain',
   lambda B, V_, S: _set(_cfg_pair(B)[0], parent_version_id=_cfg_pair(B)[1]['show_config_version_id']))
cc('CC03', 'version_number is not parent + 1 (3)', G34, 'exactly show-config versions 1 and 2',
   lambda B, V_, S: _set(_cfg_pair(B)[1], version_number=3))
cc('CC04', 'payload differs from the parent in another key (show_version label)', G34, 'beyond configured_runtime_seconds.max',
   lambda B, V_, S: _cfg_pair(B)[1]['canonical_payload'].update(show_version='postmatch-fixture-v5'))
cc('CC05', 'configuration hash is not recomputable', G34, 'does not recompute',
   lambda B, V_, S: _set(_cfg_pair(B)[1], config_hash='0' * 64))
cc('CC06', 'the old configuration row is mutated (payload label)', G34, 'version 1',
   lambda B, V_, S: _cfg_pair(B)[0]['canonical_payload'].update(name='Northbridge Post-Match (edited)'))
cc('CC07', 'configuration member differs from the loaded current row', G31, 'show configuration member differs',
   lambda B, V_, S: _cfg_pair(B)[1]['canonical_payload']['configured_runtime_seconds'].update(min=61))
cc('CC08', 'an attempt is still bound to the old configuration', G34, 'every loaded attempt must be bound',
   lambda B, V_, S: _set(_atts(B)[0], show_config_version_id=_cfg_pair(B)[0]['show_config_version_id']))
cc('CC09', 'the two attempts are bound to different configurations', G34, 'every loaded attempt must be bound',
   lambda B, V_, S: _set(_atts(B)[1], show_config_version_id=_cfg_pair(B)[0]['show_config_version_id']))
cc('CC10', 'a loaded attempt carries an archived accepted-v2 attempt id (old-attempt reuse)', G34, 'not a fresh identity',
   lambda B, V_, S: _set(_atts(B)[0], attempt_id='22222222-2222-4222-8222-222222222221'))


@case('CC11', 'an old (archived v2) attempt row is co-loaded beside the fresh attempts, bound to the old configuration', G34, 'every loaded attempt must be bound', category='config330_lineage')
def _(B, V_, S):
    a = _atts(B)
    old = dict(a[0], attempt_id='22222222-2222-4222-8222-222222222221', show_config_version_id=_cfg_pair(B)[0]['show_config_version_id'])
    B['load']['program_run_attempts'].append(old)


cc('CC12', 'READY expectations carry the old configuration id', G34, 'READY expectations are not bound',
   lambda B, V_, S: B['members']['ready_expectations'].update(show_config_version_id=_cfg_pair(B)[0]['show_config_version_id']))
cc('CC13', 'READY expectations carry the old (archived v2) attempt id', G34, 'READY expectations are not bound',
   lambda B, V_, S: B['members']['ready_expectations'].update(attempt_id='22222222-2222-4222-8222-222222222222'))


@case('CC14', 'the revalidation result carries the old READY candidate fingerprint', G34, 'revalidation result does not carry', category='config330_lineage')
def _(B, V_, S):
    both(B, 'revalidation_result__successor', lambda p: p.update(ready_candidate_fingerprint='5179590fc930db43078ca00485dcd05d619761f48c4e1bf281786b7a22344267'))


cc('CC15', 'an isolated repair child is bound to a different configuration than its parent attempt', G34, 'does not inherit',
   lambda B, V_, S: _set(_scen_child(B, 'performance_repair'), show_config_version_id=_cfg_pair(B)[0]['show_config_version_id']))


@case('CC16', 'a rejected-v3 identity is presented as a current identity', G34, 'rejected-v3 identity', category='config330_lineage')
def _(B, V_, S):
    ids = (B['denylist'] or {}).get('rejected_v3_ids', [])
    if not ids:
        raise V.SelectorError('rejected-v3 denylist is empty')
    B['members']['scenarios']['scenarios']['halt']['x_probe_identity'] = ids[0]


@case('CC17', 'a replaced accepted-v2 SOURCE gate row id is co-loaded', 'G13_gates_ready', 'source gate row id was retained', category='config330_lineage')
def _(B, V_, S):
    g = at_list(B['load']['gate_results'], 0)
    g['gate_result_id'] = 'd125001a-0000-4000-8000-000000000002'


@case('CC18', 'an archived accepted-v2 (fresh) attempt-owned gate row id is co-loaded', G34, 'accepted v2 attempt-owned rows are co-loaded', category='config330_lineage')
def _(B, V_, S):
    olds = [r['v2_id'] for r in B['archive283'] if r['family'] == 'gate_results']
    if not olds:
        raise V.SelectorError('no archived v2 gate rows')
    at_list(B['load']['gate_results'], 0)['gate_result_id'] = olds[0]


cc('CC19', 'a second configuration edit: the Brief show_version label differs from the configuration label', G34, 'show_version differs',
   lambda B, V_, S: B['members']['showrunner_brief'].update(show_version='postmatch-fixture-v5'))
cc('CC20', 'configuration version 2 created before its parent', G34, 'not created after its parent',
   lambda B, V_, S: _set(_cfg_pair(B)[1], created_at='2026-09-27T11:59:59Z'))


# ====================================================================== Part 4: cases ADDED in v0.4.6 (category 'authority_resolution_v046')
# Authority-resolution decisions D1-D5: closed profiles, the Writing fixture-profile addendum binding, the structural domain of the projection,
# mechanical-sensitivity labels and the identity-transition record. Each case rewrites subjects consistently where a stale-hash check could hide it.
G35 = 'G35_authority_resolution_vectors'
G36 = 'G36_v046_identity_transition'
ADD_KEY, ADD_ID = 'writing_fixture_profile_addendum', 'writing-fixture-profile-addendum-0.1'


def ar(cid, desc, group, needle, fn, selectors=None):
    case(cid, desc, group, needle, selectors=selectors, category='authority_resolution_v046')(fn)


def _vec(B, vid):
    hits = [v for v in B['authres']['vectors'] if v['id'] == vid]
    if len(hits) != 1:
        raise V.SelectorError('authority vector %s is not unique' % vid)
    return hits[0]


def _bvec(B, vid):
    hits = [v for v in B['v_base_request']['vectors'] if v['id'] == vid]
    if len(hits) != 1:
        raise V.SelectorError('base-request vector %s is not unique' % vid)
    return hits[0]


def _addendum_path(B):
    return B['policy']['policies'][ADD_KEY]['shipped_at']


ar('AR01', 'a recorded authority-vector expected hash is altered', G35, 'recorded expectation', lambda B, V_, S: _vec(B, 'PC-15')['expect'].update(hash='0' * 64))
ar('AR02', 'a recorded authority-vector rejection code is altered', G35, 'expected rejection', lambda B, V_, S: _vec(B, 'PC-04')['expect'].update(code='prediction_unknown_field'))
ar('AR03', 'an authority vector is removed (declared count and the Hashing s10.1 range no longer match)', G35, 'declared count', lambda B, V_, S: B['authres']['vectors'].pop())
ar('AR04', 'authority vector ids are not contiguous within a family', G35, 'not contiguous', lambda B, V_, S: _vec(B, 'PC-16').update(id='PC-17'))
ar('AR05', 'the shipped addendum bytes differ from the policy-map source hash', G24, 'does not match the shipped authority bytes',
   lambda B, V_, S: B['pack'].data.update({_addendum_path(B): B['pack'].data[_addendum_path(B)] + b'\n'}))
ar('AR06', 'the addendum is missing from the policy map (an inventory entry is required but not sufficient)', G24, 'ten expected policies', lambda B, V_, S: B['policy']['policies'].pop(ADD_KEY))


def _drop_addendum(pl):
    pl['component_versions'].pop(ADD_KEY)
    pl['policy_source_hashes'].pop(ADD_KEY)


ar('AR07', 'the writer manifest omits the addendum binding (payload, typed row, container and hash rewritten together)', G35, 'expected acceptance',
   lambda B, V_, S: attack(B, S, WRITER, _drop_addendum, typed=('component_versions', 'policy_source_hashes')), selectors=_sel_ma(WRITER))
ar('AR08', 'the writer view re-exposes retention_class to the writer', G35, 'expected acceptance',
   lambda B, V_, S: both(B, 'writer_view', lambda p: [e.update(retention_class='fixture_retained') for e in p['selected_evidence']]))
ar('AR09', 'the context manifest omits the addendum from required_policy_refs', G35, 'expected acceptance',
   lambda B, V_, S: both(B, 'writer_context_manifest', lambda p: p.update(required_policy_refs=['writing-0.2.3', 'writing-craft-0.1', 'claims-0.1.2'])))


def _bind_planner(pl, B):
    pl['component_versions'][ADD_KEY] = ADD_ID
    pl['policy_source_hashes'][ADD_KEY] = V.H(B['pack'].data[_addendum_path(B)])


ar('AR10', 'the planner manifest binds the addendum although it governs no planner input', G35, 'expected acceptance',
   lambda B, V_, S: attack(B, S, PLANNER, lambda pl: _bind_planner(pl, B), typed=('component_versions', 'policy_source_hashes')), selectors=_sel_ma(PLANNER))
ar('AR11', 'a mechanical-sensitivity label is removed from an ownership-invalid vector (SN015)', G35, 'labels differ', lambda B, V_, S: _bvec(B, 'SN015').pop('mechanical_sensitivity'))
ar('AR12', 'OW027 (context text rejection) is removed', G35, 'no rejection vector covers', lambda B, V_, S: B['v_base_request']['vectors'].remove(_bvec(B, 'OW027')))
ar('AR13', 'the identity transition records a stage fingerprint as changed', G36, 'stage fingerprint', lambda B, V_, S: B['transition']['stage_fingerprints'][0].update(status='changed'))
ar('AR14', 'the identity transition records a script hash as having changed', G36, 'no regenerated chain value',
   lambda B, V_, S: [a.update(content_hash_v045='0' * 64, status='changed') for a in B['transition']['artifacts'] if a['artifact_type'] == 'script_pass1'])
ar('AR15', 'a stored prediction candidate gains a Writing s16 settlement field', G35, 'expected acceptance',
   lambda B, V_, S: both(B, 'script_pass1', lambda p: p['prediction_candidates'][0].update(settlement_scope='x')))
ar('AR16', 'the current show configuration payload gains a fifteenth key', G35, 'expected acceptance',
   lambda B, V_, S: sorted(B['load']['show_config_versions'], key=lambda r: r['version_number'])[1]['canonical_payload'].update(extra=1))
ar('AR17', 'the semantic-audit result carries a non-empty findings list', G35, 'expected acceptance',
   lambda B, V_, S: both(B, 'semantic_audit_result__successor', lambda p: p.update(findings=[{'finding_type': 'x'}])))
ar('AR18', 'the Brief gains an unknown key', G35, 'expected acceptance', lambda B, V_, S: both(B, 'showrunner_brief', lambda p: p.update(extra_key=1)))


def _pg_block(B, n):
    hits = [b for b in B['v_base_request']['actual_blocks'] if b['render_block_sequence'] == n]
    if len(hits) != 1:
        raise V.SelectorError('actual block %s is not unique' % n)
    return hits[0]['input_record']


ar('AR19', 'an application of actual block 3 references a voice that resolves to no voice-map entry', G35, 'expected acceptance',
   lambda B, V_, S: _pg_block(B, 3)['pronunciation_applications'][0].update(voice_profile_version_id='cf0000bb-0000-4000-8000-000000000001'))
ar('AR20', 'a second voice-map entry carries the voice id an application references (ambiguous reference)', G35, 'expected acceptance',
   lambda B, V_, S: _pg_block(B, 3)['voice_versions'].update(zz_extra_participant=copy.deepcopy(next(iter(_pg_block(B, 3)['voice_versions'].values())))))
ar('AR21', 'the transition lists a changed member as unchanged', G36, 'flagged unchanged',
   lambda B, V_, S: [m.update(status='unchanged') for m in B['transition']['members'] if m['status'] == 'changed'][:1] or (_ for _ in ()).throw(V.SelectorError('no changed member')))
