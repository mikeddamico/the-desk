# The Desk — I2B technical resolution record (version 1)

Status: FROZEN at creation. This file is immutable evidence; a later correction creates a new version and requires dependent recomputation.

## 1. Authorship and observed times (truthful provenance)

- Technical adjudicator: the supervising assistant, acting under Mike's delegated remit, by adjudication v0.4 as relayed in the execution handoff. This record does not attribute approval of any technical particular to Mike, and no human semantic override exists or is claimed.
- Correction executor and author of this record: Claude Code (model claude-sonnet-5-5, single agent, no subagents, no provider or paid operation), running offline Python standard-library scripts in the successor area.
- Observed time this record was frozen: 2026-09-30T14:20:25Z (UTC, system clock at creation).
- Observed time the pre-execution verification output was last written: 2026-09-30T14:19:34Z (UTC, file mtime).
- This is not a model run, not a director/producer run, and not an execution of the inherited label `fixture_direction_manual_v3`. It is an offline manual correction. Fixture scenario clocks (2026-09-27 values) are declared synthetic settings and are unrelated to these observed times.

## 2. Final rules (from adjudication v0.4, decisions 1–4 and F1/F2 resolutions)

### 2.1 Bounded event-scope hash
- Projection = the eight `manifest.scope` fields, values and array order preserved: `competition_ids`, `entity_ids`, `event_ids` (ordered arrays of nonblank strings); `locale`, `scheduled_default_mode`, `target_publication_slot_ref` (nonblank strings); `scope_type` (literal `event`); `show_id` (governed UUID resolving to the bound show). Any other scope type or unrecognized field is rejected.
- `scope_hash = lower_hex(SHA256(UTF8("evidence-package-scope-v1\n") || canonical_json_bytes(scope_projection)))` — canonical serializer of Hashing v0.1.4 §1, exactly one LF after the domain, no BOM, no trailing LF, no wrapper. The package hash keeps selecting `manifest` and excludes this envelope digest.

### 2.2 Bounded cross-block context recipe (C2-v1) and digest
- rb01 stays `C0-v1` with no context: `{"recipe_version":"C0-v1","turns":[]}` receives a computed non-null digest.
- rb02–rb09 are relabeled `C2-v1`: the render block begins at the first approved turn of its program block and uses exactly one context turn, the final approved turn of the immediately preceding program block (the within-block C1 component is empty). The recipe is rejected if the block begins elsewhere, the preceding block is not adjacent in the frozen Brief order, or the turn is not that block's final approved turn. It is not extended to split-block cases.
- `context_hash = lower_hex(SHA256(UTF8("render-context-v1\n") || canonical_json_bytes({"recipe_version":..., "turns":[{"semantic_turn_id","participant_id","spoken_text"}...]})))`; storage UUIDs, sequence, program-block storage refs, script/manifest hashes and the digest itself are excluded. TTS hashes bounded context content directly, not this digest.

### 2.3 Editorial pace correction
- Change only the value of source intent `d1250017-0000-4000-8000-000000000006` (pace, scope turn `d1250013-0000-4000-8000-000000000048` = final-script anchor t14, participant tully, strength standard, timing anchor null) from `measured` to `slower`. The other seven intents and every script word are unchanged. The closed vocabulary is not extended. `slower` is a selected delivery correction, not a synonym declaration and not a claim about historical audio.
- A new immutable direction version/artifact with eight newly owned intent rows supersedes the historical source through the existing `artifacts.supersedes_artifact_id`; the original source rows are never reparented or mutated.

### 2.4 Historical limitation and correction fingerprint
- The original source direction's producer-input identity is unrecoverable. JSON null is authorized only for that preserved historical envelope and its artifact-payload copy, disposition `historical_producer_inputs_not_recorded`: one nested field, two storage copies, outside the 176 typed placeholders; never a computed hash.
- The corrected direction's `input_fingerprint` is non-null: `lower_hex(SHA256(UTF8("performance-direction-correction-input-v1\n") || canonical_json_bytes(P)))` with P having exactly five top-level keys: `source_direction_hash`, `script_hash`, `direction_spec_version` (`performance-render-0.1.4`), `adjudication_record_sha256` (raw-byte SHA-256 of this frozen file), and `correction` = `{source_performance_intent_id, source_scope_ref, intent_type:"pace", expected_value:"measured", replacement_value:"slower"}`.
- Actor/time exclusion from the correction projection is direct only: this file's exact bytes, including this provenance, intentionally reach the fingerprint through `adjudication_record_sha256`. Direction content hashing still excludes the producer fingerprint.

### 2.5 Load profile and dependency order
- Fresh offline fixture load: 311 retained source rows + 95 fresh rows = 406 rows across 40 families; 85 source downstream rows are archive-only and not co-loaded; ten retained rows are historical direction input. Repeated-manifest cached-take ownership is a deferred runtime-contract gap and is not proven by this fixture.
- Dependency order: source/script reconstruction and pre-execution verification → this frozen record → correction input bytes and fingerprint → corrected direction → audit → render → assembly → READY.
- Existing fixture adapter contract version (`fixture-adapter-contract-v2`) is retained; no global version bump.

## 3. Source bindings

- Repository: `/home/codespace/desk-v1.2.5-persistence-review/repository`, branch `hotfix/final-lock-v1.2.5-persistence-contract`, HEAD `1c85b4f07344cb6e03ec1619e3e059538d36ca3d`.
- I2A inventory SHA-256 `6b234bc03a7ec445914e98d323840e365b5412612346bec76fcb888ad67c660d`; I2A checkpoint SHA-256 `26b4f3a5e83f02bd90bad3e54aeb6052cad8bb985b1f52b83c0807440557eb95`; stopped I2B inventory SHA-256 `0dd7b4b792ff7684f9f6647d1b8039732bbdf7e12badf0cd109d7693675b8998`; stopped I2B checkpoint SHA-256 `3e2b1d9d88773e827350e95d5dd00253aefb080c7738fecec398d897b490e1d9`.
- Performance & Render v0.1.4: `The_Desk_Performance_and_Render_v0.1.4.md` SHA-256 `959474f6f90668b0c5d76e2bd4deafdb9cb52e8df706e469dc9d4b7b088381dc`.
- Hashing v0.1.4: `The_Desk_Hashing_Fingerprints_and_Text_Spans_v0.1.4.md` SHA-256 `73cfc4727ce375df0a402c38b9a9044ceb6a1015ce0bcbeaf97433f6986f6d60`.
- Writing v0.2.3: `The_Desk_Writing_Spec_v0.2.3.md` SHA-256 `62f2a4c5424a39ee445929a47c2ffea070eb3ded40767876ae328fe2dcc42bda`.
- Evidence Package v0.2.2: `The_Desk_Evidence_Package_v0.2.2.md` SHA-256 `f12582a70cd9223fdd05dbabf8bf2fbddfe11816ab4c1925d24e24c8051e71ea`.
- Showrunner Planning v0.1.3: `The_Desk_Showrunner_Planning_v0.1.3.md` SHA-256 `8a658b976a3c9d73bb2e039655ab4016af867b919d906bbc07aef286555b7367`.
- Source direction envelope `authored/performance_direction.json` raw SHA-256 `8b0c14b2f7dc7e7109e7895ca84add7e7fd36ec79c1b3a9bc13b85611bf703a4`; source direction artifact `d1250005-0000-4000-8000-000000000012`, version `d1250016-0000-4000-8000-000000000001`.
- Reconstructed source direction content hash (input integrity only; hashing bytes does not validate them): `ea5926e81267dd749cf33ed29564fe88815d3243b68260f1b4ddb96588e2f533`.
- Bound final script content hash (unchanged by the correction): `4b6bc58ac065979711c14a681450601e04cb7f2984fa276f0cc7f5b0459671dd`.
- Unchanged upstream content hashes reconstructed in phase 1: brief_hash `a686ae9a75d9f8e03b82d44d88a4cefc5f565eaf1338c5b1334bd3cc49c14f24`, package_hash `a8655c0e8bd72094a823b367a0c21cd665d3d99c271341286a92dbdc2ea304ab`, scope_hash `ecb1eb2b675a9e383dfe88e6311f8cc88cc97eb17183df9a8cae935d8d1f8979`, script_craft_revision `c4f009cc9a2bd5d0409118d6ab1c3d66082f107a3a9933dd2702bbbe3a338d66`, script_pass1 `da38e493ab7bbbcd24b58e7bcc189315f7de5df364261c1997a5b2957b6188c3`, script_pass2 `4b6bc58ac065979711c14a681450601e04cb7f2984fa276f0cc7f5b0459671dd`, serialized_input_hash `e25feecc6790848fc4af8adf336700236a236f74543e2fe1bf8b1259a2933e94`, writer_context_manifest_hash `f308927ca07f0f8a430cc276d4ae968c7a0e6ae01d54a48fbc910eb299ab8520`, writer_view_hash `9213f26a1e577cc2528596b6023567b6f7eada1e82d0a2622f495c5bad9544e9`, writing_craft_review `4c489b5bad3706b18c9576675e4777d13dc2f4028f6e0e0160af91d8f0aaf572`.
- Pre-execution verification output `preexec/PREEXEC_VERIFICATION.json` raw SHA-256 `ff7d87ef206c3f2fe1dcf7a1c5c71a01f3c794fbb03bb49b934d2f62a71f0ab6`.

## 4. Pre-execution verification summary (32 checks, 32 passed, 0 failed)

- [PASS] `words-script_pass1` — all 17 spoken strings byte-equal to predecessor and NFC
- [PASS] `words-script_craft_revision` — all 17 spoken strings byte-equal to predecessor and NFC
- [PASS] `words-script_pass2` — all 17 spoken strings byte-equal to predecessor and NFC
- [PASS] `scope-schema` — exact eight keys with required types; scope_type literal event
- [PASS] `scope-resolution` — show, entity, competition and event ids resolve to the bound show/package/window
- [PASS] `scope-reject-other-scope_type` — author projection rejects other scope_type
- [PASS] `scope-reject-unrecognized-field` — author projection rejects unrecognized field
- [PASS] `scope-reject-missing-field` — author projection rejects missing field
- [PASS] `scope-reject-array-replaced-by-string` — author projection rejects array replaced by string
- [PASS] `scope-hash-recompute` — scope hash recomputed from framing bytes equals stored
- [PASS] `c0-rb01` — rb01 is C0-v1 with an empty context
- [PASS] `c2-rb02` — C2 bound/adjacency/last-turn holds; old C1 label invalid for cross-block context
- [PASS] `c2-rb03` — C2 bound/adjacency/last-turn holds; old C1 label invalid for cross-block context
- [PASS] `c2-rb04` — C2 bound/adjacency/last-turn holds; old C1 label invalid for cross-block context
- [PASS] `c2-rb05` — C2 bound/adjacency/last-turn holds; old C1 label invalid for cross-block context
- [PASS] `c2-rb06` — C2 bound/adjacency/last-turn holds; old C1 label invalid for cross-block context
- [PASS] `c2-rb07` — C2 bound/adjacency/last-turn holds; old C1 label invalid for cross-block context
- [PASS] `c2-rb08` — C2 bound/adjacency/last-turn holds; old C1 label invalid for cross-block context
- [PASS] `c2-rb09` — C2 bound/adjacency/last-turn holds; old C1 label invalid for cross-block context
- [PASS] `enum-source-violations` — exactly one source intent violates the closed vocabulary (pace=measured)
- [PASS] `pace-intent-identity` — intent 006 is pace/standard/null timing on final turn t14, participant tully
- [PASS] `slower-legal` — 'slower' is in the closed pace vocabulary and 'measured' is not
- [PASS] `source-direction-hash` — source direction semantic hash reconstructed from the bound final script
- [PASS] `derivation-recompute` — late-concession count strictly > minute 80 over the five scoped matches is 3
- [PASS] `equal-body-hash` — isolated equal-body evidence hashes equal to evidence 005 with a distinct UUID
- [PASS] `writer-view-19-keys` — writer data object has exactly the nineteen Writing 5.1 keys
- [PASS] `writer-forbidden-absent` — forbidden claim/evidence ids are absent from serialized writer data
- [PASS] `context-required-claims` — required_claim_refs equals the writer-view selected claims (order kept)
- [PASS] `context-selection-refs` — required context selections equal Brief context selections
- [PASS] `context-applied-exclusions` — exclusions_applied_count equals the number of Brief planning exclusions applied
- [PASS] `context-token-budget` — declared synthetic token estimate + reserved output fits the declared limit
- [PASS] `uuid-plan` — 95 rows, 95 distinct canonical v4 fresh ids, none present in source foundation rows

C2 boundary table (source label → anchors): rb02 t02→t03; rb03 t03→t04; rb04 t05→t06; rb05 t08→t09; rb06 t09→t10; rb07 t13→t14; rb08 t14→t15; rb09 t16→t17.

## 5. Not claimed

No I2C packaging, activation, Migration 002, production or live-provider fidelity, human semantic override, or database execution is claimed. This record contains no successor identity allocation, correction-input or sidecar digest, corrected-output hash, or downstream validation result.
