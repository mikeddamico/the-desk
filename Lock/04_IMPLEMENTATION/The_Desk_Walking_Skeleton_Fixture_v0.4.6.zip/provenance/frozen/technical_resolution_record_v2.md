# The Desk — CONFIG-330 technical resolution record (version 2)

Status: FROZEN at creation. Version 1 (`technical_resolution_record_v1.md`, raw SHA-256 `3f8a760aa106e238d262132ab396cc3a99f71c72768a2f6a72b14c65bd7f78c3`) remains frozen history. This version 2 is the new version that v1 requires for a later correction ("a later correction creates a new version and requires dependent recomputation"): it records the CONFIG-330 corrected successor.

## 1. Authorship and observed times (truthful provenance)

- Technical decision chain: the supervising assistant's CONFIG-330 correction plan (revised transfer SHA-256 `8ffee35d983e43aad85156d18f10a8f7c71530e07f2823042b696fa76c11072a`, plan inventory `f80f0ced12c2a69c2d3f715f518185324d47689148d74cd88d7eeb884bdc1e30`, frozen identity table `8f7311d88218eaf9a7414e7bd4c3ff418054e82698b645eddb34633e9fa19830`) and the execution authorization that followed it. No approval of any technical particular is attributed to Mike, and no human semantic override exists.
- Executor and author of this record: Claude Code (model claude-sonnet-5-5, single agent, no subagents, no provider or paid operation), running offline Python standard-library scripts in the successor area.
- Observed time this record was frozen: 2026-10-01T00:12:14Z (UTC, system clock at creation).
- Observed time the pre-execution verification output was last written: 2026-10-01T00:12:14Z (UTC, system clock).
- This is not a model run, not a director/producer run, and not an execution of the inherited label `fixture_direction_manual_v3`. It is an offline re-keying of the already corrected direction. Fixture scenario clocks (2026-09-27 values) are declared synthetic settings and are unrelated to these observed times.

## 2. Rules (version 1 rules inherited unchanged; version 2 deltas)

### 2.1 Inherited unchanged
- Version 1 sections 2.1–2.5 apply unchanged: bounded event-scope hash, C0/C2 context recipe and digest, the editorial pace correction (source intent value `measured` replaced by `slower`; nothing else), the historical-null disposition for the preserved historical direction, the correction fingerprint formula with exactly five top-level keys, and the existing adapter contract version.

### 2.2 Single configuration edit
- A new immutable `show_config_versions` row (version 2, parent = the version-1 row) changes only `configured_runtime_seconds.max` from 300 to 330 (`min` 60 and `fixture_override` true unchanged; no other key, including the `show_version` label, changes). Old show-config hash `1d4e82bdc40571351f582aa0173ff55cf040f48bef7028fde958bd7b595c5683`; new `d1f022782d543d1b8d9a7fd3d56895b57ca1f2b8381457d84261508e75b36719` under `show-config-v1`. The launch template (quiet 8 / standard 10 / big 12 minutes) is untouched; the fixture `runtime_target` stays 240 s (`evaluation_fixture`); the nine authored block budgets (sum 330 s) are unchanged and no equality with the target is required.

### 2.3 Identity and hashes
- Every row that owns or references a fresh attempt is re-keyed by the frozen identity table (274 replacement rows, one new config row; two fresh root runs and two fresh attempts bound to the new config; fresh `program_block_id` values). Script words, participants, semantic anchors, block budgets, intent values, TTS preimages, render-context digests, WAV bytes and the assembly recipe are unchanged. Governed hashes that contain a fresh identity (Brief, writer view/context, scripts, craft review, four request/complete-manifest/semantic hashes, direction content hash, audit input/result, render manifest, assembly map, six stage fingerprints, READY candidate, revalidation result) are recomputed.
- This record deliberately contains no successor UUID allocation, no correction-input or sidecar digest and no corrected-output hash.

### 2.4 Correction fingerprint in the successor
- The corrected direction's `input_fingerprint` keeps the version 1 formula (`sha256("performance-direction-correction-input-v1\n" + canonical_json_bytes(P))`) with P re-bound to the successor: `source_direction_hash` is the unchanged historical source direction hash, `script_hash` is the successor final script content hash below, `adjudication_record_sha256` is the raw SHA-256 of this file, and `correction.source_scope_ref` is the successor turn UUID of final-script anchor t14 (the source intent id remains the archived historical intent). Direction content hashing still excludes the producer fingerprint.

### 2.5 Load profile and dependency order
- Corrected standalone offline load: 398 rows = 123 retained source rows + 275 fresh rows (274 replacements + 1 new show-config version). The accepted I2B v2 load (406 rows) is archived history and is never co-loaded; the old show-config row and the historical direction artifact are loaded only as history (parent / supersedes target); the historical direction version and its eight intents are archive-only.
- Dependency order: source/script re-keying and pre-execution verification → this frozen record → correction input bytes and fingerprint → corrected direction → audit → render → assembly → READY → revalidation.

## 3. Source bindings

- Repository: `/home/codespace/desk-v1.2.5-persistence-review/repository`, branch `hotfix/final-lock-v1.2.5-persistence-contract`, HEAD `1c85b4f07344cb6e03ec1619e3e059538d36ca3d` (clean, read-only).
- Accepted I2B v2 load SHA-256 `6f54ca4369f24b30720b8f980b3ba0515b6426913b03323f8ad6b58c9cee8ab0`; accepted I2C v2 ZIP SHA-256 `d479f947187eae58d93f08e4f566fcb68e5b8fa9ebfaf7852ce8e9812b994eff`.
- Version 1 record SHA-256 `3f8a760aa106e238d262132ab396cc3a99f71c72768a2f6a72b14c65bd7f78c3`; version 1 correction projection SHA-256 `2aaa8a5f2e0c6b56dcafff436051af9411c66bae69fb3744bb0ecba29808af5a`.
- Historical source direction content hash (unchanged): `ea5926e81267dd749cf33ed29564fe88815d3243b68260f1b4ddb96588e2f533`; its bound (accepted v2) final script content hash: `4b6bc58ac065979711c14a681450601e04cb7f2984fa276f0cc7f5b0459671dd`.
- Successor upstream content hashes (recomputed under the frozen table): brief_hash `36fb22d03300206d3181959a100f2911c2b27d9ff72379f21831d32a4bd5c475`, package_hash `a8655c0e8bd72094a823b367a0c21cd665d3d99c271341286a92dbdc2ea304ab`, scope_hash `ecb1eb2b675a9e383dfe88e6311f8cc88cc97eb17183df9a8cae935d8d1f8979`, script_pass1 `8085dc539f87ddff9064e6db2ae338c615ad822d58b94149209b259f7f552793`, script_craft_revision `f788e07dd1ccae557ad4d9b0f681e6905630ac25b76eca0a7f34a7670d2fe359`, **final script content hash `883cbe121635364f72072b29264f00af9b79eb32fd7ebd3d7e8462f829f50677`**, writing_craft_review `5435964dbc5674c1b198167d9bdaaf4ab654849170d1b01998dc90ce4b5864c5`.
- Pre-execution verification output `preexec/PREEXEC_VERIFICATION.json` raw SHA-256 `0ca338cb80cf9c5451e2a93ff6e4022710dfa4795c24b5b487aa8287143b9159`.

## 4. Pre-execution verification summary (14 checks, 14 passed, 0 failed)

- [PASS] `words-script_pass1` — all 17 spoken strings byte-equal to predecessor, to the accepted v2 script, and NFC
- [PASS] `anchors-script_pass1` — semantic anchors, order, participants and claim/evidence use spans equal the accepted v2 script
- [PASS] `words-script_craft_revision` — all 17 spoken strings byte-equal to predecessor, to the accepted v2 script, and NFC
- [PASS] `anchors-script_craft_revision` — semantic anchors, order, participants and claim/evidence use spans equal the accepted v2 script
- [PASS] `words-script_pass2` — all 17 spoken strings byte-equal to predecessor, to the accepted v2 script, and NFC
- [PASS] `anchors-script_pass2` — semantic anchors, order, participants and claim/evidence use spans equal the accepted v2 script
- [PASS] `brief-budgets-unchanged` — nine block budgets, runtime_target and purpose equal the accepted v2 Brief; sum 330 s
- [PASS] `config-single-edit` — new show-config payload differs from its parent only at configured_runtime_seconds.max (300 -> 330); hashes recompute
- [PASS] `identity-table` — frozen identity table SHA-256 equals the accepted binding; 283 distinct canonical v4 ids; none in the accepted v2 load; collision rescan clean
- [PASS] `preserved-hashes` — nine TTS base hashes, nine render-context digests, assembly recipe hash and twelve WAV audio hashes equal the accepted v2 values
- [PASS] `intent-values-unchanged` — eight corrected intent values equal the accepted v2 corrected direction (pace on t14 = slower); the historical source value measured is untouched in the retained historical artifact
- [PASS] `source-direction-hash` — historical source direction hash reconstructed from the I2A source direction bound to the accepted v2 final script
- [PASS] `proof-rerun` — tools/rerun_proofs.py (independent proof, plan checks, minimality audit) passed against the pinned source workspace before any successor byte was written
- [PASS] `v2-bindings` — accepted I2B v2 load, I2C v2 ZIP, plan transfer and inventory bindings verified at execution start

## 5. Not claimed

No I2C acceptance, activation, Migration 002, production or live-provider fidelity, human semantic override or database execution is claimed.
