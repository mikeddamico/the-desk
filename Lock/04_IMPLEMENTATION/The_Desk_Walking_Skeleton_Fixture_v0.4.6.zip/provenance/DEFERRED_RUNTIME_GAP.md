# Deferred runtime-contract gap: repeated-manifest cached-take ownership

Status: CONFIRMED, DEFERRED. This fixture neither implements nor proves the runtime behavior described here.

## The gap

P&R keeps an unchanged block's take reusable across manifests (an unchanged `base_request_hash` should let a later manifest
reuse or append to the existing take rather than call the provider again). Foundation 001 as constrained cannot express that
path for a *repeated* manifest:

- `render_takes.provider_call_id` is UNIQUE, so a second manifest's block cannot own a new take that reuses the same
  provider call (the reuse would need a second take row pointing at one call).
- A take is bound to one `render_block_id`; the composite block/take foreign key on `take_selections` prevents attaching an
  existing take to a different manifest's block selection.
- A duplicate try-1 reservation for an unchanged logical request collides on the provider-call uniqueness guard, and
  a successful-retry constraint prevents inventing a retry or a second reservation to work around it.

So the claimed append/reuse path (P&R 25/28: a future manifest encountering the same base request uses the current approved take)
is blocked by the existing schema constraints.

## What this fixture does about it

- It is a **fresh offline fixture load**, not an incremental repair of a populated READY database. The 85 superseded source
  downstream rows are archive-only and are not co-loaded, so no duplicate reservation, take, or selection exists.
- rb01's content identity is unchanged by the correction (its base request hash is the same under the source and
  successor profiles); it is *not* altered to evade the constraint, and no retry, reservation, or child execution is invented.
- Existing provider-call and block/take uniqueness constraints are unchanged.

## Required later acceptance test (not implemented here)

A runtime/Migration-002 acceptance test must, against a populated database that already holds a manifest M1 with an approved
take T for block B (base hash X):

1. build a second immutable manifest M2 with a block B' whose resolved base request hash is also X;
2. show the system resolves B' to the existing approved take T **without** a second provider call, a duplicate try-1
   reservation, or a fabricated retry, and records a lawful ownership/selection for B' that survives the provider-call
   `UNIQUE` constraint and the block/take composite foreign key;
3. show a changed hash (for example a context or intent change) still produces a fresh reservation and take;
4. show concurrent workers converge on one paid call.

The contract question (which table owns cross-manifest take reuse) must be resolved **before** any implementation or any claim
of this runtime cache behavior. Do not resolve it by editing rb01's hash, duplicating a reservation, or relaxing uniqueness.

## Limits of the evidence

This fixture does not prove cached-take behavior, database constraint execution, concurrency, or provider fidelity.
