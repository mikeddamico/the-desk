# Runtime-budget gate resolution (CONFIG-330)

The I2C R2 finding (history: `provenance/history/RUNTIME_BUDGET_FINDING_i2c_r2.md`) recorded that the nine authored block budgets sum to **330 s** while the accepted
fixture show configuration carried the band `{min 60, max 300, fixture_override true}`, and that Showrunner Planning v0.1.3 section 23 gate 7 ("planned blocks fit
the configured runtime range/tolerance") defines no tolerance. The 240 s Brief `runtime_target` and the 60-300 s band are synthetic evaluation-fixture values, not
product runtime policy: the launch template is quiet 8 / standard 10 / big 12 minutes (`fixture_override_allowed true`) and is unchanged.

**Resolution (supervisory decision, executed here):** the fixture show configuration is corrected by a new immutable `show_config_versions` version (version 2,
parent = version 1) whose only change is `configured_runtime_seconds.max` 300 -> 330. Version 1 stays as immutable history. The authored budgets (sum 330 s), the 240 s
`runtime_target` (`evaluation_fixture`), the script words, participants, intent values, TTS preimages, render-context digests, WAV bytes and the assembly recipe are unchanged.
Because attempts bind a configuration immutably and every attempt-owned row is immutable, the corrected standalone load re-keys 274 rows by the frozen identity table and
recomputes the governed hashes that contain a fresh identity.

G32 now validates the authored 330 s sum against the corrected band `[60, 330]` with the only governed tolerance (0); it **never** requires equality with `runtime_target`.
No tolerance and no product rule was invented. The superseded inherited "unresolved base gate" classification no longer applies: a G32 failure is an ordinary failure.
