# R2-C runtime-budget finding (inherited planning data)

**Gate: Showrunner Planning v0.1.3 s23 gate 7 "Runtime budget: planned blocks fit the configured runtime range/tolerance" - UNRESOLVED / FAIL. NOT a deterministic pass.**

Status of this document: decision record of the I2C R2 executor for the supervising assistant. No semantic datum was changed; no tolerance was invented; no Mike approval is requested.

## 1. Lineage of the values (identical in all three accepted stages)

| Stage | Path | SHA-256 | Nine block targets (s) | Sum (s) | `runtime_target` |
|---|---|---|---|---:|---|
| predecessor v0.4.4 Brief | `inputs/predecessor_v0.4.4/showrunner_brief.json` | `a8d93218cbb444940951669d675dbcf789d4984cbd33842e29767729aa20b690` | 30, 30, 30, 60, 30, 60, 30, 30, 30 | **330** | {"seconds": 240, "purpose": "evaluation_fixture"} |
| I2A authored Brief | `authored/showrunner_brief.json` | `e89575ca1630edef2ff64cbb323245677b421d7b7a6da6898953feb2c33778da` | 30, 30, 30, 60, 30, 60, 30, 30, 30 | **330** | {"purpose": "evaluation_fixture", "seconds": 240} |
| accepted I2B v2 Brief member | `i2b-corrected-406-v2/members/showrunner_brief.json` | `3d069618d3efa692bc8f51918816c2cf41f5f54d870dda0ee583127654274e6d` | 30, 30, 30, 60, 30, 60, 30, 30, 30 | **330** | {"purpose": "evaluation_fixture", "seconds": 240} |

| Stage | Path | `configured_runtime_seconds` |
|---|---|---|
| predecessor config/show.json | `inputs/predecessor_v0.4.4/config/show.json` | `{"fixture_override": true, "max": 300, "min": 60}` |
| I2A config/show.json | `authored/config/show.json` | `{"fixture_override": true, "max": 300, "min": 60}` |
| accepted v2 config_show_version member | `i2b-corrected-406-v2/members/config_show_version.json` | `{"fixture_override": true, "max": 300, "min": 60}` |

The values were authored in predecessor Fixture v0.4.4 and preserved byte-for-byte through I2A, accepted I2B v2 and the I2C candidate. They were not introduced by I2C.

## 2. Arithmetic

* Sum of the nine `program_blocks[].target_duration_or_words.seconds` = 30+30+30+60+30+60+30+30+30 = **330 s**.
* Configured band (fixture override) = [60, 300] s. Sum minus band maximum = 30 s (10.0% of the maximum). Sum is above the band maximum.
* `runtime_target.seconds` = 240 s is inside the band, but it is a separate field: the block budgets (sum 330 s) exceed it by 90 s (37.5%) and exceed the band maximum by 30 s.
* Smallest symmetric tolerance that would admit the sum against the band maximum: 30 s (10.0% of 300 s). **No source states any tolerance**, so this number is arithmetic, not a rule.
* Selected template `post-event-launch-v2` (`config/rundown_template_post_event_launch_v2.json`, sha256 `4c74bc6563680d907233921333a6528463ec5819a2375786ba77efbb15e3a9f6`): runtime `{quiet 8, standard 10, big 12}` minutes and `fixture_override_allowed: true`; required slots carry `target_words_standard` summing to 1250 words (optional `quick_hits` 120 excluded). The Boolean override permits a synthetic configured band; the band itself is [60, 300] s.

## 3. Search for an explicit applicable tolerance / profile disposition (none found)

| Source | Finding |
|---|---|
| `02_ACTIVE_SPECS/The_Desk_Showrunner_Planning_v0.1.3.md` | Line 668 "Writing may vary within configured tolerance" (scripts vs budgets; no value). Gate 7 (line 954) "fit the configured runtime range/tolerance" - refers to a configuration that supplies no tolerance. s14: target "inside the configured band"; budgets are coarse. "Build-2 executable examples" = the v0.4 template/registries. |
| `02_ACTIVE_SPECS/The_Desk_Performance_and_Render_v0.1.4.md` | Lines 1387-1391 "duration is sane relative to the planned runtime tolerance" / "within tolerance": validation of AUDIO, no value, and not the planning gate. |
| `Writing 0.2.3, Character Bible 0.1.4, Evidence Package 0.2.2, Claims 0.1.2, Operator Repair 0.1.1, ADR-003A, Architecture Desk_v10, Coding Handoff v0.5.3, Contract Trace v0.5.3, Hashing v0.1.4` | No tolerance, runtime band, `fixture_override` or `evaluation_fixture` disposition. |
| `inputs/predecessor_v0.4.4 (README, expected_invariants.json, validate_fixture.py, config/*)` | No runtime-budget check and no tolerance. `fixture_override` appears only as the Boolean in the show config and `fixture_override_allowed` in the template. |
| `I2A/I2B records, frozen technical resolution record, audit report, supervisory adjudications available to the executor` | No disposition of the budget relationship. |

Exact-text hash of the governing spec searched: `The_Desk_Showrunner_Planning_v0.1.3.md` sha256 `8a658b976a3c9d73bb2e039655ab4016af867b919d906bbc07aef286555b7367` (Lock path `02_ACTIVE_SPECS/`).

**Conclusion:** no previously governing rule resolves the relationship; the Boolean `fixture_override` does not state a tolerance or authorise ignoring the band maximum; the short synthetic WAVs are irrelevant to the planning relationship. The gate is recorded **UNRESOLVED/FAIL**. It is implemented in the portable validator as group `G32_runtime_budget`, executed on every run, and keeps the full conformance verdict NON-PASSING. It is not excluded from the claim and not moved to an unexecuted document.

## 4. What a later semantic correction would change (saved for the supervising assistant; NOT implemented, no UUID allocated)

Two independent places could carry a correction. Which (if either) is governed is a technical adjudication not made here.

### 4a. Correct the Brief (block budgets and/or `runtime_target`) - large blast radius
* Changes the governed `showrunner-brief-v1` projection (`program_blocks`, `runtime_target` are in the semantic projection) -> Brief `brief_hash` `a686ae9a75d9f8e03b82d44d88a4cefc5f565eaf1338c5b1334bd3cc49c14f24` -> artifact `d1250005-0000-4000-8000-000000000001` content hash; `program_blocks.semantic_payload` rows (if budgets change).
* Direct consumers of the literal Brief hash in the accepted data (computed by scan): artifacts `...0001` Brief, `...0002` script pass 1, `...0004` craft revision, `...0005` final script, `...0008` craft-critic manifest, `...0019` writer view, fresh semantic-audit result carrier; plus request specimens, `writer_data_input.bytes`, six stage-fingerprint projections (claims_writing, semantic_audit directly), frozen `technical_resolution_record_v1.md` (text contains the hash) and `PREEXEC_VERIFICATION.json`.
* Transitive chain: writer view hash -> serialized input hash -> writer context manifest -> prompt manifests 2-5 (input hashes) -> rendered request bytes/raw hashes -> typed prompt rows -> model semantic-input hashes -> model `provider_calls.request_fingerprint`/`logical_request_key`; script-v2 projection (includes `brief_hash`) -> all three script hashes -> `revision_parent_content_identity` (script_versions) -> craft review subject hash; performance-direction hash and the correction-input projection/fingerprint (bind script hash) -> frozen correction ancestry and the frozen record (a NEW frozen-record version would be required); audit input fingerprint -> audit result, `audit_runs`; render manifest hash; gate fingerprints for claims_writing (36 rows), performance (14), semantic audit, render (8); identity registry, obligation reconciliation.
* Unchanged by a Brief-only correction: evidence/claims/package hashes, the 12 WAV bytes, TTS base projections (no script/brief hash in the eleven fields), request-to-response mapping, assembly recipe/map hashes, READY/show-config hash.

### 4b. Correct only the show configuration band (`configured_runtime_seconds`) - small blast radius, but contradicts "do not alter the band"
* Changes `show-config-v1` hash `1d4e82bdc40571351f582aa0173ff55cf040f48bef7028fde958bd7b595c5683` -> `show_config_versions.config_hash` and the config member; READY candidate projection (`show_config_version_hash`) -> READY candidate fingerprint `5179590fc930db43078ca00485dcd05d619761f48c4e1bf281786b7a22344267` -> revalidation-result artifact hash, `ready_expectations`, the retention-repair provenance constants.
* Nothing else depends on the band value.

### 4c. Alternatively an already-authorised explicit tolerance/profile rule
Would change no datum, but it must be a cited governing text or an adjudicated rule; none exists today.

## 5. Executor disposition

* Semantic data, UUIDs and identities: untouched. No tolerance invented. No numbers reinterpreted.
* `G32_runtime_budget` reports the observed inconsistency (sum 330 s vs band [60, 300] s, tolerance: none governed) as a FAIL of the BASE planning data and is distinguished in results from negative-test outcomes and harness errors.
* The check is exercised for discrimination only on mutated in-memory copies (e.g. a band maximum of 330 s or a block target lowered by 30 s would pass); those runs are labelled test-harness behaviour and do not change the verdict on the accepted data.
* Return to the supervising assistant: choose 4a, 4b or 4c (or a governed resolution); until then I2C acceptance is blocked by this gate.
