# The Desk - Frozen Walking-Skeleton Fixture v0.4.4

**Status:** ACTIVE EXECUTABLE CONTRACT FOR BUILD 1-2  
**Date:** September 28, 2026  
**Supersedes:** v0.4.3

This corrective fixture closes the implementation blockers found in the independent Codex and Claude dry runs without reopening Technical Architecture v1.0.

Key corrections:

- valid evidence-axis enums with `origin` kept separate from `source_role`;
- all nine required `post-event-launch-v2` slots represented in the Brief;
- required-attribution claims attributed on every spoken use;
- valid RFC 3339 timestamps and complete immutable repair request/plan/decision shapes;
- stage-specific gate fingerprints instead of binding SCRIPTED gates to later Performance Direction;
- explicit Unicode code-point span vectors;
- deterministic fixture TTS bytes and a materialized clean master;
- separate evaluation and production-purpose/publication-disabled review paths;
- a real READY candidate, Episode/GUID, durable review wait, and fixture revalidation result;
- confirmed READY repairs fork child attempts;
- one named mechanical reroll with durable trigger;
- `provider_calls` as the authoritative external-call/cost ledger;
- minimum fixture-grade claims/evidence/support/model/account records;
- writer payload no longer carries forbidden claim/evidence IDs.

Current canonical identities:

- Evidence Package: `22fa7218e2f820b3c3378fc083eae52d1a0b0259c43fcf555f9115afed4d0457`
- Showrunner Brief: `858e3029d17e490dd8b34f21905f21bf6e5b0daa508a44964097c8030ed6042c`
- Writer view: `27f397746133d7a3a8a32e613350a2d71231fefbc56a201a99ad8cd6f0d511d4`
- Pass 1: `2c28691be4a16c0bd5939459e1a31f783d35ddd860bad4713a514d0df8ec86fd`
- Craft review: `87fdfb0f4e8e4cd693cc4d4c10fd936694914400d3f2bd6d8e639011f3687717`
- Craft revision: `9f28c3618a792467637a70dad312738f64337d09332341c20a8339cc99168076`
- Final speech-texture script: `d6fca2178d65139b935157e28b1af01426ba9a00bbe7304824e5ac7a8125a830`
- Performance Direction: `2e613ae6c99851cad12171347cb11616dd2bbecb7e4e2083ac2dfb0aa0b6a454`
- Claims/Writing gate fingerprint: `a56625ab7885982feb59c2b9661f7048aac8882bee646c871d511e7ea5404821`
- Performance gate fingerprint: `2b8d739aa58d4721daf75ef7e72594994c80ddeb9d00d677114ee7ced5b7c761`
- Semantic audit input fingerprint: `de4e027bd6d8599ecc047745023fe2545e0fcbdaace645528f7d99902f338657`
- Render Manifest: `a018bfd689e78041edd60795ed2131bdc0eeb8abfd9ae065affef5d23ed21a76`
- Render gate fingerprint: `d92d620c8e60098e750bea6c490a85f7ca71d27994e90cb9e247bc8072241b37`
- Clean master SHA-256: `a7ecd855ef8a9100b4252fadfadf366efb866b72a060e9484f64002568354d73`
- Assembly gate fingerprint: `dd20eb19b78bea075369ebc04db438928ab272986bd3d062904604b069a84518`
- READY candidate fingerprint: `76e7e59ba2d6c21ed152afdc9b8781151fa9caadffa9dc9471ae2caf57bd06c6`

The primary artifact-writing chain is still built under the evaluation attempt and stops at VALIDATED for lifecycle purposes. The production-purpose review attempt reuses the exact immutable content-addressed artifacts, obtains its own gate/review lineage, enters READY, and remains publication-disabled.

No file grants live-search authority. Fixture audio is synthetic test material, not a product voice.


## v1.2.4 executable-contract hotfix

Triggered by the read-only Completion A persistence design pass, this bounded hotfix repairs fixture run/attempt identities to authoritative Foundation UUIDs, completes explicit deterministic `fixture_stub` model provenance, and closes the previously unspecified `model_runs.semantic_input_hash` projection/domain via Hashing v0.1.3.

Foundation UUID primary keys remain the durable run/attempt identities; no canonical-identity columns or permanent alias system are introduced. Each of the five intended typed model executions has a purpose-specific prompt manifest, explicit component versions and policy source hashes, rendered-request and semantic-input hashes, a synthetic provider-call reservation, one succeeded terminal event, zero actual USD cost, fixture model identity, and an output-artifact binding. No external provider was contacted or paid. `provider_calls` remains the authoritative side-effect/try ledger; production provider-accounting semantics are unchanged.

There is no database/schema, migration, lifecycle, product-intent, dependency, or product-implementation change. No unrelated semantic projection changes. Build 1 and Build 2 scope does not broaden; this hotfix does not begin Build 1 Completion A. Technical Architecture v1.0 and accepted ADRs remain unchanged. The Product Thesis remains working product context, outside locked implementation authority.

Only the READY candidate fingerprint changes among the six stage fingerprints, from `c9ec6c12015993af3199054429b82cc37c0c692dd259df51319e5d41e34b41ce` to `76e7e59ba2d6c21ed152afdc9b8781151fa9caadffa9dc9471ae2caf57bd06c6`. Governed upstream semantic artifact identities are unchanged. The five model semantic-input hashes are additive provenance identities.

## Deterministic model provenance

The five `fixture_stub/model-v1` executions are synthetic deterministic fixture executions only. `fixture_model_requests.json` preserves exact UTF-8 rendered request strings; SHA-256 of each string is the prompt manifest rendered-request hash. These fixture recipes request the corresponding frozen output without claiming a live model generated it. Input references bind semantic hashes and remain untrusted data. The output binding lives in `model_runs.json` / `model_output_artifacts.json`, outside semantic-input identity.

`provider_calls.json` adds five immutable model-call reservations; `provider_call_events.json` supplies exactly one succeeded, zero-USD terminal event per new reservation. Existing fixture TTS records retain their earlier representation. `model_output_artifacts.json` explicitly binds Foundation artifact UUIDs to fixture members and existing content hashes; these are output artifact records, not run/attempt aliases. Future loaders must use the supplied provenance, never fabricate missing provenance.

## Validation

From the repository root, extract only the validator to a temporary path and run:

```sh
unzip -p Lock/04_IMPLEMENTATION/The_Desk_Walking_Skeleton_Fixture_v0.4.4.zip validate_fixture.py > /tmp/validate_fixture_v044.py
python3 /tmp/validate_fixture_v044.py
```

The exact ZIP member inventory is `fixture_inventory.json` (including itself). The validator also verifies the immutable Lock pack against `PACK_MANIFEST.json`.

## Fixed run/attempt identities

- run_fixture_eval_001: `11111111-1111-4111-8111-111111111111`
- run_fixture_review_001: `11111111-1111-4111-8111-111111111112`
- attempt_fixture_eval_001: `22222222-2222-4222-8222-222222222221`
- attempt_fixture_review_001: `22222222-2222-4222-8222-222222222222`
- attempt_fixture_review_002: `22222222-2222-4222-8222-222222222223`
- attempt_fixture_review_003: `22222222-2222-4222-8222-222222222224`
