"""Frozen v0.4.4 conformance; standard-library only; run from repository root."""
from pathlib import Path
import copy
import hashlib
import json
import unicodedata
import uuid
import zipfile

ROOT = Path.cwd()
LOCK = ROOT / 'Lock'
ZIP = LOCK / '04_IMPLEMENTATION/The_Desk_Walking_Skeleton_Fixture_v0.4.4.zip'
OLD = LOCK / '04_IMPLEMENTATION/The_Desk_Walking_Skeleton_Fixture_v0.4.3.zip'
READY = '76e7e59ba2d6c21ed152afdc9b8781151fa9caadffa9dc9471ae2caf57bd06c6'
FIELDS = ('component_versions', 'policy_source_hashes', 'rendered_request_hash')

def canonical(value):
    def normalize(x):
        if isinstance(x, str):
            x.encode('utf-8')
            return unicodedata.normalize('NFC', x)
        if isinstance(x, list):
            return [normalize(v) for v in x]
        if isinstance(x, dict):
            result = {}
            for k, v in x.items():
                assert isinstance(k, str)
                key = normalize(k)
                assert key not in result, 'NFC duplicate key'
                result[key] = normalize(v)
            return result
        assert x is None or type(x) in (int, bool), 'Non-semantic JSON value'
        return x
    return json.dumps(normalize(value), ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def domain_hash(domain, value):
    return sha((domain + '\n' + canonical(value)).encode())

def project_model(manifest):
    return {k: manifest[k] for k in FIELDS}

def model_hash(manifest):
    return domain_hash('model-semantic-input-v1', project_model(manifest))

def without(value, keys):
    return {k: copy.deepcopy(v) for k, v in value.items() if k not in keys.split()}

def walk(value):
    if isinstance(value, dict):
        yield value
        for v in value.values():
            yield from walk(v)
    elif isinstance(value, list):
        for v in value:
            yield from walk(v)

def valid_uuid(value):
    assert str(uuid.UUID(value)) == value

with zipfile.ZipFile(ZIP) as z, zipfile.ZipFile(OLD) as old:
    assert z.testzip() is None
    names = z.namelist()
    assert len(names) == len(set(names))
    def read(name):
        return json.loads(z.read(name))
    assert sorted(names) == read('fixture_inventory.json')['members']
    assert set(names) == set(old.namelist()) | {'provider_call_events.json', 'fixture_model_requests.json', 'model_output_artifacts.json', 'model_semantic_input_conformance.json', 'validate_fixture.py', 'fixture_inventory.json'}
    documents = {n: read(n) for n in names if n.endswith('.json')}
    context = read('run_context.json')
    runs = {r['program_run_id']: r for r in context['program_runs']}
    scenarios = read('operator_repair_examples.json')['scenarios']
    attempts = {r['attempt_id']: r for r in context['program_run_attempts'] + [s['child_attempt'] for s in scenarios]}
    assert set(runs) == {'11111111-1111-4111-8111-111111111111', '11111111-1111-4111-8111-111111111112'}
    assert set(attempts) == {f'22222222-2222-4222-8222-22222222222{i}' for i in range(1, 5)}
    for identity in [*runs, *attempts]:
        valid_uuid(identity)
    for name, doc in documents.items():
        if name == 'model_semantic_input_conformance.json':
            continue  # Deliberately malformed excluded metadata is a stability vector.
        for row in walk(doc):
            for k, v in row.items():
                if k == 'program_run_id' and v is not None:
                    assert v in runs, (name, k, v)
                if k in ('attempt_id', 'parent_attempt_id', 'source_attempt_id', 'ready_attempt_id') and v is not None:
                    assert v in attempts, (name, k, v)
                if k in ('ready_candidate_fingerprint', 'source_ready_candidate_fingerprint', 'source_ready_fingerprint'):
                    assert v == READY, (name, k, v)
            if row.get('program_run_id') and row.get('attempt_id'):
                assert attempts[row['attempt_id']]['program_run_id'] == row['program_run_id']
    for s in scenarios:
        child = s['child_attempt']
        assert child['parent_attempt_id'] == '22222222-2222-4222-8222-222222222222'
        assert child['repair_plan_id'] == s['repair_plan']['repair_plan_id']
        assert child['repair_request_id'] == s['repair_request']['repair_request_id']
        assert s['repair_plan_decision']['decision'] == 'confirm'
    assert scenarios[0]['child_attempt']['attempt_id'].endswith('223')
    assert scenarios[1]['child_attempt']['attempt_id'].endswith('224')
    assert read('pre_publish_review.json')['attempt_id'] == read('episode_ready.json')['ready_attempt_id']
    stages = read('gate_fingerprint_inputs.json')['fingerprints']
    original_stages = json.loads(old.read('gate_fingerprint_inputs.json'))['fingerprints']
    assert len(stages) == 6
    for stage, v in stages.items():
        assert domain_hash(v['domain'], v['input_projection']) == v['expected_hash'], stage
        if stage != 'ready_candidate':
            assert v == original_stages[stage]
        else:
            assert v['expected_hash'] == READY
    print('PASS ZIP inventory, UUID/run/attempt/READY/review/repair references, six stage fingerprints')

    models = read('model_runs.json')['model_runs']
    manifests = {v['prompt_manifest_id']: v for v in read('prompt_manifests.json')['prompt_manifests']}
    requests = {v['prompt_manifest_id']: v for v in read('fixture_model_requests.json')['requests']}
    calls = read('provider_calls.json')['provider_calls']
    stub_calls = {v['provider_call_id']: v for v in calls if v['provider'] == 'fixture_stub'}
    events = read('provider_call_events.json')['provider_call_events']
    outputs = {v['artifact_id']: v for v in read('model_output_artifacts.json')['artifacts']}
    expected = [('showrunner_planner', 'showrunner_brief.json', 'planner_model_run_id'), ('writer', 'script_pass1.json', 'writer_model_run_id'), ('craft_critic', 'writing_craft_review.json', 'critic_model_run_id'), ('writer_revision', 'script_craft_revision.json', 'writer_model_run_id'), ('speech_texture', 'script_pass2.json', 'writer_model_run_id')]
    assert len(models) == len(manifests) == len(requests) == len(stub_calls) == len(events) == len(outputs) == 5
    assert len({m['model_run_id'] for m in models}) == 5
    assert len({m['provider_call_id'] for m in models}) == 5
    for m, (kind, member, model_field) in zip(models, expected):
        for k in ('model_run_id', 'attempt_id', 'provider_call_id', 'prompt_manifest_id', 'output_artifact_id'):
            valid_uuid(m[k])
        assert m['run_kind'] == kind and m['execution_mode'] == 'fixture_stub'
        pm = manifests[m['prompt_manifest_id']]
        assert pm['purpose'] == kind and pm['component_versions'] and pm['policy_source_hashes']
        assert pm['component_versions']['fixture_prompt'] == kind + '-fixture-v1'
        req = requests[m['prompt_manifest_id']]['rendered_request']
        assert sha(req.encode()) == pm['rendered_request_hash']
        assert json.loads(req)['purpose'] == kind
        assert m['semantic_input_hash'] == model_hash(pm)
        call = stub_calls[m['provider_call_id']]
        assert call['attempt_id'] == m['attempt_id']
        assert call['operation'] == kind
        assert call['model_identifier'] == m['model_identifier'] == 'fixture_stub/model-v1'
        assert call['request_fingerprint'] == pm['rendered_request_hash']
        assert call['operational_try_number'] == 1 and call['intentional_take_index'] is None
        assert call['retry_of_provider_call_id'] is None and call['reroll_of_provider_call_id'] is None
        terminal = [e for e in events if e['provider_call_id'] == call['provider_call_id']]
        assert len(terminal) == 1
        e = terminal[0]
        valid_uuid(e['provider_call_event_id'])
        assert e['event_type'] == 'succeeded' and e['actual_cost'] == '0.0000' and e['currency'] == 'USD'
        assert e['usage']['external_provider_contacted'] is False
        assert e['response_artifact_id'] == m['output_artifact_id']
        assert outputs[m['output_artifact_id']]['member'] == m['output_artifact_ref'] == member
        assert read(member)[model_field] == m['model_run_id']
        print(kind, m['semantic_input_hash'])
    assert [c for c in calls if c['provider'] != 'fixture_stub'] == json.loads(old.read('provider_calls.json'))['provider_calls']
    v = read('model_semantic_input_conformance.json')
    assert model_hash(v['baseline_manifest']) == v['baseline_hash']
    for row in v['vectors']:
        assert project_model(row['manifest']) == row['expected_projection']
        assert model_hash(row['manifest']) == row['expected_hash']
        assert ('same' if row['expected_hash'] == v['baseline_hash'] else 'different') == row['expected_relation_to_baseline']
    assert len(v['vectors']) == 24
    print('PASS five explicit model provenances and 24 semantic-input sensitivity/stability vectors')

    conformance = read('artifact_hash_conformance.json')
    original_conformance = json.loads(old.read('artifact_hash_conformance.json'))
    for k, value in conformance.items():
        if k != 'ready_candidate':
            assert value == original_conformance[k], k
    # Owning semantic projections, with the exclusions clarified by Hashing §§2,4.
    projections = {}
    projections['package'] = read('evidence_package.json')['manifest']
    projections['brief'] = without(read('showrunner_brief.json'), 'showrunner_brief_version_id program_run_id attempt_id purpose evidence_package_id planner_model_run_id created_at revision_parent_id revision_reason brief_hash')
    projections['writer_view'] = without(read('writer_view.json'), 'script_request_id writer_view_hash')
    projections['writer_context_manifest'] = without(read('writer_context_manifest.json'), 'writer_context_manifest_hash')
    parent = None
    for key in ('script_pass1', 'script_craft_revision', 'script_pass2'):
        p = without(read(key + '.json'), 'script_version_id program_run_id attempt_id purpose showrunner_brief_version_id evidence_package_id writer_model_run_id created_at revision_parent_id revision_reason script_phase script_hash finding_refs')
        p['turns'] = [without(t, 'sequence') for t in p['turns']]
        if parent:
            p['revision_parent_content_identity'] = parent
        projections[key] = p
        parent = conformance[key]['expected_hash']
    p = without(read('writing_craft_review.json'), 'writing_craft_review_id subject_script_version_id critic_model_run_id created_at review_hash')
    p['findings'] = [without(f, 'finding_id') for f in p['findings']]
    projections['writing_craft_review'] = p
    projections['performance_direction'] = without(read('performance_direction.json'), 'performance_direction_version_id script_version_id producer_run_id actor created_at direction_hash input_fingerprint')
    p = without(read('render_manifest.json'), 'render_manifest_id script_version_id performance_direction_version_id audit_run_id created_at manifest_hash')
    p['render_blocks'] = [without(b, 'sequence render_block_id state') for b in p['render_blocks']]
    projections['render_manifest'] = p
    projections['assembly_recipe'] = without(read('assembly_recipe.json'), 'assembly_recipe_hash')
    projections['master_assembly_map'] = without(read('master_assembly_map.json'), 'master_assembly_map_hash')
    for key, projection in projections.items():
        actual = domain_hash(conformance[key]['domain'], projection)
        assert actual == conformance[key]['expected_hash'], (key, actual, conformance[key]['expected_hash'])
    package = read('evidence_package.json')
    package['created_at'] = '2030-01-01T00:00:00Z'
    package['frozen_at'] = '2030-01-02T00:00:00Z'
    assert domain_hash('evidence-package-v2', package['manifest']) == conformance['package']['expected_hash']
    for out in outputs.values():
        key = 'brief' if out['member'] == 'showrunner_brief.json' else out['member'][:-5]
        assert out['content_hash'] == conformance[key]['expected_hash']
    print('PASS all governed semantic artifact hashes and package timestamp invariance')

    fields = 'concrete_model_identity adapter_render_contract_version immutable_voice_profile_version_render_fields speaker_map resolved_generation_settings canonical_spoken_text approved_performance_intents bounded_render_context render_facing_persona_or_scene_config applied_pronunciation_rendering_versions named_text_transform_versions'.split()
    def base_projection(value):
        return {k: value[k] for k in fields}
    def base_hash(value):
        return 'v1:' + sha(canonical(base_projection(value)).encode())
    base = read('base_request_hash_conformance.json')
    assert base_projection(base['baseline_input_record']) == base['baseline_projection']
    assert base_hash(base['baseline_input_record']) == base['baseline_hash']
    assert len(base['vectors']) == 9
    for v in base['vectors']:
        assert base_projection(v['input_record']) == v['expected_projection']
        assert base_hash(v['input_record']) == v['expected_hash']
        assert ('same' if v['expected_hash'] == base['baseline_hash'] else 'different') == v['expected_relation_to_baseline']
    render = read('render_request_projections.json')['projections']
    assert len(render) == 9
    for v in render:
        assert base_hash(v['projection']) == v['base_request_hash']
    unicode = read('unicode_conformance.json')
    assert canonical(unicode['key_order_input']) == unicode['canonical_json_utf8']
    for v in unicode['span_vectors']:
        assert unicodedata.normalize('NFC', unicode['spoken_text'])[v['start']:v['end']] == v['substring']
    for p in read('config/policy_versions.json')['policies'].values():
        assert sha((LOCK / p['source_path']).read_bytes()) == p['source_sha256']
    policies = read('config/policy_versions.json')['policies']
    for pm in manifests.values():
        for key, source_hash in pm['policy_source_hashes'].items():
            assert source_hash == policies[key]['source_sha256']
            assert pm['component_versions'][key] == policies[key]['version_id']
    for a in read('audio_artifacts.json')['artifacts']:
        assert sha(z.read(a['path'])) == a['sha256']
    master = read('master_artifact.json')
    assert sha(z.read(master['path'])) == master['content_hash'] == conformance['master_audio_sha256']
    print('PASS 9 base-request vectors, 9 render baselines, Unicode, policy sources, audio and clean master')

manifest = json.loads((LOCK / '00_INDEX/PACK_MANIFEST.json').read_text())
assert manifest['pack_version'] == '1.2.4'
actual_paths = {p.relative_to(LOCK).as_posix() for p in LOCK.rglob('*') if p.is_file() and p.name != 'PACK_MANIFEST.json'}
assert actual_paths == {r['path'] for r in manifest['files']}
assert manifest['file_count'] == len(actual_paths) == len(manifest['files'])
for row in manifest['files']:
    data = (LOCK / row['path']).read_bytes()
    assert len(data) == row['size_bytes'] and sha(data) == row['sha256']
print('PASS exact PACK_MANIFEST inventory; ZIP SHA-256', sha(ZIP.read_bytes()))
