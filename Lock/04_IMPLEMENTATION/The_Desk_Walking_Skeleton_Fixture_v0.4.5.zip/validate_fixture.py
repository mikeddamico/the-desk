#!/usr/bin/env python3
"""The Desk - Walking-Skeleton Fixture v0.4.5 (CANDIDATE) - portable independent final validator.

Standard library only. Reads ONLY the pack it is pointed at (a ZIP read in place, or an unpacked directory that it never
repairs, chmods or rewrites). It opens no path under /home, no repository, no Git, no unshipped predecessor and no external
scratch directory, and it imports no author/generator code: every projection, hash and identity below is re-derived here
from the pack's own immutable inputs and compared with the stored values; it never trusts a stored hash.

Lineage: the G02-G21 group logic is the reviewed I2B independent validator (validate_i2b.py, accepted with checkpoint
corrected-406 v2) ported to read the packaged layout and, for the CONFIG-330 corrected successor, to re-key the preserved I2A source
through the composed identity correspondence before every hash is recomputed (G34 and the G03/G08/G13/G15/G19/G21 successor rules are new). G01 (VM Git/workspace integrity) is NOT part of a package validator:
it is reported as NOT_APPLICABLE_IN_PACKAGE and is never counted as a pass. New groups G22-G28 cover package integrity,
reference resolution, prospective policy/authority binding, complete-manifest acceptance, and the executable vectors.

Usage:
  validate_fixture.py PACK.zip | --dir FOLDER   [--self-test] [--json OUT] [--expect-zip-sha256 HEX]
                                               [--expect-pack-members-sha256 HEX]
Exit status 0 only when every executed check behaves as expected (no skips, no harness errors, no escapes).
"""
import argparse
import ast
import collections
import copy
import hashlib
import io
import json
import os
import re
import stat
import sys
import types
import unicodedata
import uuid
import warnings
import wave
import zipfile

VALIDATOR_VERSION = 'fixture-v0.4.5-config330-candidate-validator-1'
STDLIB_ALLOWED = {'argparse', 'ast', 'collections', 'copy', 'hashlib', 'io', 'json', 'os', 're', 'stat', 'sys', 'types', 'unicodedata',
                  'uuid', 'warnings', 'wave', 'zipfile', 'time', 'platform', 'zlib', 'itertools', 'functools'}

# ------------------------------------------------------------------ packaged layout (logical name -> member path)
PATH = {
    'load': 'foundation_rows_398.json', 'requests': 'fixture_model_requests.json',
    'record': 'provenance/frozen/technical_resolution_record_v2.md', 'corr': 'provenance/frozen/correction_input_projection.json',
    'record_v1': 'provenance/frozen/i2b_v2/technical_resolution_record_v1.md', 'corr_v1': 'provenance/frozen/i2b_v2/correction_input_projection_v1.json',
    'preexec': 'provenance/PREEXEC_VERIFICATION.json', 'preexec_v2': 'provenance/i2b_v2/PREEXEC_VERIFICATION_i2b_v2.json',
    'plan': 'provenance/uuid_correspondence_composed_330.tsv', 'plan_v2': 'provenance/uuid_correspondence_handoff_transcription_v2.tsv',
    'table': 'provenance/CONFIG330_IDENTITY_TABLE.json', 'disp': 'provenance/CONFIG330_DISPOSITION_TABLE.json', 'archive283': 'archive/V2_ARCHIVED_283.json',
    'v2_provenance': 'provenance/i2b_v2/correction_provenance_i2b_v2.json', 'phase3_v2': 'provenance/i2b_v2/PHASE3_RESULTS_i2b_v2.json', 'build330': 'provenance/BUILD330_RESULTS.json',
    'denylist': 'provenance/REJECTED_V3_DENYLIST.json',
    'archive': 'archive/ARCHIVE_ONLY_85.json', 'hist': 'archive/HISTORICAL_DIRECTION_10.json',
    'obl': 'provenance/OBLIGATION_RECONCILIATION.json', 'audit_report': 'provenance/FIXTURE_AUDIT_REPORT.json',
    'totals': 'provenance/FAMILY_TOTALS.json', 'registry': 'provenance/SUCCESSOR_IDENTITY_REGISTRY.json',
    'provenance': 'provenance/correction_provenance.json', 'repair_prov': 'provenance/i2b_v2/retention_repair_provenance_i2b_v2.json',
    'gap': 'provenance/DEFERRED_RUNTIME_GAP.md', 'writer_bytes': 'provenance/captured/writer_data_input.bytes',
    'scope_bytes': 'provenance/captured/scope_projection.bytes', 'ctx_proj': 'provenance/captured/render_context_projections.json',
    'sem_proj': 'provenance/captured/model_semantic_inputs.json', 'src_rows': 'archive/i2a_source/foundation_rows.json',
    'src_show': 'archive/i2a_source/config/show.json', 'pred_pins': 'provenance/predecessor_v0.4.4_pins.json',
    'pred_proj': 'provenance/predecessor/render_request_projections.json', 'tts_base': 'render_request_projections.json',
    'tts_map': 'fixture_persistence_conformance.json', 'stages': 'gate_fingerprint_inputs.json',
    'model_vectors': 'model_semantic_input_conformance.json', 'unicode_vectors': 'unicode_conformance.json',
    'v_base_request': 'base_request_hash_conformance.json', 'v_manifest': 'prompt_manifest_conformance.json',
    'v_claims': 'claim_event_conformance.json', 'index': 'conformance_index.json', 'policy': 'config/policy_versions.json',
    'artifact_inventory': 'ARTIFACT_INVENTORY.json', 'source_provenance': 'SOURCE_PROVENANCE.json', 'pack_members': 'PACK_MEMBERS.json',
    'readme': 'README.md', 'cases_py': 'conformance_cases.py', 'validator_py': 'validate_fixture.py',
    'cfg_blocks': 'config/block_types.json', 'cfg_modes': 'config/episode_modes.json', 'cfg_participants': 'config/participant_profiles.json',
    'cfg_enums': 'config/enum_registries.json', 'cfg_voice_evidence': 'provenance/predecessor/config/voice_profile_versions.json',
    'bible': 'authority/02_ACTIVE_SPECS/The_Desk_Character_Bible_v0.1.4.md',
}
I2A_SOURCE = ['evidence_store', 'evidence_package', 'showrunner_brief', 'writer_view', 'writer_context_manifest', 'script_pass1',
              'script_craft_revision', 'script_pass2', 'writing_craft_review', 'support_payloads', 'prompt_payloads',
              'performance_direction', 'render_manifest', 'master_assembly_map', 'assembly_recipe', 'audit_result',
              'mechanical_validation', 'revalidation_result', 'revalidation_snapshot', 'pronunciations', 'voice_profiles',
              'ready_expectations', 'scenarios', 'deferred_hash_fields']
ARCHIVAL_ROLES = {'archive_only_rows', 'historical_direction_rows', 'archive_i2a_source', 'archive_source_rows_396', 'frozen_plan_evidence',
                  'pin_table', 'predecessor_words', 'predecessor_scene_config', 'predecessor_config_evidence'}
HIST_DIRECTION_ARTIFACT = 'd1250005-0000-4000-8000-000000000012'
FROZEN_RECORD_MODE = 0o444
MAX_PACK_BYTES = 256 * 1024 * 1024


class PackUnusable(Exception):
    """the pack cannot even be loaded into a bundle; carries explicit reasons"""

    def __init__(self, reasons):
        super().__init__('; '.join(reasons))
        self.reasons = list(reasons)


# ------------------------------------------------------------------ pack reading (never extracts, repairs or writes)
class Pack:
    def __init__(self, kind, label):
        self.kind = kind            # 'zip' (file or in-memory ZIP) | 'dir'
        self.label = label
        self.data = {}              # member path -> bytes (regular files only)
        self.modes = {}             # member path -> archived mode (zip) or observed on-disk mode (dir); None when absent
        self.order = []             # member order as found
        self.problems = []          # structural problems discovered while reading
        self.zip_sha256 = None      # raw SHA-256 of the ZIP bytes (zip kind)
        self.zip_bytes = None

    def archived_mode(self, name):
        """archived mode evidence: ZIP external attributes; for an unpacked dir, the mode recorded in PACK_MEMBERS.json"""
        if self.kind == 'zip':
            return self.modes.get(name)
        try:
            pm = json.loads(self.data[PATH['pack_members']].decode('utf-8'))
            for m in pm['members']:
                if m['path'] == name:
                    return int(m['mode'], 8)
        except Exception:
            return None
        return None


def unsafe_name(n):
    if n == '':
        return 'empty name'
    if n.startswith('/') or re.match(r'^[A-Za-z]:', n):
        return 'absolute path'
    if '\\' in n:
        return 'backslash in name'
    if any(ord(c) < 0x20 or ord(c) == 0x7f for c in n):
        return 'control character in name'
    parts = n.split('/')
    if any(p in ('', '.', '..') for p in parts):
        return 'empty/dot/dotdot path component'
    if len(n) > 240:
        return 'name too long'
    return None


def open_zip_bytes(raw, label='zip'):
    p = Pack('zip', label)
    p.zip_bytes = raw
    p.zip_sha256 = hashlib.sha256(raw).hexdigest()
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            z = zipfile.ZipFile(io.BytesIO(raw))
            infos = z.infolist()
            counts = collections.Counter(i.filename for i in infos)
            for n, c in sorted(counts.items()):
                if c > 1:
                    p.problems.append('duplicate ZIP member name: %s (x%d)' % (n, c))
            low = collections.defaultdict(set)
            for i in infos:
                low[i.filename.lower()].add(i.filename)
            for k, v in sorted(low.items()):
                if len(v) > 1:
                    p.problems.append('case-colliding ZIP member names: %s' % sorted(v))
            total = 0
            for i in infos:
                n = i.filename
                total += i.file_size
                bad = unsafe_name(n.rstrip('/')) if n.endswith('/') else unsafe_name(n)
                if bad:
                    p.problems.append('unsafe ZIP member name %r: %s' % (n, bad))
                    continue
                if n.endswith('/'):
                    p.problems.append('directory entry in ZIP (pack lists regular files only): %s' % n)
                    continue
                if i.flag_bits & 0x1:
                    p.problems.append('encrypted ZIP member: %s' % n)
                    continue
                if i.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED):
                    p.problems.append('unsupported compression for %s' % n)
                    continue
                mode = (i.external_attr >> 16) & 0xFFFF
                if i.create_system == 3 and mode:
                    if stat.S_ISLNK(mode):
                        p.problems.append('symlink member in ZIP: %s' % n)
                        continue
                    if not stat.S_ISREG(mode):
                        p.problems.append('non-regular ZIP member: %s' % n)
                        continue
                if n in p.data:
                    continue   # duplicate already reported; keep the first
                try:
                    p.data[n] = z.read(i)
                except Exception as e:  # CRC / inflate failure
                    p.problems.append('unreadable ZIP member %s: %s: %s' % (n, type(e).__name__, e))
                    continue
                p.modes[n] = (mode & 0o777) if (i.create_system == 3 and mode) else None
                p.order.append(n)
            if total > MAX_PACK_BYTES:
                p.problems.append('declared uncompressed size exceeds %d bytes' % MAX_PACK_BYTES)
    except Exception as e:
        p.problems.append('ZIP cannot be opened: %s: %s' % (type(e).__name__, e))
    return p


def open_zip(path):
    with open(path, 'rb') as fh:
        raw = fh.read()
    return open_zip_bytes(raw, path)


def open_dir(path):
    """read an unpacked pack WITHOUT changing it (no chmod, no repair); on-disk modes are observed evidence only"""
    p = Pack('dir', path)
    root = os.path.abspath(path)
    for r, dirs, files in os.walk(root, followlinks=False):
        for d in list(dirs):
            full = os.path.join(r, d)
            if os.path.islink(full):
                p.problems.append('symlinked directory in folder: %s' % os.path.relpath(full, root))
                dirs.remove(d)
        for f in sorted(files):
            full = os.path.join(r, f)
            rel = os.path.relpath(full, root).replace(os.sep, '/')
            bad = unsafe_name(rel)
            if bad:
                p.problems.append('unsafe member name %r: %s' % (rel, bad))
                continue
            st = os.lstat(full)
            if stat.S_ISLNK(st.st_mode):
                p.problems.append('symlink in folder: %s' % rel)
                continue
            if not stat.S_ISREG(st.st_mode):
                p.problems.append('non-regular file in folder: %s' % rel)
                continue
            with open(full, 'rb') as fh:
                p.data[rel] = fh.read()
            p.modes[rel] = st.st_mode & 0o777
            p.order.append(rel)
    return p


# ------------------------------------------------------------------ bundle from a pack
def _mem_artifact_names(arts):
    """legacy member name -> artifact id, derived from the load rows (no hard-coded fresh UUIDs)"""
    single = ('showrunner_brief', 'script_pass1', 'writing_craft_review', 'script_craft_revision', 'script_pass2', 'evidence_package',
              'assembly_recipe', 'writer_view', 'writer_context_manifest', 'revalidation_snapshot', 'tenor_support', 'continuity_support',
              'prompt_manifest_1', 'prompt_manifest_2', 'prompt_manifest_3', 'prompt_manifest_4', 'prompt_manifest_5')
    suffixed = {'semantic_audit_result': 'semantic_audit_result__successor', 'render_manifest': 'render_manifest__successor',
                'master_assembly_map': 'master_assembly_map__successor', 'mechanical_validation': 'mechanical_validation__successor',
                'revalidation_result': 'revalidation_result__successor'}
    out, reasons = {}, []
    for t in single:
        ids = [a['artifact_id'] for a in arts if a['artifact_type'] == t]
        if len(ids) != 1:
            reasons.append('expected exactly one artifact of type %s, found %d' % (t, len(ids)))
        else:
            out[t] = ids[0]
    for t, name in suffixed.items():
        ids = [a['artifact_id'] for a in arts if a['artifact_type'] == t]
        if len(ids) != 1:
            reasons.append('expected exactly one artifact of type %s, found %d' % (t, len(ids)))
        else:
            out[name] = ids[0]
    pd = [a['artifact_id'] for a in arts if a['artifact_type'] == 'performance_direction']
    if sorted(pd).count(HIST_DIRECTION_ARTIFACT) != 1 or len(pd) != 2:
        reasons.append('expected exactly two performance_direction artifacts including the historical one')
    else:
        out['performance_direction__historical'] = HIST_DIRECTION_ARTIFACT
        out['performance_direction__successor'] = [x for x in pd if x != HIST_DIRECTION_ARTIFACT][0]
    return out, reasons


def xlate(o, m):
    """replace exact UUID substrings (values and keys) through the map m; everything else untouched"""
    if isinstance(o, str):
        return UUIDANY.sub(lambda g: m.get(g.group(0), g.group(0)), o)
    if isinstance(o, list):
        return [xlate(x, m) for x in o]
    if isinstance(o, dict):
        return {xlate(k, m): xlate(v, m) for k, v in o.items()}
    return o


CONTAINER_KEYS = ('manifests', 'artifacts')


def resolve_payload(pack, art):
    """payload of a JSON artifact from its storage_uri member. Whole member = payload, except the two shared containers
    (a member object with a 'manifests' or 'artifacts' list) where the literal artifact_id selects exactly one entry."""
    uri = art['storage_uri']
    if uri not in pack.data:
        raise KeyError('dangling storage_uri %r: not a member of the pack' % uri)
    obj = json.loads(pack.data[uri].decode('utf-8'))
    if isinstance(obj, dict) and any(isinstance(obj.get(k), list) for k in CONTAINER_KEYS) and 'artifact_id' not in obj:
        lst = obj.get('manifests') if isinstance(obj.get('manifests'), list) else obj.get('artifacts')
        hits = [e for e in lst if isinstance(e, dict) and e.get('artifact_id') == art['artifact_id']]
        if len(hits) != 1:
            raise KeyError('container %s has %d entries for artifact %s (%s)' % (uri, len(hits), art['artifact_id'], 'duplicate artifact_id entry' if len(hits) > 1 else 'no entry'))
        return hits[0]['canonical_payload']
    return obj


def load_bundle(pack, expect=None):
    """Bundle B from the pack alone. Raises PackUnusable (explicit reasons) when it cannot be built."""
    reasons = []

    def need(name):
        if name not in pack.data:
            reasons.append('required member missing: ' + name)
            return b''
        return pack.data[name]

    def jl(name):
        b = need(name)
        if not b:
            return None
        try:
            return json.loads(b.decode('utf-8'))
        except Exception as e:
            reasons.append('member is not valid UTF-8 JSON: %s (%s)' % (name, e))
            return None

    B = {'pack': pack, 'expect': expect or {}, 'notes': {}}
    load = jl(PATH['load'])
    if reasons:
        raise PackUnusable(reasons)
    B['load'] = load['tables']
    B['load_profile'] = load.get('profile')
    B['pack_members'] = jl(PATH['pack_members'])
    B['src_tables'] = (jl(PATH['src_rows']) or {}).get('tables')
    B['src'] = {n: jl('archive/i2a_source/%s.json' % n) for n in I2A_SOURCE}
    B['src']['show'] = jl(PATH['src_show'])
    arts = B['load']['artifacts']
    names, r2 = _mem_artifact_names(arts)
    reasons += r2
    byid = {a['artifact_id']: a for a in arts}
    members = {}
    for nm, aid in names.items():
        try:
            members[nm] = resolve_payload(pack, byid[aid])
        except Exception as e:
            reasons.append('artifact %s (%s) does not resolve to a member payload: %s' % (aid, nm, e))
    members['ready_expectations'] = jl('ready_expectations.json')
    members['persistence_expectations'] = jl('persistence_expectations.json')
    members['scenarios'] = jl('scenarios.json')
    members['config_show_version'] = jl('config/show_config_version.json')
    members['config_show_version_v1_history'] = jl('config/show_config_version_v1_history.json')
    B['members'] = members
    B['proj'] = {'tts_base_projections': jl(PATH['tts_base']), 'fixture_tts_mapping': jl(PATH['tts_map']), 'stage_fingerprints': jl(PATH['stages']),
                 'model_semantic_inputs': jl(PATH['sem_proj']), 'render_context_projections': jl(PATH['ctx_proj'])}
    B['requests'] = jl(PATH['requests'])
    B['record'] = need(PATH['record'])
    B['corr_bytes'] = need(PATH['corr'])
    B['preexec'] = need(PATH['preexec'])
    B['writer_bytes'] = need(PATH['writer_bytes'])
    B['scope_bytes'] = need(PATH['scope_bytes'])
    B['gap_md'] = need(PATH['gap'])
    B['wav'] = {n: pack.data[n] for n in sorted(pack.data) if n.startswith('fixture_audio/') and n.endswith('.wav')}
    tsv = need(PATH['plan']).decode('utf-8', 'replace')
    B['plan'] = [tuple(l.rstrip('\n').split('\t')) for l in tsv.splitlines() if l.strip()]
    B['plan_v2'] = [tuple(l.rstrip('\n').split('\t')) for l in need(PATH['plan_v2']).decode('utf-8', 'replace').splitlines() if l.strip()]
    B['table_bytes'] = need(PATH['table'])
    B['frozen_table'] = jl(PATH['table'])
    B['denylist'] = jl(PATH['denylist'])
    B['disp'] = jl(PATH['disp'])
    B['record_v1'] = need(PATH['record_v1'])
    B['corr_v1'] = need(PATH['corr_v1'])
    B['preexec_v2'] = need(PATH['preexec_v2'])
    B['archive283'] = (jl(PATH['archive283']) or {}).get('rows')
    B['v2_provenance'] = jl(PATH['v2_provenance'])
    B['phase3_v2'] = jl(PATH['phase3_v2'])
    B['build330'] = jl(PATH['build330'])
    # I2A source members exist in two id spaces: B['src_v2'] (literal I2A/accepted-v2 identities) and B['src'] (the same objects
    # translated to the SUCCESSOR identities through the composed correspondence; the I2A show configuration stays historical)
    B['src_v2'] = copy.deepcopy(B['src'])
    B['xmap'] = {x[1]: x[2] for x in B['plan'] if len(x) == 4}
    B['src'] = {k: (v if (k == 'show' or v is None) else xlate(v, B['xmap'])) for k, v in B['src'].items()}
    B['archive'] = (jl(PATH['archive']) or {}).get('rows')
    B['hist'] = (jl(PATH['hist']) or {}).get('rows')
    B['obl'] = jl(PATH['obl'])
    B['audit_report'] = jl(PATH['audit_report'])
    B['totals'] = jl(PATH['totals'])
    B['registry'] = jl(PATH['registry'])
    B['provenance'] = jl(PATH['provenance'])
    B['repair_prov'] = jl(PATH['repair_prov'])
    B['pred_pins'] = jl(PATH['pred_pins'])
    B['pred_scripts'] = {k: jl('provenance/predecessor/%s.json' % k) for k in ('script_pass1', 'script_craft_revision', 'script_pass2')}
    B['pred_proj'] = (jl(PATH['pred_proj']) or {}).get('projections')
    B['model_vectors'] = jl(PATH['model_vectors'])
    B['unicode_vectors'] = jl(PATH['unicode_vectors'])
    B['v_base_request'] = jl(PATH['v_base_request'])
    B['v_manifest'] = jl(PATH['v_manifest'])
    B['v_claims'] = jl(PATH['v_claims'])
    B['index'] = jl(PATH['index'])
    B['policy'] = jl(PATH['policy'])
    B['artifact_inventory'] = jl(PATH['artifact_inventory'])
    B['source_provenance'] = jl(PATH['source_provenance'])
    sp = B['source_provenance'] or {}
    B['authority'] = {n: pack.data[n] for n in pack.data if n.startswith('authority/')}
    B['cfg'] = {'blocks': jl(PATH['cfg_blocks']), 'modes': jl(PATH['cfg_modes']), 'participants': jl(PATH['cfg_participants']), 'enums': jl(PATH['cfg_enums']), 'templates': []}
    for n in sorted(pack.data):
        if n.startswith('config/') and n.endswith('.json') and b'"rundown_template_version_id"' in pack.data[n] and b'"slots"' in pack.data[n]:
            try:
                B['cfg']['templates'].append((n, json.loads(pack.data[n].decode('utf-8'))))
            except Exception as e:
                reasons.append('template-shaped configuration member is not valid JSON: %s (%s)' % (n, e))
    if reasons:
        raise PackUnusable(reasons)
    return B
# ------------------------------------------------------------------ own serializer / hashing
def _norm(x):
    if isinstance(x, str):
        return unicodedata.normalize('NFC', x)
    if isinstance(x, bool) or x is None:
        return x
    if isinstance(x, int):
        return x
    if isinstance(x, list):
        return [_norm(i) for i in x]
    if isinstance(x, dict):
        d = {}
        for k, v in x.items():
            nk = unicodedata.normalize('NFC', k)
            if nk in d:
                raise ValueError('duplicate key after NFC')
            d[nk] = _norm(v)
        return d
    raise ValueError('non-semantic value %r' % (x,))


def _emit(x):
    if x is None:
        return 'null'
    if x is True:
        return 'true'
    if x is False:
        return 'false'
    if isinstance(x, int):
        return str(x)
    if isinstance(x, str):
        return json.dumps(x, ensure_ascii=False)
    if isinstance(x, list):
        return '[' + ','.join(_emit(i) for i in x) + ']'
    keys = sorted(x, key=lambda s: [ord(c) for c in s])
    return '{' + ','.join(json.dumps(k, ensure_ascii=False) + ':' + _emit(x[k]) for k in keys) + '}'


def cj(v):
    return _emit(_norm(v))


def cb(v):
    return cj(v).encode('utf-8')


def H(b):
    return hashlib.sha256(b).hexdigest()


def DH(domain, v):
    return H(domain.encode() + b'\n' + cb(v))


HEX = re.compile(r'^[0-9a-f]{64}$')
BASEH = re.compile(r'^v1:[0-9a-f]{64}$')
UUID4 = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$')
UUIDANY = re.compile(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')


def J(path):
    with open(path, encoding='utf-8') as fh:
        return json.load(fh)


def walk(v, p=''):
    if isinstance(v, dict):
        for k, x in v.items():
            yield from walk(x, p + '/' + k)
    elif isinstance(v, list):
        for i, x in enumerate(v):
            yield from walk(x, p + '/' + str(i))
    else:
        yield p, v


def diff(a, b, p=''):
    """leaf differences between two JSON values: [(path, a, b)]; absent side is the string '<absent>'"""
    out = []
    if isinstance(a, dict) and isinstance(b, dict):
        for k in sorted(set(a) | set(b)):
            out += diff(a.get(k, '<absent>'), b.get(k, '<absent>'), p + '/' + k)
    elif isinstance(a, list) and isinstance(b, list) and len(a) == len(b):
        for i, (x, y) in enumerate(zip(a, b)):
            out += diff(x, y, p + '/' + str(i))
    elif a != b:
        out.append((p, a, b))
    return out


# ------------------------------------------------------------------ static expectations (from the handoff)
# family: (I2A source rows, archive-only source rows, fresh rows, successor loaded rows) - the CONFIG-330 plan accounting (396 / 273 / 275 / 398)
SUCC_TABLE = {
    'accounts': (2, 0, 0, 2),
    'artifacts': (35, 16, 17, 36),
    'assembly_recipes': (1, 0, 0, 1),
    'audio_artifacts': (12, 0, 0, 12),
    'audit_runs': (2, 2, 2, 2),
    'claim_state_events': (0, 0, 0, 0),
    'claim_supports': (9, 0, 0, 9),
    'claims': (9, 0, 0, 9),
    'derivation_runs': (1, 0, 0, 1),
    'evidence_packages': (1, 0, 0, 1),
    'evidence_units': (16, 0, 0, 16),
    'gate_definitions': (32, 0, 0, 32),
    'gate_results': (62, 62, 62, 62),
    'master_assembly_maps': (1, 1, 1, 1),
    'model_runs': (5, 5, 5, 5),
    'performance_direction_versions': (1, 1, 1, 1),
    'performance_intents': (8, 8, 8, 8),
    'program_blocks': (9, 9, 9, 9),
    'program_run_attempts': (2, 2, 2, 2),
    'program_runs': (2, 2, 2, 2),
    'prompt_manifests': (5, 4, 4, 5),
    'pronunciation_renderings': (3, 0, 0, 3),
    'pronunciations': (2, 0, 0, 2),
    'provider_call_events': (15, 15, 15, 15),
    'provider_calls': (15, 15, 15, 15),
    'render_blocks': (9, 9, 9, 9),
    'render_manifests': (1, 1, 1, 1),
    'render_takes': (10, 10, 10, 10),
    'reroll_triggers': (1, 1, 1, 1),
    'rights_versions': (7, 0, 0, 7),
    'script_versions': (3, 3, 3, 3),
    'show_config_versions': (1, 0, 1, 2),
    'showrunner_brief_versions': (1, 1, 1, 1),
    'shows': (1, 0, 0, 1),
    'take_selections': (10, 10, 10, 10),
    'turn_claim_uses': (36, 36, 36, 36),
    'turn_evidence_uses': (9, 9, 9, 9),
    'turns': (51, 51, 51, 51),
    'voice_profile_versions': (3, 0, 0, 3),
    'voice_profiles': (3, 0, 0, 3),
}

PK = {'accounts': 'account_id', 'artifacts': 'artifact_id', 'assembly_recipes': 'assembly_recipe_id',
      'audio_artifacts': 'audio_artifact_id', 'audit_runs': 'audit_run_id', 'claim_state_events': 'claim_state_event_id',
      'claim_supports': 'claim_support_id', 'claims': 'claim_id', 'derivation_runs': 'derivation_run_id',
      'evidence_packages': 'evidence_package_id', 'evidence_units': 'evidence_unit_id', 'gate_definitions': 'gate_definition_id',
      'gate_results': 'gate_result_id', 'master_assembly_maps': 'master_assembly_map_id', 'model_runs': 'model_run_id',
      'performance_direction_versions': 'performance_direction_version_id', 'performance_intents': 'performance_intent_id',
      'program_blocks': 'program_block_id', 'program_run_attempts': 'attempt_id', 'program_runs': 'program_run_id',
      'prompt_manifests': 'prompt_manifest_id', 'pronunciation_renderings': 'pronunciation_rendering_id',
      'pronunciations': 'pronunciation_id', 'provider_call_events': 'provider_call_event_id', 'provider_calls': 'provider_call_id',
      'render_blocks': 'render_block_id', 'render_manifests': 'render_manifest_id', 'render_takes': 'render_take_id',
      'reroll_triggers': 'reroll_trigger_id', 'rights_versions': 'rights_version_id', 'script_versions': 'script_version_id',
      'show_config_versions': 'show_config_version_id', 'showrunner_brief_versions': 'showrunner_brief_version_id',
      'shows': 'show_id', 'take_selections': 'take_selection_id', 'turn_claim_uses': 'turn_claim_use_id',
      'turn_evidence_uses': 'turn_evidence_use_id', 'turns': 'turn_id', 'voice_profile_versions': 'voice_profile_version_id',
      'voice_profiles': 'voice_profile_id'}
# Foundation 001 FKs (cross-checked against migrations/001_foundation.sql) plus the Migration-002 columns in the specs
FK = {
    'show_config_versions': {'show_id': 'shows', 'parent_version_id': 'show_config_versions'},
    'program_runs': {'show_id': 'shows', 'show_config_version_id': 'show_config_versions'},
    'program_run_attempts': {'program_run_id': 'program_runs', 'show_config_version_id': 'show_config_versions',
                             'parent_attempt_id': 'program_run_attempts', 'evidence_package_id': 'evidence_packages'},
    'artifacts': {'parent_artifact_id': 'artifacts', 'supersedes_artifact_id': 'artifacts'},
    'evidence_units': {'rights_version_id': 'rights_versions', 'supersedes_evidence_unit_id': 'evidence_units'},
    'claims': {'supersedes_claim_id': 'claims'},
    'claim_supports': {'claim_id': 'claims', 'evidence_unit_id': 'evidence_units', 'derivation_run_id': 'derivation_runs'},
    'prompt_manifests': {'artifact_id': 'artifacts'},
    'provider_calls': {'attempt_id': 'program_run_attempts', 'retry_of_provider_call_id': 'provider_calls',
                       'reroll_of_provider_call_id': 'provider_calls', 'reroll_trigger_id': 'reroll_triggers'},
    'provider_call_events': {'provider_call_id': 'provider_calls', 'response_artifact_id': 'artifacts'},
    'reroll_triggers': {'source_provider_call_id': 'provider_calls', 'validation_artifact_id': 'artifacts', 'actor_id': 'accounts'},
    'model_runs': {'attempt_id': 'program_run_attempts', 'provider_call_id': 'provider_calls',
                   'prompt_manifest_id': 'prompt_manifests', 'output_artifact_id': 'artifacts'},
    'evidence_packages': {'artifact_id': 'artifacts'},
    'showrunner_brief_versions': {'artifact_id': 'artifacts', 'evidence_package_id': 'evidence_packages',
                                  'attempt_id': 'program_run_attempts', 'revision_parent_id': 'showrunner_brief_versions'},
    'program_blocks': {'showrunner_brief_version_id': 'showrunner_brief_versions'},
    'script_versions': {'artifact_id': 'artifacts', 'showrunner_brief_version_id': 'showrunner_brief_versions',
                        'attempt_id': 'program_run_attempts', 'revision_parent_id': 'script_versions'},
    'turns': {'script_version_id': 'script_versions', 'program_block_id': 'program_blocks'},
    'turn_claim_uses': {'turn_id': 'turns', 'claim_id': 'claims'},
    'turn_evidence_uses': {'turn_id': 'turns', 'evidence_unit_id': 'evidence_units'},
    'performance_direction_versions': {'artifact_id': 'artifacts', 'script_version_id': 'script_versions'},
    'performance_intents': {'performance_direction_version_id': 'performance_direction_versions', 'turn_id': 'turns'},
    'audit_runs': {'attempt_id': 'program_run_attempts', 'model_run_id': 'model_runs', 'result_artifact_id': 'artifacts'},
    'gate_results': {'gate_definition_id': 'gate_definitions', 'attempt_id': 'program_run_attempts'},
    'voice_profile_versions': {'voice_profile_id': 'voice_profiles'},
    'pronunciations': {'supersedes_pronunciation_id': 'pronunciations'},
    'pronunciation_renderings': {'pronunciation_id': 'pronunciations', 'voice_profile_version_id': 'voice_profile_versions'},
    'render_manifests': {'artifact_id': 'artifacts', 'script_version_id': 'script_versions',
                         'performance_direction_version_id': 'performance_direction_versions', 'audit_run_id': 'audit_runs'},
    'render_blocks': {'render_manifest_id': 'render_manifests', 'program_block_id': 'program_blocks'},
    'render_takes': {'render_block_id': 'render_blocks', 'provider_call_id': 'provider_calls', 'audio_artifact_id': 'artifacts'},
    'take_selections': {'render_block_id': 'render_blocks', 'render_take_id': 'render_takes', 'actor_id': 'accounts',
                        'supersedes_selection_id': 'take_selections'},
    'audio_artifacts': {'artifact_id': 'artifacts'},
    'assembly_recipes': {'artifact_id': 'artifacts'},
    'master_assembly_maps': {'artifact_id': 'artifacts', 'assembly_recipe_id': 'assembly_recipes',
                             'master_audio_artifact_id': 'audio_artifacts'}}

DIRECTION_VOCAB = {
    'delivery_affect': {'neutral', 'warm', 'dry', 'gently_amused', 'curious', 'skeptical', 'incredulous', 'frustrated',
                        'disappointed', 'joyful', 'rueful', 'grave', 'restrained', 'emphatic'},
    'pace': {'slower', 'standard', 'quicker', 'building'}, 'energy_intensity': {'restrained', 'standard', 'heightened'},
    'pause_intent': {'short', 'medium', 'long'}, 'nonverbal_event': {'breath', 'sigh', 'chuckle', 'laugh'}}
GATE_SET = 'build2-gates-v1'
PACE_ID = 'd1250017-0000-4000-8000-000000000006'


# (bundle loading lives in the pack section below)


# ------------------------------------------------------------------ helpers over the bundle
def current_config(B):
    """the single show-config version bound by every loaded attempt (the CURRENT configuration)"""
    L = B['load']
    ids = {a['show_config_version_id'] for a in L['program_run_attempts']}
    rows = [r for r in L['show_config_versions'] if r['show_config_version_id'] in ids]
    if len(ids) != 1 or len(rows) != 1:
        raise ValueError('loaded attempts do not bind exactly one show-config version')
    return rows[0]


def idx(rows, key):
    return {r[key]: r for r in rows}


def plan_maps(B):
    P = {}
    for fam, s, f, d in B['plan']:
        P.setdefault(fam, {})[s] = (f, d)
    return P


def fresh_of(B, fam, s):
    return plan_maps(B)[fam][s][0]


def script_view(B, key, space='succ'):
    """anchor maps for a source script member (space 'succ': translated to the successor identities; 'v2': literal I2A/accepted-v2 identities)"""
    s = (B['src'] if space == 'succ' else B['src_v2'])[key]
    return s, {t['turn_id']: t['semantic_turn_id'] for t in s['turns']}


def source_chain(B, space='succ'):
    """Independently recompute the upstream chain from the preserved I2A source. space='succ' re-keys the source objects to the SUCCESSOR identities
    (composed correspondence) so every hash is recomputed over the successor ids; space='v2' uses the literal I2A/accepted-v2 identities (the accepted history)."""
    R = {}
    S = B['src'] if space == 'succ' else B['src_v2']
    T_ = B['src_tables']
    xm = B['xmap'] if space == 'succ' else {}
    ix = lambda i: xm.get(i, i)  # noqa: E731
    st = S['evidence_store']
    ev = {r['evidence_unit_id']: H(unicodedata.normalize('NFC', r['canonical_content']).encode('utf-8')) for r in st['rows']}
    R['ev'] = ev
    dr = T_['derivation_runs'][0]
    R['deriv'] = DH('derivation-output-v1', dr['output'])
    carriers = {}
    for a in S['support_payloads']['artifacts']:
        pl = copy.deepcopy(a['canonical_payload'])
        for o in pl['projection'].get('observations', []):
            o['content_hash'] = ev[o['evidence_unit_id']]
        carriers[a['artifact_id']] = DH('fixture-support-object-v1', pl)
    R['carriers'] = carriers
    sup = {}
    for s in T_['claim_supports']:
        if s['support_kind'] == 'evidence':
            sup[s['claim_support_id']] = ev[s['evidence_unit_id']]
        elif s['support_kind'] == 'derivation':
            sup[s['claim_support_id']] = R['deriv']
        else:
            sup[s['claim_support_id']] = carriers[s['external_support_identity'].split(':', 1)[1]]
    R['sup'] = sup
    cc, cs = {}, {}
    for c in T_['claims']:
        p = {k: c[k] for k in ('claim_kind', 'origin', 'subject_domain', 'subject', 'predicate', 'value',
                               'initial_status', 'initial_usage_class', 'asserted_at')}
        cc[c['claim_id']] = DH('claim-content-v1', p)
        cs[c['claim_id']] = DH('claim-frozen-state-v1', {'claim_content_hash': cc[c['claim_id']], 'state': c['initial_status'],
                                                         'effective_usage_class': c['initial_usage_class']})
    R['cc'], R['cs'] = cc, cs
    pk = copy.deepcopy(S['evidence_package'])
    m = pk['manifest']
    for e in m['evidence']:
        e['content_hash'] = ev[e['evidence_unit_id']]
    for c in m['claims']:
        c['claim_content_hash'] = cc[c['claim_id']]
        c['frozen_state_hash'] = cs[c['claim_id']]
        for r in c['support_refs']:
            r['support_hash'] = sup[r['claim_support_id']]
    R['package_manifest'] = m
    R['package'] = DH('evidence-package-v2', m)
    R['scope'] = H(b'evidence-package-scope-v1\n' + cb(m['scope']))
    br = copy.deepcopy(S['showrunner_brief'])
    br['package_hash'] = R['package']
    R['brief_obj'] = br
    excl = set('artifact_id showrunner_brief_version_id program_run_id attempt_id purpose evidence_package_id planner_model_run_id created_at revision_parent_id revision_reason brief_hash'.split())
    R['brief'] = DH('showrunner-brief-v1', {k: v for k, v in br.items() if k not in excl})
    wv = copy.deepcopy(S['writer_view'])
    wv['brief_hash'], wv['package_hash'] = R['brief'], R['package']
    for c in wv['selected_claims']:
        c['claim_content_hash'], c['frozen_state_hash'] = cc[c['claim_id']], cs[c['claim_id']]
    for e in wv['selected_evidence']:
        e['content_hash'] = ev[e['evidence_unit_id']]
    wdata = {k: v for k, v in wv.items() if k not in ('script_request_id', 'writer_view_hash')}
    R['wv_obj'] = wv
    R['wv'] = DH('writer-view-v1', wdata)
    R['serialized_input'] = H(cb(wdata))
    cm = copy.deepcopy(S['writer_context_manifest'])
    cm['serialized_input_hash'] = R['serialized_input']
    keys = ('required_component_refs', 'required_claim_refs', 'required_context_selection_refs', 'required_character_refs',
            'required_policy_refs', 'required_comprehension_target_refs', 'serialized_input_hash', 'estimated_input_tokens',
            'model_context_limit', 'reserved_output_tokens', 'completeness_check')
    R['cm'] = DH('writer-context-manifest-v1', {k: cm[k] for k in keys})
    parent = None
    for key in ('script_pass1', 'script_craft_revision', 'script_pass2'):
        s, amap = script_view(B, key, space)
        pos = {t['semantic_turn_id']: t['sequence'] for t in s['turns']}
        cu = sorted(({'semantic_turn_id': amap[u['turn_id']], 'claim_id': u['claim_id'], 'use_mode': u['use_mode'],
                      'span_start': u['span_start'], 'span_end': u['span_end'], 'claim_state_hash': cs[u['claim_id']]}
                     for u in s['turn_claim_uses']),
                    key=lambda u: (pos[u['semantic_turn_id']], u['span_start'], u['span_end'], u['use_mode'], u['claim_id']))
        eu = sorted(({'semantic_turn_id': amap[u['turn_id']], 'evidence_unit_id': u['evidence_unit_id'], 'use_mode': u['use_mode'],
                      'span_start': u['span_start'], 'span_end': u['span_end'], 'rights_policy_version': u['rights_policy_version']}
                     for u in s['turn_evidence_uses']),
                    key=lambda u: (pos[u['semantic_turn_id']], u['span_start'], u['span_end'], u['use_mode'], u['evidence_unit_id']))
        pc = []
        for p in s['prediction_candidates']:
            q = {k: v for k, v in p.items() if k != 'turn_id'}
            q['semantic_turn_id'] = amap[p['turn_id']]
            pc.append(q)
        proj = {'brief_hash': R['brief'], 'package_hash': R['package'], 'writing_policy_version': s['writing_policy_version'],
                'program_block_refs': s['program_block_refs'],
                'turns': [{k: t[k] for k in ('semantic_turn_id', 'program_block_id', 'participant_id', 'spoken_text')} for t in s['turns']],
                'turn_claim_uses': cu, 'turn_evidence_uses': eu, 'prediction_candidates': pc}
        if parent:
            proj['revision_parent_content_identity'] = parent
        R[key] = DH('script-v2', proj)
        parent = R[key]
    rv = copy.deepcopy(S['writing_craft_review'])
    s1, amap1 = script_view(B, 'script_pass1', space)
    fl = [dict({k: v for k, v in f.items() if k not in ('finding_id', 'span_refs')},
               span_refs=[{'semantic_turn_id': amap1[r['turn_id']]} for r in f['span_refs']]) for f in rv['findings']]
    R['review'] = DH('writing-craft-review-v1', {'subject_script_hash': R['script_pass1'], 'craft_policy_version': rv['craft_policy_version'],
                                                 'critic_contract_version': rv['critic_contract_version'], 'findings': fl, 'outcome': rv['outcome']})
    sn = copy.deepcopy(S['revalidation_snapshot'])
    sn['source_package_hash'] = R['package']
    R['snapshot'] = DH('fixture-revalidation-snapshot-v1', {k: sn[k] for k in ('fixture_stub', 'live_search', 'source_package_hash',
                       'claim_state_changes', 'sensitivity_changes', 'mode_rule_changes', 'captured_at')})
    types_ = {'showrunner_brief': R['brief'], 'script_pass1': R['script_pass1'], 'writing_craft_review': R['review'], 'script_craft_revision': R['script_craft_revision'],
              'script_pass2': R['script_pass2'], 'evidence_package': R['package'], 'writer_view': R['wv'], 'writer_context_manifest': R['cm'], 'revalidation_snapshot': R['snapshot']}
    art = {}
    for a_ in T_['artifacts']:
        if a_['artifact_type'] in types_:
            art[ix(a_['artifact_id'])] = types_[a_['artifact_type']]
    art.update({k: v for k, v in carriers.items()})
    R['art'] = art
    # prompt manifests / specimens
    spec, pm_art, req, sem = {}, {}, {}, {}
    prow = {ix(r_['prompt_manifest_id']): r_ for r_ in T_['prompt_manifests']}
    for m in S['prompt_payloads']['manifests']:
        c = copy.deepcopy(m['canonical_payload'])
        for ia in c['ordered_input_artifacts']:
            ia['content_hash'] = art[ia['artifact_id']]
        rq = cj({'execution_mode': 'fixture_stub', 'input_artifacts': [dict(artifact_id=i['artifact_id'], artifact_type=i['artifact_type'],
                 content_hash=i['content_hash']) for i in c['ordered_input_artifacts']], 'instruction': c['non_source_text'][0]['text'],
                 'purpose': c['purpose']})
        c['rendered_request_hash'] = H(rq.encode('utf-8'))
        c['rendered_request_ref']['bytes_status'] = 'frozen_specimen_i2b'
        c['retention']['request_bytes_available'] = True
        spec[m['prompt_manifest_id']] = rq
        req[m['prompt_manifest_id']] = c['rendered_request_hash']
        pm_art[m['artifact_id']] = (c, DH('prompt-manifest-artifact-v1', c))
        r = prow[m['prompt_manifest_id']]
        sem[m['prompt_manifest_id']] = DH('model-semantic-input-v1', {'component_versions': r['component_versions'],
                                         'policy_source_hashes': r['policy_source_hashes'], 'rendered_request_hash': c['rendered_request_hash']})
    R['spec'], R['pm_art'], R['req'], R['sem'] = spec, pm_art, req, sem
    return R


def wav_facts(B):
    out = {}
    for path, data in B['wav'].items():
        w = wave.open(io.BytesIO(data), 'rb')
        out[path] = {'frames': w.getnframes(), 'rate': w.getframerate(), 'channels': w.getnchannels(), 'width': w.getsampwidth(),
                     'pcm': w.readframes(w.getnframes()), 'sha': H(data), 'bytes': len(data)}
    return out


# ------------------------------------------------------------------ CHECK GROUPS  (each returns a list of failure strings)
def g_frozen_record(B, f=None):
    f = [] if f is None else f
    rec = B['record'].decode('utf-8')
    proj = json.loads(B['corr_bytes'].decode('utf-8'))
    if H(B['record']) != proj.get('adjudication_record_sha256'):
        f.append('correction projection does not bind the frozen record bytes')
    forbidden = re.findall(UUIDANY, rec)
    plan_ids = {x[2] for x in B['plan']} | {p['proposed_id'] for p in (B['frozen_table'] or {}).get('proposals', [])}
    if any(u in plan_ids for u in forbidden):
        f.append('frozen record contains a successor UUID allocation')
    m = B['members'].get('performance_direction__successor', {})
    for tok in (m.get('direction_hash'), m.get('input_fingerprint'), H(B['corr_bytes'])):
        if tok and tok in rec:
            f.append('frozen record contains a downstream/output hash (cycle)')
    m_ = re.search(r'Pre-execution verification output `[^`]+` raw SHA-256 `([0-9a-f]{64})`', rec)
    if not m_ or m_.group(1) != H(B['preexec']):
        f.append('frozen record does not bind the current pre-execution verification output')
    pre = json.loads(B['preexec'].decode('utf-8'))
    R_ = source_chain(B)
    if pre['summary']['failed'] != 0 or pre['script_hash'] != R_['script_pass2']:
        f.append('pre-execution verification output disagrees with the independently recomputed script hash / has failures')
    lower = rec.lower()
    for needle in ('mike approved', 'mike has approved', 'approved by mike'):
        if needle in lower:
            f.append('record attributes approval to Mike')
    if 'not a model run' not in lower:
        f.append('record does not disclaim model/director run')
    # version 2 supersedes version 1 and binds its exact bytes; version 1 and its projection stay frozen history
    if H(B['record_v1']) != '3f8a760aa106e238d262132ab396cc3a99f71c72768a2f6a72b14c65bd7f78c3' or H(B['corr_v1']) != '2aaa8a5f2e0c6b56dcafff436051af9411c66bae69fb3744bb0ecba29808af5a':
        f.append('version 1 record/projection bytes differ from the accepted frozen constants')
    if H(B['record_v1']) not in rec or H(B['corr_v1']) not in rec:
        f.append('record v2 does not bind the version 1 record and projection hashes')
    p1 = json.loads(B['corr_v1'].decode('utf-8'))
    R2_ = source_chain(B, 'v2')
    if p1.get('adjudication_record_sha256') != H(B['record_v1']) or p1.get('script_hash') != R2_['script_pass2']:
        f.append('version 1 projection does not bind the version 1 record / the accepted v2 script hash')
    if pre.get('config', {}).get('new_hash') != B['members']['config_show_version']['config_hash']:
        f.append('pre-execution verification does not bind the new configuration hash')
    return f


def g_plan_counts_fk(B, f=None):
    f = [] if f is None else f
    plan = plan_maps(B)
    if len(B['plan']) != 275:
        f.append('composed plan is not 275 rows')
    fresh = [x[2] for x in B['plan']]
    if len(set(fresh)) != 275 or not all(UUID4.match(u) for u in fresh):
        f.append('fresh ids not 275 distinct canonical v4')
    src_text = json.dumps(B['src_tables'])
    if any(u in src_text for u in fresh):
        f.append('a fresh id collides with a source row value')
    L = B['load']
    if set(L) != set(SUCC_TABLE) or len(L) != 40:
        f.append('family set is not the 40 expected families')
    counts = {k: len(v) for k, v in L.items()}
    for fam, (s, a, fr, tot) in SUCC_TABLE.items():
        if counts.get(fam) != tot or len(B['src_tables'][fam]) != s or len(plan.get(fam, {})) != fr:
            f.append('family count mismatch: %s got %s want %s' % (fam, counts.get(fam), tot))
        arch = sum(1 for v in plan.get(fam, {}).values() if v[1] == 'Archive only')
        if arch != a:
            f.append('archive-only count mismatch: ' + fam)
    if sum(counts.values()) != 398:
        f.append('load is not 398 rows: %d' % sum(counts.values()))
    # global PK canonical + unique
    seen = {}
    for fam, rows in L.items():
        if fam not in PK:
            continue
        for r in rows:
            v = r.get(PK[fam])
            if not isinstance(v, str) or not UUID4.match(v):
                f.append('noncanonical v4 PK in ' + fam)
            elif v in seen:
                f.append('duplicate PK across load: ' + v)
            seen[v] = fam
    # archive-only ids absent, fresh ids present in their family, historical retained
    for fam, mp in plan.items():
        ids = {r[PK[fam]] for r in L[fam]}
        for s, (fr, d) in mp.items():
            if fr not in ids:
                f.append('fresh row missing: %s %s' % (fam, fr))
            if d == 'Archive only' and s in ids:
                f.append('archive-only source row co-loaded: %s %s' % (fam, s))
            if d == 'Historical in load' and s not in ids:
                f.append('historical source row not retained: %s %s' % (fam, s))
    # the composed plan equals the accepted v2 correspondence composed with the FROZEN identity table (independent recomposition)
    ft = B['frozen_table']
    umap = {p['old_id']: p['proposed_id'] for p in ft['proposals'] if p['old_id'] and not p['family'].startswith('scenario:')}
    cfg_new = [p['proposed_id'] for p in ft['proposals'] if p['family'] == 'show_config_versions']
    if H(B['table_bytes']) != '8f7311d88218eaf9a7414e7bd4c3ff418054e82698b645eddb34633e9fa19830':
        f.append('shipped identity table is not the accepted frozen table')
    if len(ft['proposals']) != 283 or len(umap) != 274 or len(cfg_new) != 1:
        f.append('frozen identity table is not 283 proposals (274 replacements + 1 config + 8 scenario rows)')
    arch_only9 = {d['old_id'] for d in (B['disp'] or {}).get('rows', []) if d.get('disposition') == 'archive_only_no_successor'}
    recomposed, v2fresh = set(), set()
    for fam, s, f2, d in B['plan_v2']:
        v2fresh.add(f2)
        if f2 not in umap:
            f.append('accepted v2 fresh id is not replaced by the frozen table: %s' % f2)
            continue
        recomposed.add((fam, s, umap[f2], 'Archive only' if (d == 'Archive only' or s in arch_only9) else d))
    fam_of = {r[PK[fm]]: fm for fm, rs in B['src_tables'].items() for r in rs}
    fam_of.update({x[2]: x[0] for x in B['plan_v2']})
    for old, new in umap.items():
        if old not in v2fresh:
            recomposed.add((fam_of.get(old, '?'), old, new, 'Archive only'))
    recomposed.add(('show_config_versions', 'd1250003-0000-4000-8000-000000000001', cfg_new[0] if cfg_new else '?', 'Historical in load'))
    if recomposed != {tuple(x) for x in B['plan']}:
        f.append('composed plan differs from the accepted v2 correspondence composed with the frozen identity table')
    # retained rows differ from source only at placeholder positions
    for fam, rows in B['src_tables'].items():
        loaded = idx(L[fam], PK[fam])
        for r in rows:
            k = r[PK[fam]]
            if plan.get(fam, {}).get(k, (None, ''))[1] == 'Archive only':
                continue
            if k not in loaded:
                f.append('retained row missing: %s %s' % (fam, k))
                continue
            for p, a, b in diff(r, loaded[k]):
                if a is None and b is not None and b != '<absent>':
                    continue
                if a == 'pending_I2B':
                    continue
                if a == '<absent>' and p.endswith('/input_fingerprint_disposition') and fam == 'artifacts':
                    continue
                # captured manifest(s): request_bytes_available false -> true only (the planner manifest is retained verbatim)
                if fam == 'artifacts' and p == '/canonical_payload/retention/request_bytes_available' and a is False and b is True and str(loaded[k]['artifact_type']).startswith('prompt_manifest'):
                    owner = [r for r in L['prompt_manifests'] if r['artifact_id'] == k]
                    specimens = [r for r in B['requests']['requests'] if len(owner) == 1 and r['prompt_manifest_id'] == owner[0]['prompt_manifest_id']]
                    if len(specimens) == 1 and H(specimens[0]['rendered_request'].encode('utf-8')) == owner[0]['rendered_request_hash']:
                        continue
                f.append('retained row changed beyond placeholder fill: %s %s %s' % (fam, k, p))
    # FK resolution
    ix = {fam: {r[PK[fam]] for r in rows} for fam, rows in L.items() if fam in PK}
    for fam, fks in FK.items():
        for r in L.get(fam, []):
            for col, tgt in fks.items():
                if col not in r:
                    f.append('missing FK column %s.%s' % (fam, col))
                elif r[col] is not None and r[col] not in ix[tgt]:
                    f.append('dangling FK %s.%s -> %s' % (fam, col, tgt))
    return f


def g_knowledge(B, f=None):
    f = [] if f is None else f
    R = source_chain(B)
    L = B['load']
    ev = idx(L['evidence_units'], 'evidence_unit_id')
    for k, h in R['ev'].items():
        if ev[k]['content_hash'] != h:
            f.append('evidence body hash mismatch ' + k)
    cl = idx(L['claims'], 'claim_id')
    for k in R['cc']:
        if cl[k]['content_hash'] != R['cc'][k]:
            f.append('claim content hash mismatch ' + k)
    dr = L['derivation_runs'][0]
    if dr['output_hash'] != R['deriv']:
        f.append('derivation output hash mismatch')
    # independent recomputation of the derivation from the five window bodies
    minutes = []
    for ref in dr['exact_input_refs']:
        body = [r['canonical_content'] for r in B['src']['evidence_store']['rows'] if r['evidence_unit_id'] == ref['evidence_unit_id']][0]
        m = re.search(r'minute (\d+)', body)
        minutes.append(int(m.group(1)) if m and 'did not' not in body else None)
        if ref['content_hash'] != R['ev'][ref['evidence_unit_id']]:
            f.append('derivation input hash mismatch')
    if {'after_minute': 80, 'count': sum(1 for x in minutes if x and x > 80), 'sample_size': len(minutes)} != dr['output']:
        f.append('derivation output does not reproduce from window bodies')
    sp = idx(L['claim_supports'], 'claim_support_id')
    for k, h in R['sup'].items():
        if sp[k]['support_hash'] != h:
            f.append('support hash mismatch ' + k)
        s = sp[k]
        want = {'evidence': 'evidence_unit_id', 'derivation': 'derivation_run_id', 'signal': 'external_support_identity',
                'continuity': 'external_support_identity'}[s['support_kind']]
        others = {'evidence_unit_id', 'derivation_run_id', 'external_support_identity'} - {want}
        if s[want] is None or any(s[o] is not None for o in others):
            f.append('support target kind mismatch ' + k)
    for c in L['claims']:
        if c['initial_status'] != 'confirmed':
            f.append('claim initial status ' + c['claim_id'])
    if L['claim_state_events']:
        f.append('base claim events inserted')
    from collections import Counter
    if len(L['evidence_units']) != 16 or len(L['rights_versions']) != 7 or len(L['claims']) != 9 or len(L['derivation_runs']) != 1 or len(L['claim_supports']) != 9:
        f.append('evidence/rights/claim/derivation/support counts are not 16/7/9/1/9')
    if Counter(c['initial_usage_class'] for c in L['claims']) != Counter({'assertable': 7, 'hedged_only': 1, 'silent': 1}):
        f.append('claim usage classes are not seven assertable, one hedged, one silent')
    if Counter(x['support_kind'] for x in L['claim_supports']) != Counter({'evidence': 6, 'derivation': 1, 'signal': 1, 'continuity': 1}):
        f.append('support edges are not six evidence, one derivation, one signal, one continuity')
    pk = B['members']['evidence_package']
    for c in pk['manifest']['claims']:
        if c['state_event_cursor'] is not None:
            f.append('non-null base cursor')
    # rights coverage
    rights = idx(L['rights_versions'], 'rights_version_id')
    prov = {e['evidence_unit_id']: e for e in pk['manifest']['evidence']}
    for e in L['evidence_units']:
        pol = rights[e['rights_version_id']]['policy']
        if prov[e['evidence_unit_id']]['source_identity'] not in pol['covered_source_identities']:
            f.append('rights version does not cover source of ' + e['evidence_unit_id'])
    # equal-body isolation scenario
    sc = B['members']['scenarios']['scenarios']['equal_body_distinct_identity']['rows']['evidence_units'][0]
    if sc['content_hash'] != R['ev']['d1250007-0000-4000-8000-000000000005'] or sc['evidence_unit_id'] in R['ev']:
        f.append('equal-body scenario evidence hash/identity')
    # member vs artifact payload equality is checked in g_copies
    return f


def scope_ok(scope, show_ids):
    keys = {'competition_ids', 'entity_ids', 'event_ids', 'locale', 'scheduled_default_mode', 'scope_type', 'show_id',
            'target_publication_slot_ref'}
    if set(scope) != keys or scope['scope_type'] != 'event':
        return False
    for k in ('competition_ids', 'entity_ids', 'event_ids'):
        v = scope[k]
        if not isinstance(v, list) or not v or not all(isinstance(x, str) and x.strip() for x in v):
            return False
    for k in ('locale', 'scheduled_default_mode', 'target_publication_slot_ref'):
        if not isinstance(scope[k], str) or not scope[k].strip():
            return False
    return isinstance(scope['show_id'], str) and bool(UUID4.match(scope['show_id'])) and scope['show_id'] in show_ids


def g_package_scope(B, f=None):
    f = [] if f is None else f
    R = source_chain(B)
    pk = B['members']['evidence_package']
    if pk['package_hash'] != R['package'] or DH('evidence-package-v2', pk['manifest']) != R['package']:
        f.append('package hash mismatch')
    if pk['manifest'] != R['package_manifest']:
        f.append('package manifest is not the source manifest plus computed hashes')
    scope = pk['manifest']['scope']
    show_ids = {r['show_id'] for r in B['load']['shows']}
    if not scope_ok(scope, show_ids):
        f.append('scope schema/type/show resolution failure')
    want = H(b'evidence-package-scope-v1\n' + cb(scope))
    if pk['scope_hash'] != want or R['scope'] != want:
        f.append('scope hash mismatch')
    if not HEX.match(str(pk['scope_hash'])):
        f.append('scope hash not 64 lowercase hex')
    # scope hash excluded from package preimage: changing it must not change package hash
    pk2 = copy.deepcopy(pk)
    pk2['scope_hash'] = '0' * 64
    if DH('evidence-package-v2', pk2['manifest']) != R['package']:
        f.append('package hash depends on envelope scope digest')
    # framing negative controls
    if want in (H(b'evidence-package-scope-v1' + cb(scope)), H(b'evidence-package-scope-v1\n' + cb(scope) + b'\n'),
                H(cb(scope))):
        f.append('scope framing not distinguishable')
    ent = set(scope['entity_ids'])
    if not ent <= {e['entity_identity'] for e in pk['manifest']['evidence'] if e['entity_identity']} | set(
            pk['manifest']['selection_provenance']['match_window_proof']['current_event']['participant_entities']):
        f.append('scope entity does not resolve')
    sb = B['scope_bytes']
    if sb != cb(scope) or H(b'evidence-package-scope-v1\n' + sb) != pk['scope_hash']:
        f.append('captured scope projection bytes do not reproduce the scope hash')
    art = idx(B['load']['artifacts'], 'artifact_id')['d1250005-0000-4000-8000-000000000011']
    if art['canonical_payload'] != pk:
        f.append('package artifact payload copy differs from member')
    # NV15 style: timestamp stability
    pk3 = copy.deepcopy(pk)
    pk3['created_at'], pk3['frozen_at'] = '2030-01-01T00:00:00Z', '2030-01-02T00:00:00Z'
    if DH('evidence-package-v2', pk3['manifest']) != R['package']:
        f.append('package hash not timestamp-stable')
    return f


def g_brief_writer_scripts(B, f=None):
    f = [] if f is None else f
    R = source_chain(B)
    M = B['members']
    if M['showrunner_brief']['brief_hash'] != R['brief'] or M['showrunner_brief']['package_hash'] != R['package']:
        f.append('brief hash/package binding mismatch')
    wv = M['writer_view']
    if wv['writer_view_hash'] != R['wv'] or wv != R['wv_obj'] | {'writer_view_hash': R['wv']}:
        f.append('writer view mismatch')
    wdata = {k: v for k, v in wv.items() if k not in ('script_request_id', 'writer_view_hash')}
    if len(wdata) != 19:
        f.append('writer data object is not 19 keys')
    wb = B['writer_bytes']
    if wb != cb(wdata) or H(wb) != M['writer_context_manifest']['serialized_input_hash']:
        f.append('captured writer data bytes do not reproduce serialized_input_hash')
    if M['writer_context_manifest']['serialized_input_hash'] != H(cb(wdata)):
        f.append('serialized writer input hash mismatch')
    cmx = M['writer_context_manifest']
    if cmx['writer_context_manifest_hash'] != R['cm']:
        f.append('context manifest hash mismatch')
    forb = [e['scope_ref'] for e in M['showrunner_brief']['planning_exclusions'] if e['effect'] == 'forbidden_to_writer']
    if any(x in cj(wdata) for x in forb):
        f.append('forbidden ref serialized to writer')
    if cmx['completeness_check']['exclusions_applied_count'] != len(M['showrunner_brief']['planning_exclusions']):
        f.append('applied exclusion count wrong')
    if cmx['required_claim_refs'] != [c['claim_id'] for c in wv['selected_claims']]:
        f.append('required claim refs differ from view')
    if cmx['estimated_input_tokens'] + cmx['reserved_output_tokens'] > cmx['model_context_limit']:
        f.append('declared token budget exceeded')
    for k in ('script_pass1', 'script_craft_revision', 'script_pass2'):
        if M[k]['brief_hash'] != R['brief'] or M[k]['package_hash'] != R['package']:
            f.append('script is not bound to the exact Brief/package hashes: ' + k)
    for k in ('script_pass1', 'script_craft_revision', 'script_pass2'):
        if M[k]['script_hash'] != R[k]:
            f.append('script hash mismatch ' + k)
    if M['script_craft_revision']['revision_parent_content_identity'] != R['script_pass1'] or \
            M['script_pass2']['revision_parent_content_identity'] != R['script_craft_revision'] or \
            M['script_pass1'].get('revision_parent_content_identity') not in (None, '<absent>'):
        f.append('script parent content identity chain wrong')
    sv = idx(B['load']['script_versions'], 'script_version_id')
    ids = []
    for k_ in ('script_pass1', 'script_craft_revision', 'script_pass2'):
        hit = [r_['script_version_id'] for r_ in sv.values() if r_['artifact_id'] == M[k_]['artifact_id']]
        ids.append(hit[0] if len(hit) == 1 else None)
    if [sv.get(i, {}).get('revision_parent_content_identity') for i in ids] != [None, R['script_pass1'], R['script_craft_revision']]:
        f.append('script_versions parent identity column wrong')
    if M['writing_craft_review']['review_hash'] != R['review'] or M['writing_craft_review']['subject_script_hash'] != R['script_pass1']:
        f.append('craft review hash/subject mismatch')
    # words: spoken text equals the preserved predecessor strings; NFC; 51 distinct turn ids
    for k in ('script_pass1', 'script_craft_revision', 'script_pass2'):
        pred = {t['turn_id']: t['spoken_text'] for t in B['pred_scripts'][k]['turns']}
        cur = {t['semantic_turn_id']: t['spoken_text'] for t in M[k]['turns']}
        if cur != pred or any(unicodedata.normalize('NFC', v) != v for v in cur.values()):
            f.append('script words differ from approved predecessor: ' + k)
    if len({t['turn_id'] for t in B['load']['turns']}) != 51:
        f.append('turn ids not 51 distinct')
    # claim-use spans inside text; silent value absent; numeric value support (NV01/NV02)
    fin = idx(B['load']['turns'], 'turn_id')
    claims = idx(B['load']['claims'], 'claim_id')
    for u in B['load']['turn_claim_uses']:
        t = fin[u['turn_id']]
        if not (0 <= u['span_start'] < u['span_end'] <= len(t['spoken_text'])):
            f.append('claim span outside text')
        c = claims[u['claim_id']]
        span = t['spoken_text'][u['span_start']:u['span_end']]
        val = c['value']
        if c['predicate'] == 'possession_percent' and str(val['scalar']) not in span:
            f.append('claim value not supported by its span')
        if c['predicate'] == 'match_result' and u['use_mode'] == 'asserted' and str(val['northbridge_goals']) not in span and 'win' not in span:
            f.append('score claim span unsupported')
        if c['initial_usage_class'] == 'silent':
            f.append('silent claim used in a turn')
    silent = [c for c in B['load']['claims'] if c['initial_usage_class'] == 'silent']
    for t in B['load']['turns']:
        if any(str(c['value'].get('scalar', '')).replace('0.', '') and ('58 percent' in t['spoken_text'] or '0.58' in t['spoken_text']) for c in silent):
            f.append('silent value leaked into a turn')
    return f


def g_prompts_models(B, f=None):
    f = [] if f is None else f
    R = source_chain(B)
    L = B['load']
    arts = idx(L['artifacts'], 'artifact_id')
    pm = idx(L['prompt_manifests'], 'prompt_manifest_id')
    reqs = {r['prompt_manifest_id']: r for r in B['requests']['requests']}
    if len(reqs) != 5:
        f.append('request specimens are not five')
    for pid, rq in R['spec'].items():
        got = reqs[pid]['rendered_request']
        if got != rq:
            f.append('request specimen bytes differ from independent rebuild: ' + pid)
        if H(got.encode('utf-8')) != pm[pid]['rendered_request_hash'] or pm[pid]['rendered_request_hash'] != R['req'][pid]:
            f.append('rendered_request_hash mismatch ' + pid)
    for aid, (payload, h) in R['pm_art'].items():
        a = arts[aid]
        if a['canonical_payload'].get('retention', {}).get('request_bytes_available') is not True:
            f.append('captured request specimen retention availability must be true ' + aid)
        if a['canonical_payload'] != payload or a['content_hash'] != h:
            f.append('prompt manifest artifact payload/hash mismatch ' + aid)
        owners = [r for r in pm.values() if r['artifact_id'] == aid]
        if len(owners) != 1:
            f.append('prompt pairing cardinality wrong for artifact ' + aid)
            continue
        row = owners[0]
        if row['component_versions'] != payload['component_versions'] or row['policy_source_hashes'] != payload['policy_source_hashes'] \
                or row['rendered_request_hash'] != payload['rendered_request_hash']:
            f.append('typed three-field reconciliation failed ' + aid)
        if set(payload) != {'schema_version', 'purpose', 'component_versions', 'template_version', 'policy_source_hashes',
                            'ordered_input_artifacts', 'ordered_input_evidence', 'ordered_input_claims', 'exposure_instructions',
                            'non_source_text', 'provider', 'model_identifier', 'settings', 'rendered_request_hash',
                            'rendered_request_ref', 'retention'}:
            f.append('prompt manifest payload is not the 16-field object')
    mr = idx(L['model_runs'], 'model_run_id')
    calls = idx(L['provider_calls'], 'provider_call_id')
    for m in mr.values():
        if m['semantic_input_hash'] != R['sem'][m['prompt_manifest_id']]:
            f.append('model semantic input hash mismatch ' + m['model_run_id'])
        c = calls[m['provider_call_id']]
        rh = R['req'][m['prompt_manifest_id']]
        if c['request_fingerprint'] != rh or c['logical_request_key'] != 'fixture_stub:%s:%s' % (c['operation'], rh):
            f.append('model provider call fingerprint/key mismatch')
    msi = B['proj']['model_semantic_inputs']['inputs']
    if len(msi) != 5:
        f.append('model semantic input projections are not five')
    for x in msi:
        row = pm[x['prompt_manifest_id']]
        want3 = {'component_versions': row['component_versions'], 'policy_source_hashes': row['policy_source_hashes'],
                 'rendered_request_hash': R['req'][x['prompt_manifest_id']]}
        if x['projection'] != want3 or set(x['projection']) != {'component_versions', 'policy_source_hashes', 'rendered_request_hash'} or \
                x['semantic_input_hash'] != R['sem'][x['prompt_manifest_id']] or x['semantic_input_hash'] != DH('model-semantic-input-v1', want3):
            f.append('captured three-field model semantic projection mismatch ' + x['prompt_manifest_id'])
    # three-field vectors (unchanged conformance vectors)
    base = {'component_versions': {'fixture_prompt': 'fixture-model-prompt-v1'}, 'policy_source_hashes': {'policy': '0' * 64},
            'rendered_request_hash': '1' * 64}
    if DH('model-semantic-input-v1', base) != '02d99899a1ff6b46e960712558ca46521db078edc0e4abfeb7cd4042a28e9b3f':
        f.append('inherited model-semantic-input baseline vector broken')
    return f


def _dir_proj(script_hash, spec, intents, amap):
    out = []
    for i in intents:
        out.append({'scope_type': i['scope_type'], 'scope_ref': amap.get(i['scope_ref'], i['scope_ref']) if i['scope_type'] == 'turn' else i['scope_ref'],
                    'intent_type': i['intent_type'], 'value': i['value'], 'strength': i['strength'], 'timing_anchor': i['timing_anchor']})
    return {'script_hash': script_hash, 'direction_spec_version': spec, 'performance_intents': out}


def g_correction(B, f=None):
    f = [] if f is None else f
    R = source_chain(B)
    R2 = source_chain(B, 'v2')
    L = B['load']
    M = B['members']
    xm = B['xmap']
    src_dir_v2 = B['src_v2']['performance_direction']          # the historical source direction, literal identities
    src_dir = B['src']['performance_direction']                  # the same object translated to the successor identities
    fs2, amap = script_view(B, 'script_pass2')
    _, amap2 = script_view(B, 'script_pass2', 'v2')
    # historical hash: reconstructed from the I2A source bound to the ACCEPTED v2 final script (history), never to the successor script
    src_hash = DH('performance-direction-v1', _dir_proj(R2['script_pass2'], src_dir_v2['direction_spec_version'], src_dir_v2['performance_intents'], amap2))
    proj = json.loads(B['corr_bytes'].decode('utf-8'))
    if B['corr_bytes'] != cb(proj):
        f.append('correction sidecar is not canonical bytes')
    if set(proj) != {'source_direction_hash', 'script_hash', 'direction_spec_version', 'adjudication_record_sha256', 'correction'}:
        f.append('correction projection is not exactly five top-level keys')
    if proj.get('source_direction_hash') != src_hash or proj.get('script_hash') != R['script_pass2']:
        f.append('correction projection source/script binding wrong')
    if proj.get('direction_spec_version') != 'performance-render-0.1.4':
        f.append('direction spec version')
    t14 = [t for t in fs2['turns'] if t['semantic_turn_id'] == 't14'][0]['turn_id']
    if proj.get('correction') != {'source_performance_intent_id': PACE_ID, 'source_scope_ref': t14,
                                  'intent_type': 'pace', 'expected_value': 'measured', 'replacement_value': 'slower'}:
        f.append('correction operation content wrong')
    fp = H(b'performance-direction-correction-input-v1\n' + B['corr_bytes'])
    new = M['performance_direction__successor']
    if new['input_fingerprint'] != fp or not HEX.match(str(new['input_fingerprint'])):
        f.append('corrected input_fingerprint does not recompute from captured bytes')
    if H(B['record']) != proj['adjudication_record_sha256']:
        f.append('adjudication record digest')
    # corrected direction content
    ints = new['performance_intents']
    if len(ints) != 8:
        f.append('corrected direction is not eight intents')
    pace_final = xm[PACE_ID]
    changed = 0
    for a, b in zip(src_dir['performance_intents'], ints):
        ca = {k: v for k, v in a.items() if k != 'performance_intent_id'}
        cb_ = {k: v for k, v in b.items() if k != 'performance_intent_id'}
        if ca != cb_:
            changed += 1
            if not (a['performance_intent_id'] == pace_final and a['value'] == 'measured' and b['value'] == 'slower'
                    and {k: v for k, v in ca.items() if k != 'value'} == {k: v for k, v in cb_.items() if k != 'value'}):
                f.append('an intent other than the bounded pace change differs')
        if b['performance_intent_id'] != a['performance_intent_id']:
            f.append('intent id is not the planned fresh id')
        if b['value'] not in DIRECTION_VOCAB[b['intent_type']]:
            f.append('active intent outside closed vocabulary')
    if changed != 1:
        f.append('expected exactly one changed intent, got %d' % changed)
    if not any(a['value'] not in DIRECTION_VOCAB[a['intent_type']] and a['performance_intent_id'] == PACE_ID for a in src_dir_v2['performance_intents']):
        f.append('historical measured value not detected as invalid')
    want = DH('performance-direction-v1', _dir_proj(R['script_pass2'], new['direction_spec_version'], ints, amap))
    if new['direction_hash'] != want or new['script_hash'] != R['script_pass2']:
        f.append('corrected direction hash mismatch')
    # fingerprint excluded from direction content hash
    n2 = copy.deepcopy(new)
    n2['input_fingerprint'] = '1' * 64
    if DH('performance-direction-v1', _dir_proj(R['script_pass2'], n2['direction_spec_version'], n2['performance_intents'], amap)) != want:
        f.append('direction hash depends on producer fingerprint')
    # historical (retained verbatim; bound to the accepted v2 script, not to the successor script)
    hist = M['performance_direction__historical']
    if hist['direction_hash'] != src_hash or hist['input_fingerprint'] is not None or \
            hist.get('input_fingerprint_disposition') != 'historical_producer_inputs_not_recorded' or hist['script_hash'] != R2['script_pass2']:
        f.append('historical direction nested null disposition/hash wrong')
    if set(hist) - set(src_dir_v2) != {'input_fingerprint_disposition'}:
        f.append('historical envelope gained fields beyond the disposition')
    # lineage and ownership in the load
    arts = idx(L['artifacts'], 'artifact_id')
    ha, na = arts[HIST_DIRECTION_ARTIFACT], arts[new['artifact_id']]
    if na['supersedes_artifact_id'] != ha['artifact_id'] or ha['supersedes_artifact_id'] is not None:
        f.append('supersedes lineage wrong')
    if ha['content_hash'] != src_hash or na['content_hash'] != want or ha['canonical_payload'] != hist or na['canonical_payload'] != new:
        f.append('direction artifact rows do not match members/hashes')
    dv = idx(L['performance_direction_versions'], 'performance_direction_version_id')
    final_sv = [r['script_version_id'] for r in L['script_versions'] if r['artifact_id'] == M['script_pass2']['artifact_id']]
    if len(dv) != 1 or new['performance_direction_version_id'] not in dv:
        f.append('the successor load must hold exactly the corrected direction version (the historical version is archive-only)')
    else:
        nv = dv[new['performance_direction_version_id']]
        if nv['artifact_id'] != na['artifact_id'] or len(final_sv) != 1 or nv['script_version_id'] != final_sv[0]:
            f.append('direction version not bound to the final script (or to its artifact)')
    pi = L['performance_intents']
    own_new = [i for i in pi if i['performance_direction_version_id'] == new['performance_direction_version_id']]
    if len(own_new) != 8 or len(pi) != 8:
        f.append('intent ownership counts wrong')
    for i in own_new:
        if i['intent']['value'] not in DIRECTION_VOCAB[i['intent']['intent_type']]:
            f.append('active intent row outside closed vocabulary')
        if i['turn_id'] != i['intent']['scope_ref']:
            f.append('intent turn_id/scope mismatch')
    # the historical version and its eight intents are archive-only: present verbatim in the archives, absent from the load
    src_pi = idx(B['src_tables']['performance_intents'], 'performance_intent_id')
    hv_id = [r['performance_direction_version_id'] for r in B['src_tables']['performance_direction_versions']][0]
    own_old = [i for i in src_pi.values() if i['performance_direction_version_id'] == hv_id]
    if len(own_old) != 8 or any(x['performance_intent_id'] in {r['performance_intent_id'] for r in pi} for x in own_old) or hv_id in dv:
        f.append('historical direction version/intents are not archive-only')
    ref_text = json.dumps({k: L[k] for k in ('render_manifests', 'audit_runs', 'render_blocks', 'gate_results')}) + json.dumps(
        [a['canonical_payload'] for a in L['artifacts'] if a['artifact_type'] in ('render_manifest', 'semantic_audit_result')])
    for hid in (hv_id, HIST_DIRECTION_ARTIFACT) + tuple(i['performance_intent_id'] for i in own_old):
        if hid in ref_text:
            f.append('historical direction referenced by an active path: ' + hid)
    # inherited actor labels not presented as a new run
    co = new.get('correction_operation', {})
    if co.get('model_run_executed') is not False or co.get('provider_call_executed') is not False or \
            co.get('inherited_producer_labels', {}).get('producer_run_id') != 'fixture_direction_manual_v3' or \
            new.get('producer_run_id') == 'fixture_direction_manual_v3':
        f.append('inherited producer label presented as a new execution')
    if co.get('source_performance_intent_id') != PACE_ID or co.get('source_direction_artifact_id') != HIST_DIRECTION_ARTIFACT:
        f.append('correction operation does not name the archived historical source subjects')
    return f


def sem_audit(mode, sens, turns, cu, eu, usage, intents):
    """independent structural re-implementation; returns (refusal or None, risk_by_anchor)"""
    risk = {}
    sombre = mode != 'normal_post_event' or any(s.get('state') != 'none' for s in sens)
    for i in intents:
        if i['intent_type'] not in DIRECTION_VOCAB or i['value'] not in DIRECTION_VOCAB[i['intent_type']]:
            return 'vocabulary:%s=%s' % (i['intent_type'], i['value']), {}
        if i['scope_ref'] not in turns:
            return 'reference', {}
    for i in intents:
        a = i['scope_ref']
        uses = [u for u in cu if u['semantic_turn_id'] == a]
        qualified = [u for u in uses if usage[u['claim_id']] == 'hedged_only' or u['use_mode'] in ('hedged', 'attributed')]
        quoted = [u for u in eu if u['semantic_turn_id'] == a and u['use_mode'] == 'quoted']
        emph = (i['intent_type'], i['value']) in {('energy_intensity', 'heightened'), ('delivery_affect', 'emphatic'),
                                                     ('delivery_affect', 'incredulous'), ('delivery_affect', 'frustrated'), ('delivery_affect', 'joyful')}
        r = (emph and bool(qualified)) or (i['intent_type'] == 'delivery_affect' and i['value'] != 'neutral' and bool(quoted)) or \
            (i['intent_type'] == 'pace' and i['value'] in ('quicker', 'building') and bool(qualified)) or \
            (sombre and (i['intent_type'], i['value']) in {('delivery_affect', 'gently_amused'), ('delivery_affect', 'joyful'), ('energy_intensity', 'heightened')})
        risk[a] = risk.get(a, False) or r
    return None, risk


def g_audit(B, f=None):
    f = [] if f is None else f
    R = source_chain(B)
    L = B['load']
    M = B['members']
    new = M['performance_direction__successor']
    s, amap = script_view(B, 'script_pass2')
    br = M['showrunner_brief']
    usage = {c['claim_id']: c['initial_usage_class'] for c in L['claims']}
    turns = {t['semantic_turn_id']: t for t in s['turns']}
    ints = _dir_proj(R['script_pass2'], new['direction_spec_version'], new['performance_intents'], amap)['performance_intents']
    refusal, risk = sem_audit(br['selected_mode'], M['evidence_package']['manifest']['sensitivities'], turns, s['turn_claim_uses'],
                              s['turn_evidence_uses'], usage, ints)
    if refusal or any(risk.values()):
        f.append('independent audit does not pass the corrected direction: %s %s' % (refusal, risk))
    hist_ints = _dir_proj(R['script_pass2'], 'x', B['src']['performance_direction']['performance_intents'], amap)['performance_intents']
    r2, _ = sem_audit(br['selected_mode'], [], turns, s['turn_claim_uses'], s['turn_evidence_uses'], usage, hist_ints)
    if not r2 or 'measured' not in r2:
        f.append('independent audit did not refuse the historical measured direction')
    # negative audit specimen: heightened energy on the hedged turn t07 must be flagged
    bad = ints + [{'scope_type': 'turn', 'scope_ref': 't07', 'intent_type': 'energy_intensity', 'value': 'heightened', 'strength': 'standard', 'timing_anchor': None}]
    _, rk = sem_audit(br['selected_mode'], [], turns, s['turn_claim_uses'], s['turn_evidence_uses'], usage, bad)
    if not rk.get('t07'):
        f.append('audit rules fail to flag emphatic energy over a hedged claim')
    aip = {'package_hash': R['package'], 'brief_hash': R['brief'], 'script_hash': R['script_pass2'],
           'performance_direction_hash': new['direction_hash'], 'claims_policy_version': 'claims-0.1.2',
           'writing_policy_version': 'writing-0.2.3', 'performance_policy_version': 'performance-render-0.1.4',
           'auditor_contract_version': 'semantic-auditor-v1'}
    fp = DH('audit-input-v1', aip)
    res = M['semantic_audit_result__successor']
    if res['input_projection'] != aip or res['input_fingerprint'] != fp or res['result'] != 'pass' or res['findings'] != [] or res['fixture_stub'] is not True:
        f.append('audit result input/fingerprint/outcome mismatch')
    want = DH('semantic-audit-result-v1', {k: res[k] for k in ('auditor_kind', 'auditor_version', 'input_projection', 'input_fingerprint', 'result', 'findings', 'fixture_stub')})
    art = idx(L['artifacts'], 'artifact_id')[res['artifact_id']]
    if art['content_hash'] != want or art['canonical_payload'] != res:
        f.append('audit result carrier hash/payload')
    runs = L['audit_runs']
    if len(runs) != 2 or {r['input_fingerprint'] for r in runs} != {fp} or {r['result_artifact_id'] for r in runs} != {res['artifact_id']} or \
            any(r['model_run_id'] is not None for r in runs):
        f.append('audit_runs rows wrong')
    src_ar = idx(B['src_tables']['audit_runs'], 'audit_run_id')
    for r in runs:
        if r['audit_run_id'] in src_ar:
            f.append('audit run reuses a source id')
    rep = B['audit_report']
    if rep.get('human_override') is not None or not rep.get('limitations') or not rep.get('method') or len(rep.get('per_intent', [])) != 8:
        f.append('audit report lacks method/limitations/per-intent review or claims a human override')
    if rep['subject']['input_fingerprint'] != fp:
        f.append('audit report bound to a different fingerprint')
    old = B['src']['audit_result']
    if res['input_fingerprint'] == old.get('input_fingerprint') and old.get('input_fingerprint') is not None:
        f.append('prior audit fingerprint copied')
    return f


def block_plan(B, R):
    """independent render-plan derivation from source script/Brief/voices/pronunciations/successor direction"""
    s, amap = script_view(B, 'script_pass2')
    br = R['brief_obj']
    order = [b['program_block_id'] for b in sorted(br['program_blocks'], key=lambda b: b['sequence'])]
    by_pb = {}
    for t in sorted(s['turns'], key=lambda t: t['sequence']):
        by_pb.setdefault(t['program_block_id'], []).append(t)
    plan = []
    for n, pb in enumerate(order):
        ts = by_pb[pb]
        if n == 0:
            recipe, ctx = 'C0-v1', []
        else:
            recipe, ctx = 'C2-v1', [by_pb[order[n - 1]][-1]]
        plan.append({'sequence': n + 1, 'program_block_id': pb, 'turns': ts, 'recipe': recipe, 'ctx': ctx})
    return plan


def voice_fields(B, participant):
    vp = B['src']['voice_profiles']
    pid = [p['voice_profile_id'] for p in vp['voice_profiles'] if p['participant_identity'] == participant][0]
    v = [x for x in vp['voice_profile_versions'] if x['voice_profile_id'] == pid][0]
    rf = v['render_fields']
    return v['voice_profile_version_id'], {'version': v['version'], 'provider': rf['provider'], 'provider_voice_id': rf['provider_voice_id'],
                                           'provider_model_compatibility': sorted(set(rf['provider_model_compatibility'])),
                                           'render_facing_design': rf['render_facing_design'],
                                           'request_side_voice_controls': rf['request_side_voice_controls']}


def tts_projection(B, R, bp, intents_by_anchor, recipe, adapter, ctx_override=None, voice_override=None, text_override=None):
    s, amap = script_view(B, 'script_pass2')
    pr = B['src']['pronunciations']
    canon = idx(pr['canonical_pronunciations'], 'pronunciation_id')
    rend = idx(pr['pronunciation_renderings'], 'pronunciation_rendering_id')
    scene = B['pred_proj'][0]['projection']['render_facing_persona_or_scene_config']
    ts = bp['turns']
    voices = {}
    for t in ts:
        vid, vf = voice_fields(B, t['participant_id'])
        voices.setdefault(t['participant_id'], vf)
    if voice_override:
        voices = voice_override
    intents = [i for a in [t['semantic_turn_id'] for t in ts] for i in intents_by_anchor.get(a, [])]
    entries, order = {}, []
    turn_ids = [t['turn_id'] for t in ts]
    for a in sorted((x for x in pr['resolved_applications'] if x['turn_id'] in turn_ids), key=lambda x: (turn_ids.index(x['turn_id']), x['span_start'])):
        rr = rend[a['pronunciation_rendering_id']]
        cp = canon[a['pronunciation_id']]
        t = [x for x in ts if x['turn_id'] == a['turn_id']][0]
        if t['spoken_text'][a['span_start']:a['span_end']] != cp['canonical_text']:
            raise ValueError('pronunciation application span does not match the entity text')
        vid_ = voice_fields(B, t['participant_id'])[0]
        if a['voice_profile_version_id'] != vid_ or rr['voice_profile_version_id'] != vid_:
            raise ValueError('pronunciation application bound to the wrong speaker voice version')
        if rr['pronunciation_id'] != a['pronunciation_id']:
            raise ValueError('pronunciation rendering does not derive from the applied canonical version')
        k = a['pronunciation_rendering_id']
        if k not in entries:
            entries[k] = {'entity_identity': cp['entity_identity'], 'canonical_text': cp['canonical_text'], 'canonical_version': cp['canonical_version'],
                          'language': cp['language'], 'ipa': cp['ipa'], 'provider': rr['provider'], 'participant_id': t['participant_id'],
                          'voice_render_identity': voice_fields(B, t['participant_id'])[1], 'rendering_version': rr['version'],
                          'render_text': rr['rendering'], 'applications': []}
            order.append(k)
        entries[k]['applications'].append({'semantic_turn_id': t['semantic_turn_id'], 'start_offset': a['span_start'], 'end_offset': a['span_end']})
    ctx = ctx_override if ctx_override is not None else bp['ctx']
    return {'concrete_model_identity': 'fixture-model-1.0', 'adapter_render_contract_version': adapter,
            'immutable_voice_profile_version_render_fields': voices,
            'speaker_map': [{'semantic_turn_id': t['semantic_turn_id'], 'participant_id': t['participant_id'],
                             'voice_version': voice_fields(B, t['participant_id'])[1]['version']} for t in ts],
            'resolved_generation_settings': {'temperature': '0.7', 'format': 'wav', 'sample_rate_hz': 48000, 'channels': 1},
            'canonical_spoken_text': [{'semantic_turn_id': t['semantic_turn_id'], 'participant_id': t['participant_id'],
                                       'spoken_text': (text_override or {}).get(t['semantic_turn_id'], t['spoken_text'])} for t in ts],
            'approved_performance_intents': intents,
            'bounded_render_context': {'recipe_version': recipe, 'turns': [{'semantic_turn_id': c['semantic_turn_id'], 'participant_id': c['participant_id'],
                                                                            'spoken_text': c['spoken_text']} for c in ctx]},
            'render_facing_persona_or_scene_config': scene,
            'applied_pronunciation_rendering_versions': [entries[k] for k in order],
            'named_text_transform_versions': ['literal-text-escape/v1', 'pronunciation-apply/v1']}


def bh(p):
    return 'v1:' + H(cb(p))


def _intents_by_anchor(intent_list, amap):
    out = {}
    for i in intent_list:
        a = amap[i['scope_ref']] if i['scope_type'] == 'turn' else i['scope_ref']
        out.setdefault(a, []).append({'scope_type': i['scope_type'], 'scope_ref': a, 'intent_type': i['intent_type'], 'value': i['value'],
                                      'strength': i['strength'], 'timing_anchor': i['timing_anchor']})
    return out


def g_render(B, f=None):
    f = [] if f is None else f
    R = source_chain(B)
    L = B['load']
    M = B['members']
    s, amap = script_view(B, 'script_pass2')
    new = M['performance_direction__successor']
    rm = M['render_manifest__successor']
    bps = block_plan(B, R)
    src_rm = B['src']['render_manifest']
    if len(rm['render_blocks']) != 9:
        f.append('manifest is not nine blocks')
    ibyanchor = _intents_by_anchor(new['performance_intents'], amap)
    proj_file = B['proj']['tts_base_projections']['projections']
    ctxf = {c['render_block_sequence']: c for c in B['proj']['render_context_projections']['contexts']}
    rows = idx(L['render_blocks'], 'render_block_id')
    plan = plan_maps(B)['render_blocks']
    voice_uuid = {p['participant_identity']: voice_fields(B, p['participant_identity'])[0] for p in B['src']['voice_profiles']['voice_profiles']}
    intent_ids_by_anchor = {}
    for i in new['performance_intents']:
        intent_ids_by_anchor.setdefault(amap[i['scope_ref']], []).append(i['performance_intent_id'])
    for blk, bp in zip(rm['render_blocks'], bps):
        seq = bp['sequence']
        srcb = [b for b in src_rm['render_blocks'] if b['sequence'] == seq][0]
        if blk['render_block_id'] != srcb['render_block_id'] or blk['render_block_id'] != plan[[o_['render_block_id'] for o_ in B['src_v2']['render_manifest']['render_blocks'] if o_['sequence'] == seq][0]][0]:
            f.append('render block id is not the planned fresh id (%d)' % seq)
        if blk['program_block_id'] != bp['program_block_id'] or blk['ordered_turn_ids'] != [t['turn_id'] for t in bp['turns']]:
            f.append('render block turns/program block wrong (%d)' % seq)
        if len({t['program_block_id'] for t in bp['turns']}) != 1:
            f.append('render block crosses a program block')
        # C0 / C2 rule
        if seq == 1:
            if blk['context_recipe_version'] != 'C0-v1' or blk['resolved_context_refs']['turn_ids'] != []:
                f.append('rb01 is not C0-v1 with empty context')
            cproj = {'recipe_version': 'C0-v1', 'turns': []}
        else:
            if blk['context_recipe_version'] != 'C2-v1':
                f.append('rb%02d recipe is not C2-v1' % seq)
            want_ctx = [bp['ctx'][0]['turn_id']]
            if blk['resolved_context_refs']['turn_ids'] != want_ctx:
                f.append('rb%02d context is not the final turn of the adjacent preceding block' % seq)
            if blk['ordered_turn_ids'][0] != bp['turns'][0]['turn_id'] or bp['turns'][0]['sequence'] != min(t['sequence'] for t in s['turns'] if t['program_block_id'] == bp['program_block_id']):
                f.append('rb%02d does not begin at the first approved turn of its program block' % seq)
            if any(t['program_block_id'] == bp['program_block_id'] for t in bp['ctx']):
                f.append('rb%02d context comes from its own block (C1 usage)' % seq)
            cproj = {'recipe_version': 'C2-v1', 'turns': [{'semantic_turn_id': c['semantic_turn_id'], 'participant_id': c['participant_id'],
                                                           'spoken_text': c['spoken_text']} for c in bp['ctx']]}
        dg = H(b'render-context-v1\n' + cb(cproj))
        if blk['resolved_context_refs']['context_hash'] != dg or ctxf[seq]['context_hash'] != dg or ctxf[seq]['context_projection'] != cproj:
            f.append('context digest mismatch (%d)' % seq)
        # derived plan lists
        want_speak = [{'participant_id': t['participant_id'], 'turn_id': t['turn_id'], 'voice_profile_version_id': voice_uuid[t['participant_id']]} for t in bp['turns']]
        if blk['speaker_map'] != want_speak:
            f.append('speaker map mismatch (%d)' % seq)
        want_int = [iid for t in bp['turns'] for iid in intent_ids_by_anchor.get(t['semantic_turn_id'], [])]
        if blk['applied_performance_intent_ids'] != want_int:
            f.append('applied intent ids mismatch (%d)' % seq)
        # TTS base projection
        try:
            proj = tts_projection(B, R, bp, ibyanchor, bp['recipe'], 'fixture-adapter-contract-v2')
        except Exception as e:
            f.append('projection failed: %s' % e)
            continue
        if list(proj) and len(proj) != 11:
            f.append('projection is not eleven fields')
        h = bh(proj)
        stored = [p for p in proj_file if p['render_block_sequence'] == seq][0]
        if stored['projection'] != proj or stored['base_request_hash'] != h or blk['base_request_hash'] != h:
            f.append('base request hash/projection mismatch (%d)' % seq)
        r = rows[blk['render_block_id']]
        if r['base_request_hash'] != h or r['program_block_id'] != bp['program_block_id'] or r['sequence'] != seq:
            f.append('render_blocks row mismatch (%d)' % seq)
        if [x['turn_id'] for x in r['speaker_map']] != blk['ordered_turn_ids']:
            f.append('render_blocks speaker map differs from manifest')
        # comparator: source profile (C1 label + measured pace)
        srcint = _intents_by_anchor(B['src']['performance_direction']['performance_intents'], amap)
        sp = tts_projection(B, R, bp, srcint, 'C0-v1' if seq == 1 else 'C1-v1', 'fixture-adapter-contract-v2')
        if seq == 1 and bh(sp) != h:
            f.append('rb01 base identity changed by the correction')
        if seq > 1 and bh(sp) == h:
            f.append('rb%02d did not reflect the corrected recipe' % seq)
        if seq == 7:
            combo = {(a, b): bh(tts_projection(B, R, bp, srcint if b == 'measured' else _intents_by_anchor(
                [dict(i, value='slower') if i['performance_intent_id'] == B['xmap'][PACE_ID] else i for i in B['src']['performance_direction']['performance_intents']], amap),
                a, 'fixture-adapter-contract-v2')) for a in ('C1-v1', 'C2-v1') for b in ('measured', 'slower')}
            if len(set(combo.values())) != 4 or combo[('C2-v1', 'slower')] != h:
                f.append('rb07 recipe and pace changes are not both reflected')
    # manifest hash
    mp = {k: v for k, v in rm.items() if k not in ('artifact_id', 'audit_run_id', 'created_at', 'manifest_hash', 'performance_direction_version_id',
                                                   'render_manifest_id', 'script_version_id')}
    mp['render_blocks'] = [{k: v for k, v in b.items() if k not in ('sequence', 'render_block_id', 'state')} for b in rm['render_blocks']]
    if DH('render-manifest-v1', mp) != rm['manifest_hash']:
        f.append('manifest hash mismatch')
    audit = M['semantic_audit_result__successor']
    if rm['audit_gate_fingerprint'] != audit['input_fingerprint'] or rm['performance_direction_hash'] != new['direction_hash'] or rm['script_hash'] != R['script_pass2']:
        f.append('manifest bindings to audit/direction/script wrong')
    if rm['adapter_contract_version'] != src_rm['adapter_contract_version']:
        f.append('adapter contract version bumped')
    mrow = L['render_manifests'][0]
    if mrow['performance_direction_version_id'] != new['performance_direction_version_id'] or mrow['artifact_id'] != rm['artifact_id'] or \
            mrow['audit_run_id'] != rm['audit_run_id'] or mrow['render_manifest_id'] != rm['render_manifest_id']:
        f.append('render_manifests row bindings wrong')
    # exclusion invariants (NV10/NV13): storage ids and take index leave the base hash unchanged
    p1 = tts_projection(B, R, bps[0], ibyanchor, 'C0-v1', 'fixture-adapter-contract-v2')
    if bh(dict(p1)) != bh(json.loads(cj(p1))):
        f.append('projection hash unstable under reserialization')
    # NV11/NV12 sensitivity
    vo = copy.deepcopy(p1['immutable_voice_profile_version_render_fields'])
    k0 = sorted(vo)[0]
    vo[k0]['version'] += 1
    if bh(tts_projection(B, R, bps[0], ibyanchor, 'C0-v1', 'fixture-adapter-contract-v2', voice_override=vo)) == bh(p1):
        f.append('voice version change does not change the base hash')
    p3 = tts_projection(B, R, bps[2], ibyanchor, 'C2-v1', 'fixture-adapter-contract-v2')
    alt = tts_projection(B, R, dict(bps[2], ctx=[dict(bps[2]['ctx'][0], spoken_text=bps[2]['ctx'][0]['spoken_text'] + ' x')]), ibyanchor, 'C2-v1', 'fixture-adapter-contract-v2')
    if bh(alt) == bh(p3) or bh(tts_projection(B, R, bps[3], ibyanchor, 'C2-v1', 'fixture-adapter-contract-v2')) != [p['base_request_hash'] for p in proj_file if p['render_block_sequence'] == 4][0]:
        f.append('context sensitivity/isolation vector failed')
    if bh(tts_projection(B, R, bps[0], ibyanchor, 'C0-v1', 'fixture-adapter-contract-v3')) == bh(p1):
        f.append('adapter version is not part of the base identity')
    return f


def ts(v):
    return v  # ISO-8601 Z strings compare lexicographically


def g_ledger(B, f=None):
    f = [] if f is None else f
    R = source_chain(B)
    L = B['load']
    M = B['members']
    calls, events = L['provider_calls'], L['provider_call_events']
    if len(calls) != 15 or len(events) != 15:
        f.append('reservation/event counts are not 15/15')
    tts = [c for c in calls if c['operation'] == 'tts']
    mod = [c for c in calls if c['operation'] != 'tts']
    if len(tts) != 10 or len(mod) != 5:
        f.append('ledger is not 10 TTS + 5 model')
    src_call_ids = {c['provider_call_id'] for c in B['src_tables']['provider_calls']}
    for c in tts:
        if c['provider_call_id'] in src_call_ids:
            f.append('a source TTS reservation was co-loaded')
    for c in calls:
        if c['operational_try_number'] != 1 or c['retry_of_provider_call_id'] is not None:
            f.append('call is not try 1')
        ev = [e for e in events if e['provider_call_id'] == c['provider_call_id']]
        if len(ev) != 1 or ev[0]['event_type'] != 'succeeded' or ev[0]['actual_cost'] != '0.0000' or ev[0]['currency'] != 'USD':
            f.append('call lacks exactly one succeeded zero-cost USD terminal event')
        elif not (c['started_at'] < ev[0]['ended_at']):
            f.append('event does not follow reservation')
        if c['provider'] == 'fixture_tts' and c['model_identifier'] != 'fixture-model-1.0':
            f.append('TTS model identity')
    rb = idx(L['render_blocks'], 'render_block_id')
    takes = L['render_takes']
    if len(takes) != 10 or len({t['provider_call_id'] for t in takes}) != 10:
        f.append('takes are not ten with unique provider calls')
    pairs = {(t['render_block_id'], t['take_index']) for t in takes}
    if len(pairs) != 10:
        f.append('block/take pairs not unique')
    ccall = idx(calls, 'provider_call_id')
    for t in takes:
        c = ccall[t['provider_call_id']]
        b = rb[t['render_block_id']]
        if c['request_fingerprint'] != b['base_request_hash'] or c['logical_request_key'] != '%s:%d' % (b['base_request_hash'], t['take_index']) or \
                c['intentional_take_index'] != t['take_index']:
            f.append('take/call/block request binding wrong')
        if t['technical_validation']['status'] == 'pass' and t['technical_validation']['reason_code'] is not None:
            f.append('passing take has a reason code')
    # rb06 chain
    seq6 = [b for b in L['render_blocks'] if b['sequence'] == 6][0]
    t6 = sorted([t for t in takes if t['render_block_id'] == seq6['render_block_id']], key=lambda t: t['take_index'])
    if [t['take_index'] for t in t6] != [0, 1] or t6[0]['technical_validation'] != {'reason_code': 'unexpected_truncation', 'status': 'fail'}:
        f.append('rb06 take chain wrong')
    tr = L['reroll_triggers']
    if len(tr) != 1:
        f.append('trigger count')
    else:
        t = tr[0]
        mv = M['mechanical_validation__successor']
        c0, c1 = ccall[t6[0]['provider_call_id']], ccall[t6[1]['provider_call_id']]
        if t['source_provider_call_id'] != c0['provider_call_id'] or c1['reroll_of_provider_call_id'] != c0['provider_call_id'] or \
                c1['reroll_trigger_id'] != t['reroll_trigger_id'] or t['base_request_hash'] != seq6['base_request_hash'] or t['take_index'] != 1 or \
                t['failure_code'] != 'unexpected_truncation' or t['trigger_kind'] != 'mechanical_failure':
            f.append('reroll causal chain wrong')
        if mv['artifact_id'] != t['validation_artifact_id'] or mv['base_request_hash'] != seq6['base_request_hash'] or \
                mv['source_provider_call_id'] != c0['provider_call_id'] or mv['source_render_take_id'] != t6[0]['render_take_id']:
            f.append('mechanical validation bindings wrong')
        ev0 = [e for e in events if e['provider_call_id'] == c0['provider_call_id']][0]
        ev1 = [e for e in events if e['provider_call_id'] == c1['provider_call_id']][0]
        sel = sorted([s for s in L['take_selections'] if s['render_block_id'] == seq6['render_block_id']], key=lambda s: s['created_at'])
        if len(sel) != 2 or [s['decision'] for s in sel] != ['rejected', 'approved'] or sel[1]['supersedes_selection_id'] != sel[0]['take_selection_id'] or \
                sel[0]['render_take_id'] != t6[0]['render_take_id'] or sel[1]['render_take_id'] != t6[1]['render_take_id']:
            f.append('rb06 rejection/approval chain wrong')
            sel = None
        chain = [ev0['ended_at'], mv['validated_at'], t['created_at'], sel[0]['created_at'], c1['started_at'], ev1['ended_at'], sel[1]['created_at']] if sel else None
        if chain and chain != sorted(chain) or (chain and len(set(chain)) != 7) or t['created_at'] != '2026-09-27T13:16:09Z' or c1['started_at'] != '2026-09-27T13:16:11Z':
            f.append('rb06 timestamps not causal/synthetic values')
    # measurements
    mv = M['mechanical_validation__successor']
    if DH('mechanical-validation-result-v1', {k: mv[k] for k in ('validation_policy_version', 'base_request_hash', 'take_index', 'audio_sha256', 'result', 'failure_code', 'measurements')}) != \
            idx(L['artifacts'], 'artifact_id')[mv['artifact_id']]['content_hash']:
        f.append('mechanical validation hash mismatch')
    # selections: exactly one final approved per block; superseded only rb06
    sels = L['take_selections']
    if len(sels) != 10:
        f.append('selections not ten')
    sup = {s['supersedes_selection_id'] for s in sels if s['supersedes_selection_id']}
    for b in L['render_blocks']:
        fin = [s for s in sels if s['render_block_id'] == b['render_block_id'] and s['take_selection_id'] not in sup and s['decision'] == 'approved']
        if len(fin) != 1:
            f.append('block lacks exactly one final approved selection')
        for s in [s for s in sels if s['render_block_id'] == b['render_block_id']]:
            tk = [t for t in takes if t['render_take_id'] == s['render_take_id']][0]
            if tk['render_block_id'] != s['render_block_id']:
                f.append('selection take belongs to another block')
    # two PENDING base attempts, no episode rows
    if any(a['state'] != 'PENDING' for a in L['program_run_attempts']) or len(L['program_run_attempts']) != 2:
        f.append('base attempts are not two PENDING')
    # audio artifacts: twelve rows/artifacts retained; event responses reference distinct audio artifacts
    if len(L['audio_artifacts']) != 12:
        f.append('audio rows not twelve')
    if len({e['response_artifact_id'] for e in events if e['provider_call_id'] in {c['provider_call_id'] for c in tts}}) != 10:
        f.append('TTS responses not ten distinct artifacts')
    # timeline of the synthetic scenario clock
    nd = M['performance_direction__successor']['created_at']
    au = M['semantic_audit_result__successor']['created_at']
    rmc = M['render_manifest__successor']['created_at']
    first_tts = min(c['started_at'] for c in tts)
    perf_g = [g['created_at'] for g in L['gate_results'] if g['result']['fingerprint_stage'] == 'performance']
    if not (B['src']['performance_direction']['created_at'] < nd < min(perf_g) < au < rmc < first_tts):
        f.append('scenario clock order violated (historical<corrected<perf gates<audit<manifest<first TTS)')
    return f


def g_audio_assembly(B, f=None):
    f = [] if f is None else f
    L = B['load']
    M = B['members']
    W = wav_facts(B)
    rows = idx(L['audio_artifacts'], 'audio_artifact_id')
    arts = idx(L['artifacts'], 'artifact_id')
    by_art = {r['artifact_id']: r for r in rows.values()}
    path_of = {}
    for a in arts.values():
        p = a['canonical_payload']
        if a['artifact_id'].startswith('66666666'):
            path_of[a['artifact_id']] = p['path']
    for aid, path in path_of.items():
        w = W[path]
        r = by_art.get(aid)
        if r is None:
            f.append('audio artifact has no audio row (typed id mismatch): ' + aid)
            continue
        if w['rate'] != 48000 or w['channels'] != 1 or w['width'] != 2:
            f.append('WAV not 48 kHz mono 16-bit: ' + path)
        if w['sha'] != r['audio_sha256'] or arts[aid]['content_hash'] != w['sha'] or arts[aid]['canonical_payload']['frame_count'] != w['frames'] or \
                arts[aid]['byte_size'] != w['bytes']:
            f.append('WAV bytes/hash/frames disagree with rows: ' + path)
    if len(path_of) != 12:
        f.append('not twelve audio artifacts')
    for path in path_of.values():
        if B['pred_pins']['members_sha256'].get(path) != W[path]['sha']:
            f.append('WAV is not byte-identical to the predecessor member: ' + path)
    mrow0 = L['master_assembly_maps'][0]
    ar_ = idx(L['audio_artifacts'], 'audio_artifact_id').get(mrow0['master_audio_artifact_id'])
    if not ar_ or ar_['artifact_id'] != B['members']['master_assembly_map__successor']['master_artifact_id']:
        f.append('master map typed ids: audio row and underlying artifact do not agree')
    if W['fixture_audio/rb06_take0.wav']['frames'] != 6240 or W['fixture_audio/rb06_take1.wav']['frames'] != 6959:
        f.append('rb06 take frame counts wrong')
    # recipe
    rc = M['assembly_recipe']
    proj = {k: rc[k] for k in ('assembly_recipe_version', 'ordered_audio_artifact_hashes', 'normalization', 'output_target', 'trim_policy_version',
                               'join_gap_policy_version', 'fade_policy_version', 'static_asset_hashes', 'deterministic_fixture_command')}
    rh = DH('assembly-recipe-v1', proj)
    if rc['assembly_recipe_hash'] != rh or arts[rc['artifact_id']]['content_hash'] != rh:
        f.append('assembly recipe hash mismatch')
    mp = M['master_assembly_map__successor']
    # selected lineage from rows
    takes = idx(L['render_takes'], 'render_take_id')
    sup = {s['supersedes_selection_id'] for s in L['take_selections'] if s['supersedes_selection_id']}
    final = {s['render_block_id']: s for s in L['take_selections'] if s['decision'] == 'approved' and s['take_selection_id'] not in sup}
    pos, pcm, ordered = 0, b'', []
    segs = []
    blocks = sorted(L['render_blocks'], key=lambda b: b['sequence'])
    sting = [a for a in arts.values() if a['artifact_id'].startswith('66666666') and a['canonical_payload']['artifact_kind'] == 'static_asset'][0]
    seq_list = []
    for b in blocks:
        s = final[b['render_block_id']]
        t = takes[s['render_take_id']]
        seq_list.append(('speech', b, s, t))
        if b['sequence'] == 2:
            seq_list.append(('static', None, None, None))
    for kind, b, s, t in seq_list:
        aid = t['audio_artifact_id'] if kind == 'speech' else sting['artifact_id']
        w = W[path_of[aid]]
        seg = {'kind': kind, 'audio_artifact_id': by_art[aid]['audio_artifact_id'], 'artifact_id': aid, 'audio_sha256': w['sha'],
               'render_block_id': b['render_block_id'] if b else None, 'render_take_id': t['render_take_id'] if t else None,
               'take_selection_id': s['take_selection_id'] if s else None, 'program_block_id': b['program_block_id'] if b else None,
               'start_frame': pos, 'end_frame': pos + w['frames']}
        pos += w['frames']
        pcm += w['pcm']
        ordered.append(w['sha'])
        segs.append(seg)
    master_w = W['fixture_audio/master.wav']
    if pos != master_w['frames'] or pcm != master_w['pcm'] or master_w['frames'] != 57119:
        f.append('selected PCM + sting != preserved 57,119-frame master')
    if ordered != rc['ordered_audio_artifact_hashes'] or ordered != mp['selected_audio_hashes']:
        f.append('recipe/map ordered hashes differ from derived selection')
    if len(mp['segments']) != len(segs):
        f.append('segment count')
    else:
        for got, want in zip(mp['segments'], segs):
            for k, v in want.items():
                if got[k] != v:
                    f.append('segment %s mismatch: %s' % (want['kind'], k))
            if got['kind'] == 'static' and (got['render_block_id'] or got['render_take_id'] or got['take_selection_id'] or got['program_block_id']):
                f.append('static segment carries speech refs')
    offs = {}
    for sg in segs:
        if sg['kind'] == 'speech':
            o = offs.setdefault(sg['program_block_id'], [sg['start_frame'], sg['end_frame']])
            o[1] = sg['end_frame']
    if [(o['program_block_id'], o['start_frame'], o['end_frame']) for o in mp['program_block_offsets']] != [(k, v[0], v[1]) for k, v in offs.items()] or \
            [o['program_block_id'] for o in mp['program_block_offsets']] != [b['program_block_id'] for b in B['members']['showrunner_brief']['program_blocks']]:
        f.append('program block offsets wrong')
    mproj = {k: mp[k] for k in ('assembly_recipe_id', 'assembly_recipe_hash', 'master_audio_artifact_id', 'master_artifact_id', 'master_audio_hash',
                                'sample_rate_hz', 'selected_audio_hashes', 'segments', 'program_block_offsets', 'timing_method', 'timing_confidence')}
    mproj['segments'] = [{k: sg[k] for k in ('kind', 'audio_artifact_id', 'artifact_id', 'audio_sha256', 'render_block_id', 'render_take_id',
                                             'take_selection_id', 'program_block_id', 'start_frame', 'end_frame', 'join_metadata')} for sg in mp['segments']]
    mh = DH('master-assembly-map-v1', mproj)
    if mp['master_assembly_map_hash'] != mh or arts[mp['artifact_id']]['content_hash'] != mh or mp['assembly_recipe_hash'] != rh:
        f.append('master map hash mismatch')
    if mp['master_audio_hash'] != master_w['sha'] or mp['master_artifact_id'] != '66666666-6666-4666-8666-000000000112':
        f.append('map master binding wrong')
    mrow = L['master_assembly_maps'][0]
    if mrow['artifact_id'] != mp['artifact_id'] or mrow['master_assembly_map_id'] != mp['master_assembly_map_id'] or \
            mrow['master_audio_artifact_id'] != mp['master_audio_artifact_id']:
        f.append('master_assembly_maps row mismatch')
    # mapping (10 synthetic receipts)
    mapping = B['proj']['fixture_tts_mapping']['entries']
    if len(mapping) != 10:
        f.append('mapping is not ten entries')
    calls = idx(L['provider_calls'], 'provider_call_id')
    evs = {e['provider_call_id']: e for e in L['provider_call_events']}
    tk = {t['provider_call_id']: t for t in L['render_takes']}
    known = {c['request_fingerprint'] + ':' + str(c['intentional_take_index']) for c in calls.values() if c['operation'] == 'tts'}
    for m in mapping:
        c = calls.get(m['provider_call_id'])
        if not c or m['base_request_hash'] + ':' + str(m['intentional_take_index']) not in known:
            f.append('mapping entry for an unknown request')
            continue
        e, t = evs[c['provider_call_id']], tk[c['provider_call_id']]
        w = W[path_of[t['audio_artifact_id']]]
        if m['succeeded_event_id'] != e['provider_call_event_id'] or e['response_artifact_id'] != t['audio_artifact_id']:
            f.append('mapping event/response mismatch')
        if m['response_artifact_id'] != t['audio_artifact_id'] or m['audio_row_id'] != by_art[t['audio_artifact_id']]['audio_artifact_id'] or \
                m['wav_sha256'] != w['sha'] or m['wav_byte_length'] != w['bytes'] or m['wav_member_path'] != path_of[t['audio_artifact_id']] or \
                m['wav_frames'] != w['frames'] or m['base_request_hash'] != c['request_fingerprint'] or m['logical_request_key'] != c['logical_request_key']:
            f.append('mapping does not reconcile to reservation/event/take/audio')
        rc_ = m['receipt']
        if rc_.get('synthetic') is not True or rc_.get('live_provider_contacted') is not False or \
                rc_.get('predecessor_receipt_relabeled_as_new_generation') is not False or rc_.get('claims_audible_performance_fidelity') is not False:
            f.append('receipt does not disclaim live/fidelity claims')
    if len({m['provider_call_id'] for m in mapping}) != 10:
        f.append('mapping duplicates a reservation')
    return f


def stage_projections(B, R):
    L = B['load']
    M = B['members']
    new = M['performance_direction__successor']
    rm = M['render_manifest__successor']
    aud = M['semantic_audit_result__successor']
    mp = M['master_assembly_map__successor']
    rc = M['assembly_recipe']
    cw = {'package_hash': R['package'], 'brief_hash': R['brief'], 'script_hash': R['script_pass2'], 'claims_policy_version': 'claims-0.1.2',
          'writing_policy_version': 'writing-0.2.3', 'gate_set_version': GATE_SET}
    perf = {'script_hash': R['script_pass2'], 'performance_direction_hash': new['direction_hash'], 'performance_policy_version': 'performance-render-0.1.4',
            'gate_set_version': GATE_SET}
    aip = aud['input_projection']
    render = {'render_manifest_hash': rm['manifest_hash'], 'audit_input_fingerprint': DH('audit-input-v1', aip),
              'render_policy_version': 'performance-render-0.1.4', 'gate_set_version': GATE_SET}
    sup = {s['supersedes_selection_id'] for s in L['take_selections'] if s['supersedes_selection_id']}
    take = idx(L['render_takes'], 'render_take_id')
    aud_row = {a['artifact_id']: a['audio_sha256'] for a in L['audio_artifacts']}
    fin = {s['render_block_id']: s for s in L['take_selections'] if s['decision'] == 'approved' and s['take_selection_id'] not in sup}
    lin = [{'render_block_id': b['render_block_id'], 'take_selection_id': fin[b['render_block_id']]['take_selection_id'],
            'render_take_id': fin[b['render_block_id']]['render_take_id'], 'take_index': take[fin[b['render_block_id']]['render_take_id']]['take_index'],
            'audio_sha256': aud_row[take[fin[b['render_block_id']]['render_take_id']]['audio_artifact_id']]}
           for b in sorted(L['render_blocks'], key=lambda b: b['sequence'])]
    asm = {'selected_take_lineage': lin, 'assembly_recipe_hash': DH('assembly-recipe-v1', {k: rc[k] for k in (
        'assembly_recipe_version', 'ordered_audio_artifact_hashes', 'normalization', 'output_target', 'trim_policy_version', 'join_gap_policy_version',
        'fade_policy_version', 'static_asset_hashes', 'deterministic_fixture_command')}),
        'master_assembly_map_hash': mp['master_assembly_map_hash'], 'assembly_policy_version': 'performance-render-0.1.4', 'gate_set_version': GATE_SET}
    cfg = DH('show-config-v1', current_config(B)['canonical_payload'])
    rd = B['src']['ready_expectations']
    ready = {'master_artifact_id': rd['master_artifact_id'], 'master_audio_sha256': mp['master_audio_hash'],
             'assembly_gate_fingerprint': DH('assembly-gate-input-v1', asm), 'program_run_id': rd['program_run_id'], 'attempt_id': rd['attempt_id'],
             'show_config_version_hash': cfg, 'review_gate_version': '1', 'gate_set_version': GATE_SET}
    return {'claims_writing': ('claims-writing-gate-input-v1', cw), 'performance': ('performance-gate-input-v1', perf),
            'semantic_audit': ('audit-input-v1', aip), 'render': ('render-gate-input-v1', render),
            'assembly': ('assembly-gate-input-v1', asm), 'ready_candidate': ('ready-candidate-v1', ready)}, cfg


def g_gates_ready(B, f=None):
    f = [] if f is None else f
    R = source_chain(B)
    L = B['load']
    M = B['members']
    plan = plan_maps(B)['gate_results']
    stages, cfg = stage_projections(B, R)
    fp = {k: DH(d, p) for k, (d, p) in stages.items()}
    stored = B['proj']['stage_fingerprints']
    for k, v in fp.items():
        if stored[k]['fingerprint'] != v or stored[k]['input_projection'] != stages[k][1]:
            f.append('stage fingerprint file mismatch: ' + k)
    if fp['claims_writing'] != DH('claims-writing-gate-input-v1', stages['claims_writing'][1]) or len(set(fp.values())) != 6:
        f.append('six stage fingerprints not distinct/valid')
    gd = idx(L['gate_definitions'], 'gate_definition_id')
    gates = L['gate_results']
    if len(gates) != 62:
        f.append('gate rows not 62')
    src_g = idx(B['src_tables']['gate_results'], 'gate_result_id')
    counts = {'claims_writing': 0, 'performance': 0, 'render': 0, 'assembly': 0}
    replaced = {'claims_writing': 0, 'performance': 0, 'render': 0, 'assembly': 0}
    ids = {g['gate_result_id'] for g in gates}
    for sid, (fresh, d) in plan.items():
        if sid in ids:
            f.append('replaced gate row co-loaded: ' + sid)
        if fresh not in ids:
            f.append('replacement gate row missing: ' + fresh)
    for g in gates:
        st = g['result']['fingerprint_stage']
        counts[st] += 1
        if g['input_fingerprint'] != fp[st]:
            f.append('gate row fingerprint wrong: %s %s' % (st, g['gate_result_id']))
        name = gd[g['gate_definition_id']]['gate_name']
        if name.split('.')[0] != {'claims_writing': None}.get(st, st) and not (st == 'claims_writing' and name.split('.')[0] in ('claims', 'writing')):
            f.append('gate definition/stage mismatch: ' + name)
        if g['outcome'] != 'pass':
            f.append('gate outcome not pass')
        if g['gate_result_id'] in src_g:
            f.append('a source gate row id was retained (every gate row owns a fresh attempt): ' + g['gate_result_id'])
        else:
            replaced[st] += 1
            if st == 'claims_writing' and g['result']['subject_refs'] != [[r_['script_version_id'] for r_ in L['script_versions'] if r_['artifact_id'] == M['script_pass2']['artifact_id']][0]]:
                f.append('claims/writing gate subject is not the final script version')
            if st == 'performance' and g['result']['subject_refs'] != [M['performance_direction__successor']['performance_direction_version_id']]:
                f.append('performance gate subject not the corrected direction version')
            if st == 'render' and g['result']['subject_refs'] != [M['render_manifest__successor']['render_manifest_id']]:
                f.append('render gate subject not the successor manifest')
            if st == 'assembly' and g['result']['subject_refs'] != ['66666666-6666-4666-8666-000000000112']:
                f.append('assembly gate subject')
            if 'fixture_revalidation_refs' in g['result'] and g['result']['fixture_revalidation_refs']['result_artifact_id'] != M['revalidation_result__successor']['artifact_id']:
                f.append('revalidation refs not rebound')
    if counts != {'claims_writing': 36, 'performance': 14, 'render': 8, 'assembly': 4} or replaced != {'claims_writing': 36, 'performance': 14, 'render': 8, 'assembly': 4}:
        f.append('gate stage counts wrong: %s / %s' % (counts, replaced))
    # READY / revalidation
    rv = M['revalidation_result__successor']
    if rv['ready_candidate_fingerprint'] != fp['ready_candidate'] or rv['snapshot_hash'] != R['snapshot'] or rv['publication_enabled'] is not False or rv['publishing_transition_allowed'] is not False:
        f.append('revalidation result bindings wrong')
    rvh = DH('fixture-revalidation-result-v1', {k: rv[k] for k in ('adapter', 'fixture_stub', 'ready_candidate_fingerprint', 'snapshot_artifact_id',
                                                                    'snapshot_hash', 'result', 'expires_at', 'publication_enabled', 'next_allowed_state',
                                                                    'publishing_transition_allowed')})
    if idx(L['artifacts'], 'artifact_id')[rv['artifact_id']]['content_hash'] != rvh:
        f.append('revalidation result carrier hash')
    sn = idx(L['artifacts'], 'artifact_id').get('d1250005-0000-4000-8000-000000000022')
    if not sn or sn['content_hash'] != R['snapshot'] or sn['canonical_payload'].get('source_package_hash') != R['package']:
        f.append('retained synthetic revalidation snapshot missing or stale')
    if 'd1250005-0000-4000-8000-000000000015' not in {a['artifact_id'] for a in L['artifacts']}:
        f.append('assembly recipe artifact not retained')
    ra = M['ready_expectations']
    if ra['ready_candidate_fingerprint'] != fp['ready_candidate'] or ra['query_parameters']['3'] != fp['ready_candidate'] or \
            ra['ready_transition']['parameters']['2'] != fp['ready_candidate']:
        f.append('READY expectations not bound to the candidate fingerprint')
    if current_config(B)['config_hash'] != cfg or ra['show_config_version_id'] != current_config(B)['show_config_version_id']:
        f.append('show config hash / READY expectations config binding')
    if any(a['state'] != 'PENDING' for a in L['program_run_attempts']):
        f.append('attempt state')
    return f


def g_obligations(B, f=None):
    f = [] if f is None else f
    L = B['load']
    obl = B['obl']
    plan = plan_maps(B)
    des = B['src']['deferred_hash_fields']['fields']
    if len(des) != 176:
        f.append('source register is not 176')
    n = 0
    for e in des:
        t, rid, fld = e['table'], e['record_id'], e['field']
        fresh, d = plan.get(t, {}).get(rid, (None, None))
        rec = fresh if d == 'Archive only' else rid
        row = idx(L[t], PK[t]).get(rec)
        if row is None:
            f.append('typed obligation record missing: %s %s' % (t, rec))
            continue
        v = row[fld]
        if not (isinstance(v, str) and (HEX.match(v) or BASEH.match(v) or ':' in v)):
            f.append('typed obligation not a computed value: %s.%s %s' % (t, fld, rec))
        n += 1
    extra = idx(L['artifacts'], 'artifact_id')[fresh_of(B, 'artifacts', HIST_DIRECTION_ARTIFACT)]
    if not HEX.match(str(extra['content_hash'])):
        f.append('additional corrected-direction artifact hash missing')
    cfg_new = current_config(B)
    if not HEX.match(str(cfg_new['config_hash'])):
        f.append('additional new show-config hash missing')
    if n + 2 != 178:
        f.append('successor typed entries are not 178')
    if obl['summary']['successor_typed_entries'] != 178 or obl['summary']['source_typed_entries'] != 176:
        f.append('reconciliation file counts differ')
    hn = obl['summary']['historical_null']
    if hn != {'fields': 1, 'storage_copies': 2, 'counted_in_typed_entries': False, 'counted_as_computed': False}:
        f.append('historical null accounting wrong')
    # independent null scan: every hash-ish null in members and rows is classified
    allowed_leaf = {'speaker_identity', 'event_identity', 'external_support_identity', 'revision_parent_content_identity',
                    'ready_candidate_fingerprint', 'source_ready_fingerprint', 'episode_version_id', 'timing_anchor'}
    hashish = re.compile(r'hash|fingerprint|request_key|identity$|_frame$|frame$')
    nulls = []
    for name, obj in list(B['members'].items()) + [('LOAD', B['load'])]:
        for p, v in walk(obj):
            leaf = p.rsplit('/', 1)[-1]
            if v is None and hashish.search(leaf) and leaf not in allowed_leaf:
                nulls.append((name, p))
    hist_nulls = [x for x in nulls if x[1].endswith('/input_fingerprint')]
    other = [x for x in nulls if not x[1].endswith('/input_fingerprint')]
    if other:
        f.append('unclassified hash-shaped nulls: %s' % other[:5])
    if len(hist_nulls) != 2:
        f.append('historical input_fingerprint null must appear exactly twice (member + artifact copy), got %d' % len(hist_nulls))
    for name, p in hist_nulls:
        if 'historical' not in name.lower() and not p.startswith('/artifacts/'):
            f.append('input_fingerprint null outside the historical direction: %s %s' % (name, p))
    # legit-null rules: external_support_identity null iff evidence/derivation; root script has no parent identity
    for s in L['claim_supports']:
        if (s['external_support_identity'] is None) != (s['support_kind'] in ('evidence', 'derivation')):
            f.append('external_support_identity null rule violated')
    roots = [s for s in L['script_versions'] if s['revision_parent_id'] is None]
    if len(roots) != 1 or roots[0]['revision_parent_content_identity'] is not None:
        f.append('root script parent identity rule')
    for s in L['script_versions']:
        if s['revision_parent_id'] is not None and not HEX.match(str(s['revision_parent_content_identity'])):
            f.append('child script lacks parent content identity')
    for name in ('pending_I2B',):
        if name in json.dumps(B['members']) or name in json.dumps(L):
            f.append('unresolved pending marker remains')
    return f


def g_archive_hist(B, f=None):
    f = [] if f is None else f
    L = B['load']
    # history carried unchanged from the accepted I2B v2: 85 archive-only rows and the 10 historical direction rows (source rows verbatim)
    if len(B['archive']) != 85 or len(B['hist']) != 10:
        f.append('archive/historical row counts')
    for r in B['archive'] + B['hist']:
        src = idx(B['src_tables'][r['family']], PK[r['family']]).get(r['source_id'])
        if src is None or r['source_row'] != src or r['source_row_canonical_sha256'] != H(cb(src)):
            f.append('archive row differs from preserved source: ' + r['source_id'])
    loaded = {r[PK[k]] for k, rows in L.items() for r in rows}
    ft = B['frozen_table']
    umap = {p['old_id']: p['proposed_id'] for p in ft['proposals'] if p['old_id'] and not p['family'].startswith('scenario:')}
    # the 283 accepted v2 rows replaced (274) or archived without successor (9)
    a283 = B['archive283']
    if len(a283) != 283:
        f.append('archived v2 rows are not 283')
    arch9 = {d['old_id'] for d in (B['disp'] or {}).get('rows', []) if d.get('disposition') == 'archive_only_no_successor'}
    seen_ids = set()
    for r in a283:
        if r['v2_row_canonical_sha256'] != H(cb(r['v2_row'])):
            f.append('archived v2 row hash differs from its row: ' + r['v2_id'])
        if r['v2_id'] in loaded:
            f.append('archived v2 row is loaded: ' + r['v2_id'])
        if r['v2_id'] in umap:
            if r['successor_id'] != umap[r['v2_id']] or r['disposition'] != 'replaced_fresh' or r['successor_id'] not in loaded:
                f.append('archived v2 row successor differs from the frozen table / is not loaded: ' + r['v2_id'])
        elif r['v2_id'] in arch9:
            if r['successor_id'] is not None or r['disposition'] != 'archive_only_no_successor':
                f.append('archive-only v2 row has a successor: ' + r['v2_id'])
        else:
            f.append('archived v2 row is neither replaced nor archive-only per the frozen plan: ' + r['v2_id'])
        seen_ids.add(r['v2_id'])
    if seen_ids != set(umap) | arch9:
        f.append('archived v2 rows differ from the 274 replacements + 9 archive-only rows of the plan')
    # archival accounting arithmetic derived from the shipped data
    src_ids = {r_[PK[fm]] for fm, rs in B['src_tables'].items() for r_ in rs}
    v2fresh = {x[2] for x in B['plan_v2']}
    union = src_ids | v2fresh
    proposals = {p['proposed_id'] for p in ft['proposals']}
    if len(src_ids) != 396 or len(v2fresh) != 95 or len(union) != 491 or len(proposals) != 283 or len(union | proposals) != 774 or len((union | proposals) - loaded) != 376:
        f.append('archival accounting does not reconcile (I2A 396, v2 fresh 95, union 491, proposals 283, union+proposals 774, outside the load 376)')
    if any(r['source_id'] in loaded for r in B['archive']):
        f.append('archive-only row loaded')
    return f


def g_scenarios_gaps(B, f=None):
    f = [] if f is None else f
    sc = B['members']['scenarios']['scenarios']
    if len(sc) != 7:
        f.append('scenarios not seven')
    text = json.dumps(B['members']['scenarios'])
    old_ids = {p['old_id'] for p in B['frozen_table']['proposals'] if p['old_id']} | {x[1] for x in B['plan']}
    for s in sorted(old_ids):
        if s in text:
            f.append('isolated scenario still references superseded id ' + s)
    new_ids = {p['proposed_id'] for p in B['frozen_table']['proposals'] if p['family'].startswith('scenario:')}
    if not all(u in text for u in new_ids):
        f.append('isolated scenarios do not carry their fresh scenario row ids')
    cur = current_config(B)
    if 'd1250003-0000-4000-8000-000000000001' in text or cur['show_config_version_id'] not in text:
        f.append('isolated scenarios are not bound to the current configuration version')
    loaded_ids = {r[PK[k]] for k, rows in B['load'].items() for r in rows}
    for name, s in sc.items():
        for tbl, rows in s.get('rows', {}).items():
            pkn = {'program_run_attempts': 'attempt_id', 'evidence_units': 'evidence_unit_id', 'claim_state_events': 'claim_state_event_id'}.get(tbl)
            for r in rows:
                rid = r.get(pkn) if pkn else next((v for k, v in r.items() if k.endswith('_id') and k.startswith(tbl[:-1])), None)
                if rid in loaded_ids:
                    f.append('isolated alternative row co-loaded: %s %s' % (tbl, rid))
    for r in sc['performance_repair']['rows']['repair_plans'][0]['typed_plan']['affected_artifact_refs']:
        if r == 'd1250005-0000-4000-8000-000000000012':
            f.append('repair plan targets the historical direction')
    if sc['performance_repair']['rows']['program_run_attempts'][0]['state'] != 'PENDING' or sc['programming_repair']['rows']['program_run_attempts'][0]['state'] != 'PENDING':
        f.append('repair child not PENDING')
    ev = sc['usage_change']['rows']['claim_state_events'][0]
    if ev['event_sequence'] != 1:
        f.append('isolated usage event sequence')
    if B.get('gap_md') is None:
        f.append('deferred runtime gap record missing')
    else:
        t = B['gap_md'].decode('utf-8').lower()
        for need in ('provider_call_id', 'unique', 'acceptance test', 'does not prove'):
            if need not in t:
                f.append('deferred gap record lacks: ' + need)
    return f


def g_copies(B, f=None):
    f = [] if f is None else f
    arts = idx(B['load']['artifacts'], 'artifact_id')
    seen = set()
    for a in arts.values():
        if a['artifact_id'].startswith('66666666'):
            continue
        matches = [k for k, m in B['members'].items() if m == a['canonical_payload']]
        if not matches:
            f.append('artifact payload has no equal member copy: ' + a['artifact_id'])
        seen.update(matches)
    return f


def g_artifact_consumers(B, f=None):
    f = [] if f is None else f
    L = B['load']
    ids = {a['artifact_id'] for a in L['artifacts']}
    used = {}

    def use(aid, why):
        if aid in ids:
            used.setdefault(aid, []).append(why)
    for fam, fks in FK.items():
        for r in L.get(fam, []):
            for col, tgt in fks.items():
                if tgt == 'artifacts' and r.get(col) is not None and fam != 'artifacts':
                    use(r[col], fam + '.' + col)
    for a in L['artifacts']:
        for col in ('parent_artifact_id', 'supersedes_artifact_id'):
            if a.get(col):
                use(a[col], 'artifacts.' + col)
    for r in L['claim_supports']:
        if r['external_support_identity']:
            use(r['external_support_identity'].split(':', 1)[1], 'claim_supports.external_support_identity')
    for a in L['artifacts']:
        p = a['canonical_payload']
        if isinstance(p, dict):
            for ia in p.get('ordered_input_artifacts', []) or []:
                use(ia['artifact_id'], 'prompt_manifest.ordered_input_artifacts')
    for g in L['gate_results']:
        refs = g['result'].get('fixture_revalidation_refs')
        if refs:
            use(refs['result_artifact_id'], 'gate_results.fixture_revalidation_refs')
            use(refs['snapshot_artifact_id'], 'gate_results.fixture_revalidation_refs')
    rv = B['members'].get('revalidation_result__successor')
    if rv:
        use(rv['snapshot_artifact_id'], 'revalidation result snapshot ref')
    for aid in ids:
        if aid not in used:
            f.append('orphan artifact without a durable consumer: ' + aid)
    return f


def g_identity_provenance(B, f=None):
    f = [] if f is None else f
    L = B['load']
    tot, reg, prov = B['totals'], B['registry'], B['provenance']
    plan = plan_maps(B)
    want_total = {'source': 0, 'archive': 0, 'fresh': 0, 'loaded': 0}
    by = {r['family']: r for r in tot['families']}
    for fam in B['src_tables']:
        mp = plan.get(fam, {})
        a = sum(1 for v in mp.values() if v[1] == 'Archive only')
        got = by.get(fam)
        if not got or (got['source_rows'], got['archive_only_source_rows'], got['fresh_rows'], got['successor_loaded_rows']) != \
                (len(B['src_tables'][fam]), a, len(mp), len(L[fam])):
            f.append('family totals row wrong: ' + fam)
        for k, v in (('source', len(B['src_tables'][fam])), ('archive', a), ('fresh', len(mp)), ('loaded', len(L[fam]))):
            want_total[k] += v
    if tot['total'] != want_total or want_total != {'source': 396, 'archive': 273, 'fresh': 275, 'loaded': 398}:
        f.append('family totals do not reconcile to 396/273/275/398')
    for fam, rows in L.items():
        got = [r['id'] for r in reg['families'][fam]['rows']] if fam in reg['families'] else None
        if got != [r[PK[fam]] for r in rows]:
            f.append('identity registry differs from load: ' + fam)
    if reg['counts']['rows'] != 398 or reg['counts']['fresh'] != 275 or reg['counts']['historical_in_load'] != 2 or reg['counts']['retained_source'] != 121:
        f.append('identity registry origin counts wrong: %s' % reg['counts'])
    R = source_chain(B)
    R2 = source_chain(B, 'v2')
    proj = json.loads(B['corr_bytes'].decode('utf-8'))
    new = B['members']['performance_direction__successor']
    b = prov['bindings']
    if b['adjudication_record_sha256'] != H(B['record']) or b['correction_projection_sha256'] != H(B['corr_bytes']) or \
            b['correction_input_fingerprint'] != new['input_fingerprint'] or b['corrected_direction_hash'] != new['direction_hash'] or \
            b['source_direction_hash'] != proj['source_direction_hash'] or b['script_hash'] != R['script_pass2']:
        f.append('correction provenance bindings differ from recomputed values')
    if 'not a model run' not in prov['correction_executor'] or 'no Mike approval' not in prov['technical_adjudicator']:
        f.append('provenance misattributes authorship')
    if prov['inherited_producer_labels']['producer_run_id'] != 'fixture_direction_manual_v3' or 'NOT re-executed' not in prov['inherited_producer_labels']['statement']:
        f.append('provenance presents the inherited label as executed')
    t = prov['observed_times_utc']
    if not (t['pre_execution_verification_written'] <= t['resolution_record_frozen'] <= t['correction_and_downstream_build_last_run']):
        f.append('observed times violate dependency order (verification <= freeze <= correction)')
    c3 = prov.get('config330', {})
    cur, old = current_config(B), [r for r in L['show_config_versions'] if r['version_number'] == 1][0]
    if c3.get('new_config_hash') != cur['config_hash'] or c3.get('old_config_hash') != old['config_hash'] or c3.get('new_config_version_id') != cur['show_config_version_id'] or \
            c3.get('frozen_identity_table_sha256') != H(B['table_bytes']):
        f.append('configuration/identity-table bindings in the provenance differ from the shipped data')
    # the v2 history files are carried verbatim and describe the accepted v2 chain
    v2p = B['v2_provenance']
    if v2p['bindings']['script_hash'] != R2['script_pass2'] or v2p['bindings']['source_direction_hash'] != proj['source_direction_hash']:
        f.append('accepted v2 provenance disagrees with the recomputed v2 chain')
    return f


def g_inherited_vectors(B, f=None):
    f = [] if f is None else f
    three = ('component_versions', 'policy_source_hashes', 'rendered_request_hash')
    mv = B['model_vectors']
    def mh(m):
        return DH('model-semantic-input-v1', {k: m[k] for k in three})
    if mh(mv['baseline_manifest']) != mv['baseline_hash']:
        f.append('model baseline vector hash mismatch')
    if len(mv['vectors']) != 24:
        f.append('model vectors are not 24')
    n_same = n_diff = 0
    for row in mv['vectors']:
        _n0 = len(f)
        proj = {k: row['manifest'][k] for k in three}
        if proj != row['expected_projection']:
            f.append('model vector projection mismatch: ' + str(row.get('id', row.get('name', '?'))))
        if mh(row['manifest']) != row['expected_hash']:
            f.append('model vector hash mismatch: ' + str(row.get('id', row.get('name', '?'))))
        rel = 'same' if row['expected_hash'] == mv['baseline_hash'] else 'different'
        if rel != row['expected_relation_to_baseline']:
            f.append('model vector relation mismatch: ' + str(row.get('id', row.get('name', '?'))))
        n_same += rel == 'same'
        n_diff += rel == 'different'
        _log(B, 'G20', {'id': row.get('id', row.get('name', '?')), 'class': 'model_semantic_vector', 'outcome': 'as_expected' if len(f) == _n0 else 'UNEXPECTED'})
    if n_same + n_diff != 24 or n_diff < 3:
        f.append('model vectors lack the sensitivity/stability split')
    # the three-field contract: nothing but the three fields may reach the digest
    base = mv['baseline_manifest']
    if mh(dict(base, operational_try_number=99, provider='x', output_artifact_id='y')) != mv['baseline_hash']:
        f.append('excluded model metadata reached the semantic input hash')
    uv = B['unicode_vectors']
    _k0 = len(f)
    if cj(uv['key_order_input']) != uv['canonical_json_utf8']:
        f.append('unicode key-order vector mismatch (code-point order)')
    ordered = list(json.loads(uv['canonical_json_utf8']).keys())
    if [ord(c[0]) for c in ordered] != sorted(ord(c[0]) for c in ordered):
        f.append('unicode key order is not code-point ascending')
    _log(B, 'G20', {'id': 'unicode_key_order', 'class': 'unicode_key_order_vector', 'outcome': 'as_expected' if len(f) == _k0 else 'UNEXPECTED'})
    sv = uv.get('span_vectors', [])
    if len(sv) != 2:
        f.append('unicode span vectors are not two')
    for _i, v in enumerate(sv):
        _s0 = len(f)
        if unicodedata.normalize('NFC', uv['spoken_text'])[v['start']:v['end']] != v['substring']:
            f.append('unicode span vector mismatch')
        _log(B, 'G20', {'id': 'unicode_span_%d' % (_i + 1), 'class': 'unicode_span_vector', 'outcome': 'as_expected' if len(f) == _s0 else 'UNEXPECTED'})
    return f


def g_repair_provenance(B, f=None):
    """G21 (portable, CONFIG-330): the accepted I2B v2 history is carried verbatim and verified against the independently recomputed v2 chain; the successor's
    own manifest-hash transitions and unchanged-value claims are verified against the successor chain. Pinned hashes live inside the package."""
    f = [] if f is None else f
    prov = B['repair_prov']
    R = source_chain(B)
    R2 = source_chain(B, 'v2')
    # accepted v2 complete-manifest hashes (the supervisory expectation recorded in the accepted I2B v2 repair)
    exp_v2 = {'d1250005-0000-4000-8000-000000000006': '2ccd6642e971afd74ad4376a92f0319b8909d62d854daf6e99501893e9d7c952',
              'd1250005-0000-4000-8000-000000000007': '3de1217d4b3fa7b47f4cf1bf48e9f9eb565c57056ca6335c589ce6234b171d53',
              'd1250005-0000-4000-8000-000000000008': '78e629c5d6a9389981d3e152df990066cdf552b969b4642b86a2d324e3098c03',
              'd1250005-0000-4000-8000-000000000009': '370ebeffc9c0f35b5d5433ca077d29a9847386e3b9adbd70db384e0f025106dc',
              'd1250005-0000-4000-8000-000000000010': '37283cf9c5afd8bf0a3ed7246aefe60b6268c934590fa7b6dfbe3cc2eaf8538a'}
    ba = {x['artifact_id']: x for x in prov['before_after_content_hashes']}
    if set(ba) != set(exp_v2):
        f.append('accepted v2 repair provenance does not cover exactly the five manifests')
    for aid, want in exp_v2.items():
        payload_false = copy.deepcopy(R2['pm_art'][aid][0])
        payload_false['retention']['request_bytes_available'] = False
        before = DH('prompt-manifest-artifact-v1', payload_false)
        x = ba.get(aid, {})
        if R2['pm_art'][aid][1] != want or x.get('after_content_hash_v2') != want:
            f.append('accepted v2 complete-manifest hash differs from the recomputed v2 chain: ' + aid)
        if x.get('before_content_hash_v1') != before or before == want:
            f.append('recorded v2 before-hash is not the independently recomputed false-availability hash: ' + aid)
        if x.get('changed_path') != '/canonical_payload/retention/request_bytes_available' or x.get('before') is not False or x.get('after') is not True:
            f.append('v2 repair provenance changed-path/transition wrong: ' + aid)
    b = prov['v1_bindings']
    if b['inventory_sha256'] != 'fc7105a5dd5c48c22a87be747da3364c219d27e7fd037b20fb17ec55c4812d7b' or \
            b['checkpoint_sha256'] != '96be0bd976b71a05d30ae1fb261874e29a0cfd8c85ec19670815faddee57af1d' or b['inventoried_members'] != 80:
        f.append('accepted v2 repair provenance v1 bindings wrong')
    if 'not a model run' not in prov['actor'] or prov['authority']['technical_approval_by_mike'] != 'none requested, none claimed' or \
            prov.get('not_a_new_pace_correction') is not True:
        f.append('v2 repair provenance misattributes authorship or presents a new pace correction')
    t = prov['observed_times_utc']
    if not ('2026-09-30T15:48:13Z' <= t['repair_data_regenerated'] <= t['sidecar_written']):
        f.append('v2 repair observed times precede the supervisory review or are out of order')
    # accepted v2 values recorded in history equal the recomputed v2 chain (script, correction fingerprint, corrected direction hash)
    vals = prov['unchanged_dependency_assertions']['values']
    arch = [r for r in B['archive283'] if r['family'] == 'artifacts' and r['v2_row']['artifact_type'] == 'performance_direction']
    if len(arch) != 1:
        f.append('the archived accepted v2 corrected direction artifact is missing')
    else:
        v2dir = arch[0]['v2_row']
        amap2 = script_view(B, 'script_pass2', 'v2')[1]
        hh = DH('performance-direction-v1', _dir_proj(R2['script_pass2'], v2dir['canonical_payload']['direction_spec_version'], v2dir['canonical_payload']['performance_intents'], amap2))
        if hh != vals['corrected_direction_hash'] or v2dir['content_hash'] != hh or vals['corrected_direction_hash'] != '5e30c03a7118b5bab12b84227e55724d6ab47237b3f88eb74e4524dda9272e9d':
            f.append('accepted v2 corrected direction hash differs from its recomputation')
    if H(b'performance-direction-correction-input-v1\n' + B['corr_v1']) != vals['correction_input_fingerprint'] or \
            vals['correction_input_fingerprint'] != 'c773b3352f5d3d1f4bd967e701c93cec193925499705ea5229f509a129e5fd54' or \
            R2['script_pass2'] != vals['final_script_hash'] or vals['final_script_hash'] != '4b6bc58ac065979711c14a681450601e04cb7f2984fa276f0cc7f5b0459671dd':
        f.append('accepted v2 fingerprint/script values differ from the recomputed accepted v2 chain')
    # archived mode evidence for BOTH frozen records (ZIP external attributes, or the inventory's recorded mode for an unpacked copy); never repaired here
    for key in ('record', 'record_v1'):
        am = B['pack'].archived_mode(PATH[key])
        if am is None:
            f.append('no archived mode evidence for the frozen record: ' + key)
        elif am & 0o222:
            f.append('frozen record archived mode is writable: %s %04o' % (key, am))
    # successor transitions: every complete-manifest hash that changed is recorded, recomputed, and request availability stays true
    tr = {x['purpose']: x for x in B['provenance']['manifest_hash_transitions_v2_to_successor']}
    purposes = ['showrunner_planner', 'writer', 'craft_critic', 'writer_revision', 'speech_texture']
    if set(tr) != set(purposes):
        f.append('successor provenance does not cover exactly the five manifests')
    arts = idx(B['load']['artifacts'], 'artifact_id')
    succ_hash = {c['purpose']: (aid, h_) for aid, (c, h_) in R['pm_art'].items()}
    v2_hash = {c['purpose']: h_ for aid, (c, h_) in R2['pm_art'].items()}
    for p_ in purposes:
        x = tr.get(p_, {})
        aid, h_ = succ_hash[p_]
        if x.get('successor_complete_manifest_hash') != h_ or arts[aid]['content_hash'] != h_ or x.get('v2_complete_manifest_hash') != v2_hash[p_] or \
                x.get('request_bytes_available_v2') is not True or x.get('request_bytes_available_successor') is not True:
            f.append('successor manifest hash transition wrong: ' + p_)
        if (p_ == 'showrunner_planner') != (x.get('successor_complete_manifest_hash') == x.get('v2_complete_manifest_hash')):
            f.append('only the planner manifest may be unchanged: ' + p_)
    # stage fingerprints: all six differ from the accepted v2 values recorded in history
    v2st = B['phase3_v2']['stage_fingerprints']
    st_ = stage_projections(B, R)[0]
    now_st = {k: DH(d, p) for k, (d, p) in st_.items()}
    if set(v2st) != set(now_st) or any(v2st[k] == now_st[k] for k in now_st if k != 'semantic_audit' or True):
        f.append('a stage fingerprint did not change although every stage contains a fresh identity or input')
    return f


# (GROUPS, run_checks and main live in the extension section)


# ====================================================================== NEW GROUPS (I2C)
# Each group returns a list of failure strings (empty = pass) and never raises for a corrupt input it can describe.

def _members(B):
    pm = B['pack_members'] or {}
    return {m['path']: m for m in pm.get('members', []) if isinstance(m, dict) and 'path' in m}


def import_scan(name, src_bytes):
    """imports must be standard library only; no absolute-path literals (no reach-back to /home, /workspaces, /tmp...)"""
    out = []
    try:
        tree = ast.parse(src_bytes.decode('utf-8'))
    except Exception as e:
        return ['%s does not parse: %s' % (name, e)]
    banned_prefix = re.compile(r'^(/' + 'home|/' + 'workspaces|/' + 'tmp|/' + 'Users|/' + 'root|[A-Za-z]:\\\\)')
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            for a in n.names:
                if a.name.split('.')[0] not in STDLIB_ALLOWED:
                    out.append('%s imports a non-allowlisted module: %s' % (name, a.name))
        elif isinstance(n, ast.ImportFrom):
            if n.level or (n.module or '').split('.')[0] not in STDLIB_ALLOWED:
                out.append('%s imports from a non-allowlisted/relative module: %s' % (name, n.module))
        elif isinstance(n, ast.Constant) and isinstance(n.value, str) and banned_prefix.match(n.value):
            out.append('%s contains an absolute-path literal: %r' % (name, n.value[:40]))
    return out


def g_pack_integrity(B, f=None):
    f = [] if f is None else f
    pack = B['pack']
    f += ['structure: ' + p for p in pack.problems]
    pm = B['pack_members']
    if not isinstance(pm, dict) or pm.get('pack_format') != 'desk-fixture-pack-members/1' or not isinstance(pm.get('members'), list):
        f.append('PACK_MEMBERS.json is not a desk-fixture-pack-members/1 inventory')
        return f
    listed, seen = {}, set()
    for m in pm['members']:
        p = m.get('path')
        if p in seen:
            f.append('duplicate inventory entry: %s' % p)
        seen.add(p)
        listed[p] = m
        if p == PATH['pack_members']:
            f.append('the inventory lists itself (self-hash exclusion violated)')
    actual = set(pack.data)
    for n in sorted(actual - set(listed) - {PATH['pack_members']}):
        f.append('unlisted member present in the pack: %s' % n)
    for n in sorted(set(listed) - actual):
        f.append('listed member missing from the pack: %s' % n)
    hashes = {}
    for n in sorted(actual & set(listed)):
        m, b = listed[n], pack.data[n]
        hashes[n] = H(b)
        if m.get('bytes') != len(b):
            f.append('wrong byte count for %s: inventory %s, actual %d' % (n, m.get('bytes'), len(b)))
        if m.get('sha256') != hashes[n]:
            f.append('wrong SHA-256 for %s' % n)
        if pack.kind == 'zip':
            try:
                want = int(m['mode'], 8)
            except Exception:
                want = None
            if pack.modes.get(n) != want:
                f.append('archived mode differs from the inventory for %s: zip %s inventory %s' % (n, pack.modes.get(n) and '%04o' % pack.modes.get(n), m.get('mode')))
    # the one active load, and nothing else loadable
    roles = collections.Counter(m.get('role') for m in listed.values())
    if roles.get('active_load') != 1 or listed.get(PATH['load'], {}).get('role') != 'active_load' or pm.get('active_load') != PATH['load']:
        f.append('the pack must declare exactly one active_load: %s' % PATH['load'])
    for n, b in pack.data.items():
        if n.endswith('.json') and n != PATH['load'] and b'"tables"' in b[:4096] and b'"artifacts"' in b:
            if listed.get(n, {}).get('role') not in ARCHIVAL_ROLES:
                f.append('a second row-set member is not declared archival (co-load risk): %s' % n)
    if '123 retained source rows + 275 fresh rows' not in str(B.get('load_profile')) or '398 rows' not in str(B.get('load_profile')):
        f.append('active load profile does not describe the 123 retained + 275 fresh (398-row) corrected standalone successor load')
    # frozen records (version 2 current, version 1 history): archived 0444; everything else 0644
    for n, m in listed.items():
        want = '0444' if m.get('role') == 'frozen_record' else '0644'
        if m.get('mode') != want:
            f.append('inventory mode for %s is %s, expected %s' % (n, m.get('mode'), want))
    # external trust anchors (published outside the pack): enforced when supplied, reported when not
    ex = B['expect']
    pmh = H(pack.data[PATH['pack_members']]) if PATH['pack_members'] in pack.data else None
    anchors = {'zip_sha256_supplied': bool(ex.get('zip_sha256')), 'pack_members_sha256_supplied': bool(ex.get('pack_members_sha256'))}
    if ex.get('zip_sha256'):
        if pack.zip_sha256 is None:
            f.append('a ZIP SHA-256 anchor was supplied but the input is not a ZIP')
        elif pack.zip_sha256 != ex['zip_sha256']:
            f.append('ZIP SHA-256 differs from the externally supplied anchor')
    if ex.get('pack_members_sha256') and pmh != ex['pack_members_sha256']:
        f.append('PACK_MEMBERS.json SHA-256 differs from the externally supplied anchor')
    B['notes']['anchors'] = anchors
    B['notes']['pack_members_sha256'] = pmh
    B['notes']['zip_sha256'] = pack.zip_sha256
    # checksum cycles: neither the inventory hash, nor the ZIP hash, nor a member's own hash may sit inside a member
    banned = {}
    if pmh:
        banned['PACK_MEMBERS.json hash'] = pmh.encode()
    if pack.zip_sha256:
        banned['ZIP hash'] = pack.zip_sha256.encode()
    for n, b in pack.data.items():
        for label, tok in banned.items():
            if tok in b:
                f.append('checksum cycle: %s appears inside member %s' % (label, n))
        own = H(b).encode()
        if own in b:
            f.append('checksum cycle: member %s contains its own SHA-256' % n)
    readme = pack.data.get(PATH['readme'], b'').decode('utf-8', 'replace')
    allh = set(hashes.values())
    for tok in set(re.findall(r'[0-9a-f]{64}', readme)):
        if tok in allh:
            f.append('README lists a member SHA-256 (checksum-cycle rule): %s' % tok[:12])
    # source-to-package accounting
    sp = B['source_provenance']
    if not isinstance(sp, dict) or not isinstance(sp.get('members'), list):
        f.append('SOURCE_PROVENANCE.json is malformed')
    else:
        acc = {m['member']: m for m in sp['members']}
        want = actual - {PATH['pack_members'], PATH['source_provenance']}
        for n in sorted(want - set(acc)):
            f.append('member lacks source accounting: %s' % n)
        for n in sorted(set(acc) - actual):
            f.append('source accounting names a member that is not in the pack: %s' % n)
        for n, m in acc.items():
            if n not in pack.data:
                continue
            if 'source_sha256' in m:
                if m['source_sha256'] != H(pack.data[n]):
                    f.append('copied member differs from its pinned source hash: %s' % n)
            elif m.get('sha256_of_member') != H(pack.data[n]):
                f.append('generated member differs from its recorded hash: %s' % n)
        if sp.get('bookkeeping_changes_to_load') != []:
            f.append('the packaged load declares bookkeeping changes; this candidate declares none')
    # the validator and case module must be stdlib-only and free of absolute-path reach-back
    for key in ('validator_py', 'cases_py'):
        name = PATH[key]
        if name not in pack.data:
            f.append('required member missing: %s' % name)
        else:
            f += import_scan(name, pack.data[name])
    return f


def _arts(B):
    return {a['artifact_id']: a for a in B['load']['artifacts']}


def expected_inventory_rows(B):
    rows = []
    for a in B['load']['artifacts']:
        aud = str(a['artifact_id']).startswith('66666666')
        rows.append({'artifact_id': a['artifact_id'], 'artifact_type': a['artifact_type'], 'content_hash': a['content_hash'],
                     'storage_uri': a['storage_uri'], 'byte_size': a['byte_size'], 'resolves_to_member': a['storage_uri'],
                     'resolution': 'audio_bytes_member' if aud else ('shared_container_by_artifact_id' if a['storage_uri'] in ('prompt_payloads.json', 'support_payloads.json') else 'whole_member_is_canonical_payload'),
                     'path_class': 'historical_direction_retained' if a['artifact_id'] == HIST_DIRECTION_ARTIFACT else 'current_conforming_path'})
    return rows


def g_reference_resolution(B, f=None):
    f = [] if f is None else f
    pack, L = B['pack'], B['load']
    listed = _members(B)
    arts = L['artifacts']
    cnt = collections.Counter(a['artifact_id'] for a in arts)
    for k, c in cnt.items():
        if c > 1:
            f.append('duplicate artifact id in the load: %s' % k)
    shared = collections.defaultdict(list)
    for a in arts:
        uri = a['storage_uri']
        if not isinstance(uri, str) or uri not in pack.data:
            f.append('dangling storage_uri %r on artifact %s' % (uri, a['artifact_id']))
            continue
        role = listed.get(uri, {}).get('role')
        if role in ARCHIVAL_ROLES or uri.startswith(('archive/', 'provenance/', 'authority/')):
            f.append('artifact %s storage_uri names an archival/provenance member: %s' % (a['artifact_id'], uri))
        if str(a['artifact_id']).startswith('66666666'):
            b = pack.data[uri]
            if a['byte_size'] != len(b) or a['content_hash'] != H(b) or a['canonical_payload'].get('sha256') != H(b):
                f.append('audio member bytes disagree with the artifact row: %s' % uri)
            continue
        shared[uri].append(a['artifact_id'])
        try:
            pl = resolve_payload(pack, a)
        except Exception as e:
            f.append('artifact %s does not resolve inside %s: %s' % (a['artifact_id'], uri, e))
            continue
        if pl != a['canonical_payload']:
            f.append('member payload differs from artifact payload copy: %s (%s)' % (a['artifact_id'], uri))
    for uri in ('prompt_payloads.json', 'support_payloads.json'):
        if uri not in pack.data:
            continue
        obj = json.loads(pack.data[uri].decode('utf-8'))
        lst = obj.get('manifests') if 'manifests' in obj else obj.get('artifacts')
        ids = [e.get('artifact_id') for e in lst]
        if len(ids) != len(set(ids)):
            f.append('container %s has a duplicate artifact_id entry' % uri)
        if sorted(ids) != sorted(shared.get(uri, [])):
            f.append('container %s entries differ from the artifact rows naming it' % uri)
    # other single-payload members must not be shared by two artifact rows
    for uri, ids in shared.items():
        if uri not in ('prompt_payloads.json', 'support_payloads.json') and len(ids) != 1:
            f.append('non-container member %s is shared by %d artifacts' % (uri, len(ids)))
    # member/artifact inventory
    inv = B['artifact_inventory']
    if not isinstance(inv, dict) or inv.get('artifacts') != expected_inventory_rows(B):
        f.append('ARTIFACT_INVENTORY.json differs from the rows derived from the load')
    else:
        want = {'artifact_rows': 36, 'current_conforming_path': 35, 'historical_direction_retained': 1, 'audio_artifacts': 12, 'json_artifacts': 24}
        if inv.get('counts') != want:
            f.append('artifact inventory counts are not 36 = 35 current + 1 historical (12 audio + 24 JSON)')
    # rendered_request_ref: literal member + specimen key for every complete manifest
    pm = idx(L['prompt_manifests'], 'prompt_manifest_id')
    owner = {r['artifact_id']: r for r in pm.values()}
    specs = B['requests']
    keys = [r.get('specimen_key') for r in specs.get('requests', [])]
    if len(keys) != len(set(keys)):
        f.append('duplicate specimen_key in the request specimen member')
    for a in arts:
        if not str(a['artifact_type']).startswith('prompt_manifest'):
            continue
        rr = a['canonical_payload'].get('rendered_request_ref')
        if not isinstance(rr, dict) or set(rr) != {'bytes_status', 'member', 'specimen_key'}:
            f.append('rendered_request_ref is not the exact {member, specimen_key, bytes_status} object: %s' % a['artifact_id'])
            continue
        mem = rr['member']
        if mem not in pack.data:
            f.append('rendered_request_ref.member is not a member of the pack: %s (%s)' % (mem, a['artifact_id']))
            continue
        try:
            sobj = json.loads(pack.data[mem].decode('utf-8'))
            hits = [r for r in sobj['requests'] if r.get('specimen_key') == rr['specimen_key']]
        except Exception as e:
            f.append('rendered_request_ref.member is not a request specimen member: %s (%s)' % (mem, e))
            continue
        if len(hits) != 1:
            f.append('rendered_request_ref.specimen_key %r resolves to %d specimens (%s)' % (rr['specimen_key'], len(hits), a['artifact_id']))
            continue
        row = owner.get(a['artifact_id'])
        if row is None or hits[0]['prompt_manifest_id'] != row['prompt_manifest_id']:
            f.append('specimen belongs to a different prompt manifest than the artifact names: %s' % a['artifact_id'])
        elif H(hits[0]['rendered_request'].encode('utf-8')) != row['rendered_request_hash']:
            f.append('specimen raw SHA-256 differs from the typed rendered_request_hash: %s' % a['artifact_id'])
        if rr['bytes_status'] != 'frozen_specimen_i2b':
            f.append('rendered_request_ref.bytes_status is not frozen_specimen_i2b: %s' % a['artifact_id'])
    # referenced_by in the inventory must match the references that actually exist
    want_ref = collections.defaultdict(set)
    for a in arts:
        want_ref[a['storage_uri']].add('artifact %s storage_uri' % a['artifact_id'])
        if str(a['artifact_type']).startswith('prompt_manifest'):
            rr = a['canonical_payload'].get('rendered_request_ref') or {}
            if isinstance(rr, dict) and 'member' in rr:
                want_ref[rr['member']].add('artifact %s rendered_request_ref (specimen_key %s)' % (a['artifact_id'], rr.get('specimen_key')))
    for n, m in listed.items():
        if set(m.get('referenced_by', [])) != want_ref.get(n, set()):
            f.append('inventory referenced_by differs from the real references for %s' % n)
    # other named references inside shipped data must resolve
    for m in (B['proj']['fixture_tts_mapping'] or {}).get('entries', []):
        if m.get('wav_member_path') not in pack.data:
            f.append('mapping wav_member_path is not a member: %s' % m.get('wav_member_path'))
    pol = B['policy'] or {}
    for k, p in (pol.get('policies') or {}).items():
        if p.get('shipped_at') not in pack.data:
            f.append('policy %s shipped_at is not a member: %s' % (k, p.get('shipped_at')))
    idxm = B['index'] or {}
    for o in idxm.get('obligations', []):
        for mem in o.get('members', []):
            if mem not in pack.data:
                f.append('conformance_index names a member that is not in the pack: %s' % mem)
    return f


OBSOLETE_ACTIVE_POLICY = {  # the active v1.2.4 / Fixture v0.4.4 launch-policy-set-v3 bindings this candidate must NOT silently retain
    'version_ids': {'claims-0.1.1', 'evidence-package-0.2.1', 'writing-0.2.2', 'performance-render-0.1.3', 'hash-fingerprint-span-0.1.3'},
    'source_sha256': {'1bc90f51321c8c6b0bfc663abfafb6142fca31118154d2b2d64ed955fde2532f', '4b28a95fd0f8a2a77993641c2271b7a34bdc8bf8faa7d3e01aaf8525b831356b',
                      'c9f16b84e7e4789c5709c815c477508182a4898cf935b044ca8deb812da0061e', 'd5c3f694512b57325d26eb4ba0d76fffbf1b78609dc2aed1db6bf2965ccd104a',
                      '0f7541d2b58bdc5cb29c90db4155cd462f9b405539af9f2d2cb976d219041a36'}}
POLICY_COMPONENT_KEYS = {'planning_policy', 'writing_policy', 'direction_spec', 'claims_policy', 'evidence_package_spec',
                         'operator_repair_policy', 'autonomous_operation_policy', 'writing_craft_policy', 'hashing_contract'}


def g_policy_authority(B, f=None):
    f = [] if f is None else f
    pack = B['pack']
    pol = B['policy']
    if not isinstance(pol, dict) or not isinstance(pol.get('policies'), dict):
        return ['config/policy_versions.json is malformed']
    if 'PROSPECTIVE' not in str(pol.get('status')) or 'active' not in str(pol.get('status')).lower():
        f.append('policy map does not declare itself prospective / not the active map')
    policies = pol['policies']
    if set(policies) != POLICY_COMPONENT_KEYS:
        f.append('policy map keys are not the nine expected policies: %s' % sorted(set(policies) ^ POLICY_COMPONENT_KEYS))
    for k, p in policies.items():
        if p.get('version_id') in OBSOLETE_ACTIVE_POLICY['version_ids'] or p.get('source_sha256') in OBSOLETE_ACTIVE_POLICY['source_sha256']:
            f.append('policy %s silently retains an obsolete active-profile binding' % k)
        if p.get('shipped_at') != 'authority/' + str(p.get('source_path')):
            f.append('policy %s shipped_at is not authority/<source_path>' % k)
        b = pack.data.get(p.get('shipped_at'))
        if b is None:
            f.append('policy %s authority source is not shipped' % k)
        elif H(b) != p.get('source_sha256'):
            f.append('policy %s source_sha256 does not match the shipped authority bytes' % k)
    # the owning-spec versions quoted by each spec file must equal the map's version ids (cheap title/version sanity on real bytes)
    for k, p in policies.items():
        b = pack.data.get(p.get('shipped_at'), b'')
        head = b[:600].decode('utf-8', 'replace')
        ver = re.search(r'v(\d+\.\d+(?:\.\d+)?)', head)
        if b and not ver:
            f.append('authority source %s carries no version in its title' % p.get('source_path'))
    # supporting authority (Character Bible): shipped exactly, named by the participant configuration, bound by NO prompt manifest
    sup = pol.get('supporting_authority') or {}
    if set(sup) != {'character_bible'}:
        f.append('supporting_authority must declare exactly the character_bible source')
    for k, p in sup.items():
        b = pack.data.get(p.get('shipped_at'))
        if b is None or H(b) != p.get('source_sha256') or p.get('shipped_at') != 'authority/' + str(p.get('source_path')):
            f.append('supporting authority %s is not shipped with its exact source bytes' % k)
    allpol = {p['source_sha256'] for p in policies.values()}
    if any(p.get('source_sha256') in allpol for p in sup.values()):
        f.append('a supporting authority hash appears among the prompt policy sources')
    # prompt manifests bind exactly these policies
    L = B['load']
    for r in L['prompt_manifests']:
        cv, ph = r['component_versions'], r['policy_source_hashes']
        pol_keys = {k for k in cv if k in POLICY_COMPONENT_KEYS}
        if set(ph) != pol_keys:
            f.append('prompt manifest %s policy_source_hashes keys differ from its policy components' % r['prompt_manifest_id'])
        for k in pol_keys:
            p = policies.get(k)
            if not p or cv[k] != p['version_id']:
                f.append('prompt manifest %s component %s=%r is not the policy map version' % (r['prompt_manifest_id'], k, cv[k]))
            elif ph.get(k) != p['source_sha256']:
                f.append('prompt manifest %s policy_source_hashes[%s] does not bind the exact source bytes' % (r['prompt_manifest_id'], k))
        for k in set(cv) - pol_keys:
            if k != 'fixture_prompt':
                f.append('prompt manifest %s carries an unknown component %s' % (r['prompt_manifest_id'], k))
    # other version ids used by fixture projections must be the prospective versions
    aud = B['members']['semantic_audit_result__successor']['input_projection']
    for field, key in (('claims_policy_version', 'claims_policy'), ('writing_policy_version', 'writing_policy'), ('performance_policy_version', 'direction_spec')):
        if aud.get(field) != policies.get(key, {}).get('version_id'):
            f.append('audit input %s is not the prospective policy version' % field)
    sc = current_config(B)['canonical_payload']
    for field, key in (('operator_repair_policy_version', 'operator_repair_policy'), ('autonomous_operation_policy_version', 'autonomous_operation_policy'),
                       ('writing_craft_policy_version', 'writing_craft_policy')):
        if sc.get(field) != policies.get(key, {}).get('version_id'):
            f.append('show config %s is not the prospective policy version' % field)
    stg = B['proj']['stage_fingerprints']
    for st, key in (('claims_writing', 'claims_policy'), ('claims_writing', 'writing_policy'), ('performance', 'direction_spec')):
        ip = stg[st]['input_projection']
        fld = {'claims_policy': 'claims_policy_version', 'writing_policy': 'writing_policy_version', 'direction_spec': 'performance_policy_version'}[key]
        if ip.get(fld) != policies[key]['version_id']:
            f.append('stage %s projection %s is not the prospective policy version' % (st, fld))
    rm = B['members']['render_manifest__successor']
    if rm.get('performance_policy_version', policies['direction_spec']['version_id']) != policies['direction_spec']['version_id']:
        f.append('render manifest performance policy version differs')
    return f


# ---------------------------------------------------------------- complete-manifest acceptance (valid-fixture acceptance tests)
MANIFEST_FIELDS = ['schema_version', 'purpose', 'component_versions', 'template_version', 'policy_source_hashes', 'ordered_input_artifacts',
                   'ordered_input_evidence', 'ordered_input_claims', 'exposure_instructions', 'non_source_text', 'provider', 'model_identifier',
                   'settings', 'rendered_request_hash', 'rendered_request_ref', 'retention']
THREE_FIELDS = ('component_versions', 'policy_source_hashes', 'rendered_request_hash')
RETENTION_KEYS = {'manifest_policy_version', 'raw_output_retention_policy', 'request_byte_retention', 'request_bytes_available', 'source_byte_retention_provenance'}
EXPOSURE_KEYS = {'consumer', 'input_representation', 'instructions', 'profile_version'}
FORBIDDEN_KEYS = {'output_artifact_id', 'model_run_id', 'provider_call_id', 'program_run_id', 'attempt_id', 'fixture_model_provenance',
                  'response_artifact_id', 'actual_cost', 'estimated_cost', 'cost', 'currency', 'usage', 'operational_try_number',
                  'retry_of_provider_call_id', 'prompt_manifest_id', 'storage_uri', 'byte_size', 'created_at', 'content_hash_of_manifest',
                  'envelope', 'canonical_payload', 'semantic_input_hash', 'model_semantic_input_hash'}
OUTPUT_FOR_PURPOSE = {'showrunner_planner': 'showrunner_brief', 'writer': 'script_pass1', 'craft_critic': 'writing_craft_review',
                      'writer_revision': 'script_craft_revision', 'speech_texture': 'script_pass2'}
PURPOSE_ORDER = ['showrunner_planner', 'writer', 'craft_critic', 'writer_revision', 'speech_texture']
OUTPUT_HIDDEN_KEYS = {'fixture_model_provenance', 'rendered_request', 'rendered_request_ref', 'rendered_request_hash', 'retention', 'prompt_manifest',
                      'prompt_manifest_id', 'policy_source_hashes', 'request_bytes_available'}


def _walk_keys(v):
    if isinstance(v, dict):
        for k, x in v.items():
            yield k
            yield from _walk_keys(x)
    elif isinstance(v, list):
        for x in v:
            yield from _walk_keys(x)


def _strings(v):
    if isinstance(v, str):
        yield v
    elif isinstance(v, dict):
        for x in v.values():
            yield from _strings(x)
    elif isinstance(v, list):
        for x in v:
            yield from _strings(x)


def _norm_words(s):
    return re.sub(r'\s+', ' ', unicodedata.normalize('NFC', s).lower()).strip()


def excerpt_hits(text, bodies, run=8):
    """rights-bearing source excerpt detector over structured evidence: any run of `run` consecutive words of a body
    (or a short body wholly) appearing in the text. Deterministic string containment, not a semantic judgment."""
    t = ' ' + _norm_words(text) + ' '
    hits = []
    for eid, body in bodies.items():
        w = _norm_words(body).split(' ')
        if len(w) <= run:
            if len(' '.join(w)) >= 24 and (' ' + ' '.join(w) + ' ') in t:
                hits.append(eid)
            continue
        for i in range(len(w) - run + 1):
            if (' ' + ' '.join(w[i:i + run]) + ' ') in t:
                hits.append(eid)
                break
    return hits


def manifest_acceptance(B, aid, payload, content_hash, row, run_row=None):
    """valid-fixture acceptance of ONE complete prompt-manifest artifact against the load; returns failure strings"""
    f = []
    L = B['load']
    arts = _arts(B)
    if not isinstance(payload, dict) or set(payload) != set(MANIFEST_FIELDS):
        f.append('complete manifest is not exactly the 16-field object (%s)' % (sorted(set(payload) ^ set(MANIFEST_FIELDS)) if isinstance(payload, dict) else 'not an object'))
        return f
    if payload['schema_version'] != 'prompt-manifest/1':
        f.append('manifest schema_version is not prompt-manifest/1')
    if DH('prompt-manifest-artifact-v1', payload) != content_hash:
        f.append('complete-manifest artifact hash does not recompute from the complete payload')
    for k in THREE_FIELDS:
        if row[k] != payload[k]:
            f.append('typed three-field reconciliation failed on %s' % k)
    purpose = payload['purpose']
    if purpose not in OUTPUT_FOR_PURPOSE:
        f.append('unknown manifest purpose %r' % purpose)
        return f
    mr = [m for m in L['model_runs'] if m['prompt_manifest_id'] == row['prompt_manifest_id']]
    if len(mr) != 1:
        f.append('prompt manifest is not bound by exactly one model run')
        return f
    out = arts.get(mr[0]['output_artifact_id'])
    if out is None or out['artifact_type'] != OUTPUT_FOR_PURPOSE[purpose]:
        f.append('model output artifact type does not match the manifest purpose')
    if payload['provider'] != 'fixture_stub' or payload['model_identifier'] != mr[0]['model_identifier']:
        f.append('manifest provider/model_identifier disagree with the model run')
    # artifact binding: a dedicated artifact, distinct from every model output and from every other manifest
    if aid == (out or {}).get('artifact_id'):
        f.append('prompt manifest artifact is its own model output')
    outputs = {m['output_artifact_id'] for m in L['model_runs']}
    if aid in outputs:
        f.append('prompt manifest artifact is also a model output artifact')
    # ordered inputs: resolve, match type/hash, never include own output / itself / later outputs
    pm_purpose = {p['prompt_manifest_id']: arts[p['artifact_id']]['canonical_payload'].get('purpose') for p in L['prompt_manifests'] if p['artifact_id'] in arts}
    later = set()
    for m_ in L['model_runs']:
        pp = pm_purpose.get(m_['prompt_manifest_id'])
        if pp in PURPOSE_ORDER and PURPOSE_ORDER.index(pp) >= PURPOSE_ORDER.index(purpose):
            later.add(m_['output_artifact_id'])
    if not isinstance(payload['ordered_input_artifacts'], list) or not payload['ordered_input_artifacts']:
        f.append('ordered_input_artifacts must be a non-empty ordered list')
    for ia in payload['ordered_input_artifacts'] if isinstance(payload['ordered_input_artifacts'], list) else []:
        if not isinstance(ia, dict) or set(ia) != {'artifact_id', 'artifact_type', 'content_hash'}:
            f.append('ordered input artifact is not {artifact_id, artifact_type, content_hash}')
            continue
        tgt = arts.get(ia['artifact_id'])
        if tgt is None:
            f.append('ordered input artifact does not resolve: %s' % ia['artifact_id'])
        elif tgt['artifact_type'] != ia['artifact_type'] or tgt['content_hash'] != ia['content_hash']:
            f.append('ordered input artifact type/content_hash differ from the durable artifact: %s' % ia['artifact_id'])
        if ia['artifact_id'] == aid or ia['artifact_id'] == (out or {}).get('artifact_id') or ia['artifact_id'] in later:
            f.append('manifest references its own artifact, its own output or a later output: %s' % ia['artifact_id'])
    evs = {e['evidence_unit_id']: e for e in L['evidence_units']}
    clm = {c['claim_id']: c for c in L['claims']}
    for e in payload['ordered_input_evidence'] if isinstance(payload['ordered_input_evidence'], list) else ['<not a list>']:
        if not isinstance(e, dict) or set(e) != {'evidence_unit_id', 'content_hash', 'rights_version_id', 'exposure'}:
            f.append('ordered input evidence entry has the wrong shape')
        elif e['evidence_unit_id'] not in evs or evs[e['evidence_unit_id']]['content_hash'] != e['content_hash'] or \
                evs[e['evidence_unit_id']]['rights_version_id'] != e['rights_version_id']:
            f.append('ordered input evidence entry does not resolve to its durable row')
    for c in payload['ordered_input_claims'] if isinstance(payload['ordered_input_claims'], list) else ['<not a list>']:
        if not isinstance(c, dict) or set(c) != {'claim_id', 'claim_content_hash', 'frozen_state_hash', 'package_hash'}:
            f.append('ordered input claim entry has the wrong shape')
        elif c['claim_id'] not in clm or clm[c['claim_id']]['content_hash'] != c['claim_content_hash']:
            f.append('ordered input claim entry does not resolve to its durable claim')
    # ordered inputs/exposure against the exact request specimen
    sp = [r for r in B['requests']['requests'] if r.get('specimen_key') == (payload['rendered_request_ref'] or {}).get('specimen_key')]
    if len(sp) == 1:
        try:
            rq = json.loads(sp[0]['rendered_request'])
            if rq.get('input_artifacts') != payload['ordered_input_artifacts'] or rq.get('purpose') != purpose or \
                    rq.get('instruction') != (payload['non_source_text'][0]['text'] if payload['non_source_text'] else None) or \
                    rq.get('execution_mode') != payload['provider']:
                f.append('manifest ordered inputs/instruction/purpose differ from the exact request specimen')
        except Exception as e:
            f.append('request specimen is not parseable canonical JSON: %s' % e)
    ex = payload['exposure_instructions']
    if not isinstance(ex, dict) or set(ex) != EXPOSURE_KEYS or ex.get('consumer') != purpose or ex.get('profile_version') != 'consumer-exposure-v1':
        f.append('exposure_instructions are incomplete or belong to another consumer')
    nst = payload['non_source_text']
    if not isinstance(nst, list) or not nst or any((not isinstance(x, dict)) or set(x) != {'role', 'text'} for x in nst):
        f.append('non_source_text is not an ordered list of {role, text}')
    if not isinstance(payload['settings'], dict):
        f.append('settings is not an object')
    # retention: explicit, complete, and truthful about the actual specimen
    ret = payload['retention']
    if not isinstance(ret, dict) or set(ret) != RETENTION_KEYS:
        f.append('retention declaration is missing or incomplete')
    else:
        if not isinstance(ret['request_bytes_available'], bool):
            f.append('retention.request_bytes_available is not a JSON boolean')
        for k in RETENTION_KEYS - {'request_bytes_available'}:
            if not isinstance(ret[k], str) or not ret[k].strip():
                f.append('retention.%s is empty' % k)
        actual = len(sp) == 1 and H(sp[0]['rendered_request'].encode('utf-8')) == payload['rendered_request_hash']
        if ret['request_bytes_available'] is not actual:
            f.append('retention.request_bytes_available disagrees with the actual captured specimen (declared %s, actual %s)' % (ret['request_bytes_available'], actual))
    rr = payload['rendered_request_ref']
    if not isinstance(rr, dict) or set(rr) != {'bytes_status', 'member', 'specimen_key'}:
        f.append('rendered_request_ref is not the exact three-field reference')
    # no hidden output/execution provenance anywhere in the complete payload
    scan = {k: v for k, v in payload.items() if k not in ('ordered_input_artifacts', 'ordered_input_evidence', 'ordered_input_claims')}
    bad = sorted(set(_walk_keys(scan)) & FORBIDDEN_KEYS)
    if bad:
        f.append('complete manifest carries envelope/execution/output provenance keys: %s' % bad)
    text = cj(payload)
    for label, tok in (('own artifact id', aid), ('own content hash', content_hash), ('model run id', mr[0]['model_run_id']),
                       ('provider call id', mr[0]['provider_call_id']), ('output artifact id', mr[0]['output_artifact_id']),
                       ('output content hash', (out or {}).get('content_hash')), ('semantic input hash', mr[0]['semantic_input_hash'])):
        if tok and tok in text:
            f.append('complete manifest leaks %s (hidden output provenance)' % label)
    # no rights-bearing source excerpt in the payload or its retained request specimen
    bodies = {e['evidence_unit_id']: e.get('canonical_content') or '' for e in L['evidence_units']}
    hay = ' '.join(_strings(payload)) + ' ' + (sp[0]['rendered_request'] if len(sp) == 1 else '')
    hit = excerpt_hits(hay, bodies)
    if hit:
        f.append('rights-bearing source excerpt present in the manifest/specimen: %s' % sorted(set(hit))[:3])
    return f


def g_manifest_acceptance(B, f=None):
    f = [] if f is None else f
    L = B['load']
    arts = _arts(B)
    pm = L['prompt_manifests']
    if len(pm) != 5:
        f.append('prompt rows are not exactly five')
    aids = [r['artifact_id'] for r in pm]
    if len(set(aids)) != 5:
        f.append('prompt_manifests.artifact_id values are not five distinct (unique FK) artifacts')
    if not all(a in arts for a in aids):
        f.append('a prompt manifest artifact is missing')
    if {arts[a]['artifact_type'] for a in aids if a in arts} != {'prompt_manifest_%d' % i for i in range(1, 6)}:
        f.append('prompt manifest artifact types are not prompt_manifest_1..5')
    purposes = sorted(arts[a]['canonical_payload'].get('purpose') for a in aids if a in arts)
    if purposes != sorted(PURPOSE_ORDER):
        f.append('manifest purposes are not the five model roles')
    for r in pm:
        a = arts.get(r['artifact_id'])
        if a is None:
            continue
        f += ['%s: %s' % (r['artifact_id'][-4:], m) for m in manifest_acceptance(B, a['artifact_id'], a['canonical_payload'], a['content_hash'], r)]
    # the five model output artifacts carry no request provenance of their own
    for m in L['model_runs']:
        out = arts.get(m['output_artifact_id'])
        if out is None:
            continue
        bad = sorted(set(_walk_keys(out['canonical_payload'])) & OUTPUT_HIDDEN_KEYS)
        if bad:
            f.append('model output %s carries hidden request provenance keys: %s' % (out['artifact_id'][-4:], bad))
    # all five manifests differ from each other in purpose-specific provenance
    if len({a['canonical_payload']['template_version'] for a in arts.values() if str(a['artifact_type']).startswith('prompt_manifest')}) != 5:
        f.append('template_version is not purpose-specific')
    return f


# ====================================================================== EXECUTABLE VECTOR GROUPS (I2C)
class SelectorError(Exception):
    """a declared subject/path does not resolve uniquely: a HARNESS failure, never evidence of domain rejection"""


def _unesc(tok):
    return tok.replace('~1', '/').replace('~0', '~')


def ptr_resolve(obj, pointer):
    """resolve a JSON pointer strictly: every step must exist. returns (parent, key, value)"""
    if not isinstance(pointer, str) or not pointer.startswith('/'):
        raise SelectorError('selector is not an absolute JSON pointer: %r' % (pointer,))
    toks = [_unesc(t) for t in pointer[1:].split('/')]
    parent, key, cur = None, None, obj
    for t in toks:
        if isinstance(cur, dict):
            if t not in cur:
                raise SelectorError('selector %s: key %r does not exist' % (pointer, t))
            parent, key, cur = cur, t, cur[t]
        elif isinstance(cur, list):
            if not re.fullmatch(r'0|[1-9][0-9]*', t) or int(t) >= len(cur):
                raise SelectorError('selector %s: index %r is out of range / not an index' % (pointer, t))
            parent, key, cur = cur, int(t), cur[int(t)]
        else:
            raise SelectorError('selector %s: cannot descend into a scalar at %r' % (pointer, t))
    return parent, key, cur


def ptr_parent(obj, pointer):
    """resolve the PARENT container of a pointer whose last step must be absent (for add) or a valid insert position"""
    if not isinstance(pointer, str) or not pointer.startswith('/') or pointer == '/':
        raise SelectorError('selector is not an absolute JSON pointer with a parent: %r' % (pointer,))
    head, _, last = pointer.rpartition('/')
    parent = obj if head == '' else ptr_resolve(obj, head)[2]
    return parent, _unesc(last)


def apply_mutation(obj, m):
    """apply one declared mutation to `obj` IN PLACE. Selectors resolve strictly BEFORE anything is changed; no-op mutations fail."""
    op = m['op']
    if op == 'set':
        parent, key, old = ptr_resolve(obj, m['path'])
        if parent is None:
            raise SelectorError('cannot set the document root')
        if old == m['value'] and type(old) == type(m['value']):
            raise SelectorError('mutation at %s is a no-op' % m['path'])
        parent[key] = copy.deepcopy(m['value'])
    elif op == 'delete':
        parent, key, _ = ptr_resolve(obj, m['path'])
        if parent is None:
            raise SelectorError('cannot delete the document root')
        if isinstance(parent, dict):
            del parent[key]
        else:
            parent.pop(key)
    elif op == 'add':
        parent, key = ptr_parent(obj, m['path'])
        if not isinstance(parent, dict) or key in parent:
            raise SelectorError('add target %s is not an absent key of an object' % m['path'])
        parent[key] = copy.deepcopy(m['value'])
    elif op == 'append':
        _, _, lst = ptr_resolve(obj, m['path'])
        if not isinstance(lst, list):
            raise SelectorError('append target %s is not a list' % m['path'])
        lst.append(copy.deepcopy(m['value']))
    elif op == 'insert':
        parent, key = ptr_parent(obj, m['path'])
        if not isinstance(parent, list) or not re.fullmatch(r'0|[1-9][0-9]*', key) or int(key) > len(parent):
            raise SelectorError('insert position %s is not valid for a list' % m['path'])
        parent.insert(int(key), copy.deepcopy(m['value']))
    elif op == 'swap':
        pa, ka, va = ptr_resolve(obj, m['path'])
        pb, kb, vb = ptr_resolve(obj, m['with'])
        if pa is None or pb is None or pa is not pb or va == vb:
            raise SelectorError('swap targets %s and %s must be distinct, unequal entries of one container' % (m['path'], m['with']))
        pa[ka], pa[kb] = vb, va
    elif op == 'reorder_keys':
        parent, key, d = ptr_resolve(obj, m['path']) if m['path'] != '/' else (None, None, obj)
        if not isinstance(d, dict) or len(d) < 2:
            raise SelectorError('reorder_keys target %s is not an object with two or more keys' % m['path'])
        items = list(d.items())[::-1]
        d.clear()
        d.update(items)
    else:
        raise SelectorError('unknown mutation op %r' % op)
    return obj


def apply_mutations(obj, muts):
    o = copy.deepcopy(obj)
    for m in muts:
        apply_mutation(o, m)
    return o


def leaf_pointers(v, p=''):
    if isinstance(v, dict):
        for k, x in v.items():
            yield from leaf_pointers(x, p + '/' + k.replace('~', '~0').replace('/', '~1'))
    elif isinstance(v, list):
        for i, x in enumerate(v):
            yield from leaf_pointers(x, p + '/' + str(i))
    else:
        yield p


def _log(B, group, rec):
    B.setdefault('_log', {}).setdefault(group, []).append(rec)


# ---------------------------------------------------------------- G26: complete-manifest HASH-FUNCTION sensitivity vectors
def complete_manifest_hash(payload):
    """prompt-manifest-artifact-v1 over the complete canonical payload"""
    return DH('prompt-manifest-artifact-v1', payload)


def artifact_row_complete_hash(row):
    """the artifact's content hash selects canonical_payload ONLY; the outer storage/typed-row envelope is excluded"""
    return complete_manifest_hash(row['canonical_payload'])


def semantic_three_field_hash(payload):
    return DH('model-semantic-input-v1', {k: payload[k] for k in THREE_FIELDS})


def g_manifest_hash_vectors(B, f=None):
    f = [] if f is None else f
    V = B['v_manifest']
    arts = _arts(B)
    base = V['baseline']
    if V['domains'] != {'complete_manifest': 'prompt-manifest-artifact-v1', 'model_semantic_input': 'model-semantic-input-v1'}:
        f.append('manifest vector domains are not the governed pair')
    actual = [a for a in arts.values() if str(a['artifact_type']).startswith('prompt_manifest') and a['canonical_payload']['purpose'] == base['purpose']]
    if len(actual) != 1 or actual[0]['canonical_payload'] != base['payload'] or actual[0]['content_hash'] != base['complete_hash']:
        f.append('vector baseline is not the actual shipped %s manifest' % base['purpose'])
    if complete_manifest_hash(base['payload']) != base['complete_hash'] or semantic_three_field_hash(base['payload']) != base['semantic_hash']:
        f.append('vector baseline hashes do not recompute')
    if base['payload'] is not None and set(base['payload']) != set(MANIFEST_FIELDS):
        f.append('vector baseline is not the 16-field object')
    ctr = collections.Counter()
    for v in V['vectors']:
        try:
            m = apply_mutations(base['payload'], v['mutations'])
        except SelectorError as e:
            f.append('SELECTOR FAILURE in manifest vector %s: %s' % (v['id'], e))
            _log(B, 'G26', {'id': v['id'], 'class': v['class'], 'outcome': 'SELECTOR_FAILURE'})
            continue
        ch = complete_manifest_hash(m)
        ex = v['expect']
        ok = True
        rel = 'same' if ch == base['complete_hash'] else 'different'
        if rel != ex['complete'] or ch != ex['complete_hash']:
            ok = False
            f.append('manifest vector %s complete hash: expected %s %s, got %s %s' % (v['id'], ex['complete'], ex['complete_hash'][:12], rel, ch[:12]))
        try:
            sh = semantic_three_field_hash(m)
            srel = 'same' if sh == base['semantic_hash'] else 'different'
        except KeyError:
            sh, srel = None, 'not_computable'
        if srel != ex['semantic'] or sh != ex['semantic_hash']:
            ok = False
            f.append('manifest vector %s three-field semantic identity: expected %s, got %s' % (v['id'], ex['semantic'], srel))
        if 'mutations_b' in v:
            try:
                mb = apply_mutations(base['payload'], v['mutations_b'])
            except SelectorError as e:
                f.append('SELECTOR FAILURE in manifest vector %s (b side): %s' % (v['id'], e))
                continue
            if (complete_manifest_hash(mb) == ch) is not bool(ex.get('equal_to_b')):
                ok = False
                f.append('manifest vector %s pair equality is not %s' % (v['id'], ex.get('equal_to_b')))
        ctr[v['class']] += 1
        _log(B, 'G26', {'id': v['id'], 'class': v['class'], 'outcome': 'as_expected' if ok else 'UNEXPECTED'})
    # envelope exclusion: the complete hash selects canonical_payload only
    row = copy.deepcopy(actual[0]) if len(actual) == 1 else None
    for ev in V.get('envelope_vectors', []):
        if row is None:
            break
        r2 = copy.deepcopy(row)
        try:
            for k, val in ev['change'].items():
                if k not in r2:
                    raise SelectorError('envelope field %s does not exist on the artifact row' % k)
                r2[k] = val
        except SelectorError as e:
            f.append('SELECTOR FAILURE in envelope vector %s: %s' % (ev['id'], e))
            continue
        ok = artifact_row_complete_hash(r2) == base['complete_hash']
        if not ok:
            f.append('envelope vector %s: an excluded storage/envelope field changed the complete-manifest hash' % ev['id'])
        ctr['envelope_exclusion'] += 1
        _log(B, 'G26', {'id': ev['id'], 'class': 'envelope_exclusion', 'outcome': 'as_expected' if ok else 'UNEXPECTED'})
    # sweep over the five ACTUAL manifests: every top-level field and every leaf changes the complete hash; the three-field
    # relation follows the field; metadata-only changes leave model-semantic-input-v1 unchanged
    sweep_fail = 0
    n_sweep = 0
    for a in arts.values():
        if not str(a['artifact_type']).startswith('prompt_manifest'):
            continue
        pl = a['canonical_payload']
        h0, s0 = complete_manifest_hash(pl), semantic_three_field_hash(pl)
        for ptr in leaf_pointers(pl):
            _, _, cur = ptr_resolve(pl, ptr)
            newv = (not cur) if isinstance(cur, bool) else (cur + 1 if isinstance(cur, int) else ('x' + cur if isinstance(cur, str) else 'x'))
            m = copy.deepcopy(pl)
            ptr_resolve(m, ptr)[0][ptr_resolve(m, ptr)[1]] = newv
            under3 = ptr.split('/')[1] in THREE_FIELDS
            n_sweep += 1
            if complete_manifest_hash(m) == h0 or ((semantic_three_field_hash(m) != s0) != under3):
                sweep_fail += 1
                f.append('actual-manifest sweep: leaf %s of %s misbehaves' % (ptr, a['artifact_id'][-4:]))
        for fld in MANIFEST_FIELDS:
            m = copy.deepcopy(pl)
            del m[fld]
            n_sweep += 1
            if complete_manifest_hash(m) == h0:
                f.append('actual-manifest sweep: deleting field %s of %s does not change the complete hash' % (fld, a['artifact_id'][-4:]))
    ctr['actual_manifest_sweep'] = n_sweep
    _log(B, 'G26', {'id': 'SWEEP', 'class': 'actual_manifest_sweep', 'outcome': 'as_expected' if not sweep_fail else 'UNEXPECTED', 'n': n_sweep})
    B['notes']['G26_counts'] = dict(ctr)
    return f


# ---------------------------------------------------------------- G27: TTS base-request projection, ownership, closed mapping
VOICE_FIELDS = ('version', 'provider', 'provider_voice_id', 'provider_model_compatibility', 'render_facing_design', 'request_side_voice_controls')
INTENT_FIELDS = ('scope_type', 'scope_ref', 'intent_type', 'value', 'strength', 'timing_anchor')
GEN_KEYS = ('temperature', 'format', 'sample_rate_hz', 'channels')


def _nfc(s):
    return unicodedata.normalize('NFC', s)


def _voice_identity(v):
    return {'version': v['version'], 'provider': v['provider'], 'provider_voice_id': v['provider_voice_id'],
            'provider_model_compatibility': sorted(set(v['provider_model_compatibility'])), 'render_facing_design': v['render_facing_design'],
            'request_side_voice_controls': v['request_side_voice_controls']}


def select_projection(rec):
    """Hashing v0.1.4 s7.1 / P&R s23.1: select EXACTLY the eleven render-affecting fields from a resolved request record.
    Storage PKs, status flags, QA/admin labels, measurements, timestamps, redundant hashes, output/cost/reservation identities and
    take_index are never read."""
    turns = rec['turns']
    voices = {}
    for t in turns:
        voices.setdefault(t['participant_id'], _voice_identity(rec['voice_versions'][t['participant_id']]))
    if 'resolved_generation_settings' in rec:
        gs = {k: rec['resolved_generation_settings'][k] for k in GEN_KEYS}
    else:  # defaults resolved before hashing: a caller that omits a default and one that supplies it hash identically
        merged = dict(rec['generation_defaults'])
        merged.update(rec.get('generation_overrides', {}))
        gs = {k: merged[k] for k in GEN_KEYS}
    order = {t['semantic_turn_id']: i for i, t in enumerate(turns)}
    apps = sorted(rec.get('pronunciation_applications', []), key=lambda a: (order.get(a['semantic_turn_id'], 10 ** 6), a['start_offset']))
    entries, seq = {}, []
    for a in apps:
        k = a['pronunciation_rendering_id']
        if k not in entries:
            speaker = [t for t in turns if t['semantic_turn_id'] == a['semantic_turn_id']]
            pid = speaker[0]['participant_id'] if speaker else a.get('participant_id')
            entries[k] = {'entity_identity': a['entity_identity'], 'canonical_text': a['canonical_text'], 'canonical_version': a['canonical_version'],
                          'language': a['language'], 'ipa': a['ipa'], 'provider': a['provider'], 'participant_id': pid,
                          'voice_render_identity': _voice_identity(rec['voice_versions'][pid]) if pid in rec['voice_versions'] else None,
                          'rendering_version': a['rendering_version'], 'render_text': a['render_text'], 'applications': []}
            seq.append(k)
        entries[k]['applications'].append({'semantic_turn_id': a['semantic_turn_id'], 'start_offset': a['start_offset'], 'end_offset': a['end_offset']})
    return {'concrete_model_identity': rec['concrete_model_identity'], 'adapter_render_contract_version': rec['adapter_render_contract_version'],
            'immutable_voice_profile_version_render_fields': voices,
            'speaker_map': [{'semantic_turn_id': t['semantic_turn_id'], 'participant_id': t['participant_id'],
                             'voice_version': rec['voice_versions'][t['participant_id']]['version']} for t in turns],
            'resolved_generation_settings': gs,
            'canonical_spoken_text': [{'semantic_turn_id': t['semantic_turn_id'], 'participant_id': t['participant_id'], 'spoken_text': _nfc(t['spoken_text'])} for t in turns],
            'approved_performance_intents': [{k: i[k] for k in INTENT_FIELDS} for i in rec['intents']],
            'bounded_render_context': {'recipe_version': rec['context']['recipe_version'],
                                       'turns': [{'semantic_turn_id': c['semantic_turn_id'], 'participant_id': c['participant_id'],
                                                  'spoken_text': _nfc(c['spoken_text'])} for c in rec['context']['turns']]},
            'render_facing_persona_or_scene_config': {'scene_version': rec['scene_config']['scene_version'], 'description': rec['scene_config']['description']},
            'applied_pronunciation_rendering_versions': [entries[k] for k in seq],
            'named_text_transform_versions': list(rec['named_text_transform_versions'])}


def request_hash(rec):
    return 'v1:' + H(cb(select_projection(rec)))


class RequestRejected(Exception):
    def __init__(self, code, detail=''):
        super().__init__('%s %s' % (code, detail))
        self.code = code


def check_ownership(rec, ctx):
    """structural/ownership validation of a resolved request record against the bound script. Raises RequestRejected(code)."""
    turns = {t['semantic_turn_id']: t for t in ctx['turns']}
    order = ctx['program_block_order']
    gen = rec['turns']
    if not gen:
        raise RequestRejected('empty_block')
    for t in gen:
        s = turns.get(t['semantic_turn_id'])
        if s is None:
            raise RequestRejected('anchor_not_in_bound_script', t['semantic_turn_id'])
        if s['participant_id'] != t['participant_id']:
            raise RequestRejected('participant_not_from_bound_script', t['semantic_turn_id'])
        if _nfc(s['spoken_text']) != _nfc(t['spoken_text']):
            raise RequestRejected('text_not_from_bound_script', t['semantic_turn_id'])
        if s['turn_id'] != t['turn_id'] or s['program_block_id'] != t['program_block_id']:
            raise RequestRejected('turn_identity_not_from_bound_script', t['semantic_turn_id'])
    if len({t['program_block_id'] for t in gen}) != 1:
        raise RequestRejected('cross_program_block')
    seqs = [turns[t['semantic_turn_id']]['sequence'] for t in gen]
    if seqs != sorted(seqs) or len(set(seqs)) != len(seqs):
        raise RequestRejected('turn_order_not_script_order')
    pb = gen[0]['program_block_id']
    same_block = sorted((x for x in ctx['turns'] if x['program_block_id'] == pb), key=lambda x: x['sequence'])
    if [x['semantic_turn_id'] for x in same_block] != [t['semantic_turn_id'] for t in gen] and gen[0]['semantic_turn_id'] != same_block[0]['semantic_turn_id']:
        raise RequestRejected('block_does_not_begin_at_first_turn_of_program_block')
    c = rec['context']
    n = order.index(pb)
    if c['recipe_version'] == 'C0-v1':
        if c['turns']:
            raise RequestRejected('context_recipe_c0_not_empty')
        if n != 0:
            raise RequestRejected('c0_used_after_the_first_block')
    elif c['recipe_version'] == 'C2-v1':
        if n == 0 or len(c['turns']) != 1:
            raise RequestRejected('context_not_exactly_one_preceding_turn')
        prev = sorted((x for x in ctx['turns'] if x['program_block_id'] == order[n - 1]), key=lambda x: x['sequence'])[-1]
        ct = c['turns'][0]
        if ct['semantic_turn_id'] == gen[-1]['semantic_turn_id'] or any(ct['semantic_turn_id'] == g['semantic_turn_id'] for g in gen):
            raise RequestRejected('context_from_own_block')
        if ct['semantic_turn_id'] != prev['semantic_turn_id']:
            raise RequestRejected('context_not_final_turn_of_preceding_block', ct['semantic_turn_id'])
        if _nfc(ct['spoken_text']) != _nfc(prev['spoken_text']) or ct['participant_id'] != prev['participant_id']:
            raise RequestRejected('context_text_not_from_bound_script', ct['semantic_turn_id'])
    else:
        raise RequestRejected('context_recipe_unknown', str(c['recipe_version']))
    anchors = {t['semantic_turn_id'] for t in gen}
    for i in rec['intents']:
        if i['scope_type'] == 'turn' and i['scope_ref'] not in anchors:
            raise RequestRejected('intent_outside_block', str(i['scope_ref']))
    for p, t in ((t['participant_id'], t) for t in gen):
        vv = rec['voice_versions'].get(p)
        if vv is None:
            raise RequestRejected('voice_binding_missing', p)
        if t['voice_profile_version_id'] != vv['voice_profile_version_id']:
            raise RequestRejected('voice_binding_mismatch', p)
        if rec['concrete_model_identity'] not in vv['provider_model_compatibility']:
            raise RequestRejected('voice_model_incompatible', p)
    for a in rec.get('pronunciation_applications', []):
        t = [x for x in gen if x['semantic_turn_id'] == a['semantic_turn_id']]
        if not t:
            raise RequestRejected('pronunciation_outside_block', a['semantic_turn_id'])
        t = t[0]
        if not (0 <= a['start_offset'] < a['end_offset'] <= len(_nfc(t['spoken_text']))) or _nfc(t['spoken_text'])[a['start_offset']:a['end_offset']] != a['canonical_text']:
            raise RequestRejected('pronunciation_span_mismatch', a['semantic_turn_id'])
        if a['voice_profile_version_id'] != rec['voice_versions'][t['participant_id']]['voice_profile_version_id']:
            raise RequestRejected('pronunciation_wrong_voice', a['semantic_turn_id'])
        if a['provider'] != rec['voice_versions'][t['participant_id']]['provider']:
            raise RequestRejected('pronunciation_provider_mismatch', a['pronunciation_rendering_id'])
        if a['rendering_pronunciation_id'] != a['pronunciation_id']:
            raise RequestRejected('pronunciation_not_derived_from_applied_canonical', a['pronunciation_rendering_id'])
        if a['pronunciation_id'] != a['canonical_current_pronunciation_id']:
            raise RequestRejected('pronunciation_stale', a['pronunciation_rendering_id'])
    ti = rec.get('take_index')
    if not isinstance(ti, int) or isinstance(ti, bool) or ti < 0:
        raise RequestRejected('take_index_invalid')
    return True


class UnknownFixtureRequest(Exception):
    pass


class ProviderSpy:
    """stands in for a live provider; the closed fixture adapter must NEVER reach it"""
    def __init__(self):
        self.calls = 0

    def generate(self, *a, **k):
        self.calls += 1
        raise RuntimeError('a provider call was attempted')


class ClosedFixtureAdapter:
    """frozen request-to-response mapping: resolves projection + base hash + take index, then the literal entry. Unknown = error."""
    def __init__(self, entries, provider):
        self.index = {(e['base_request_hash'], e['intentional_take_index']): e for e in entries}
        self.provider = provider

    def synthesize(self, rec, take_index):
        key = (request_hash(rec), take_index)
        if key not in self.index:
            raise UnknownFixtureRequest('no frozen mapping for %s take %s' % key)
        return self.index[key]


def g_tts_request_vectors(B, f=None):
    f = [] if f is None else f
    V = B['v_base_request']
    ctx = V['script_context']
    base = V['baseline']
    spy = ProviderSpy()
    adapter = ClosedFixtureAdapter(B['proj']['fixture_tts_mapping']['entries'], spy)
    ctr = collections.Counter()
    # 1) the nine ACTUAL block records: projection function -> exact stored projection/hash; ownership validates; mapping resolves
    actual = {p['render_block_sequence']: p for p in B['proj']['tts_base_projections']['projections']}
    blocks = V['actual_blocks']
    if [b['render_block_sequence'] for b in blocks] != list(range(1, 10)):
        f.append('actual block records are not the nine blocks in order')
    for b in blocks:
        seq = b['render_block_sequence']
        try:
            proj = select_projection(b['input_record'])
            h = 'v1:' + H(cb(proj))
            ok = proj == actual[seq]['projection'] and h == actual[seq]['base_request_hash'] == b['expected_hash']
            if not ok:
                f.append('block rb%02d: select_projection does not reproduce the stored projection/base hash' % seq)
            check_ownership(b['input_record'], ctx)
            takes = [e for e in B['proj']['fixture_tts_mapping']['entries'] if e['base_request_hash'] == h]
            for e in takes:
                got = adapter.synthesize(b['input_record'], e['intentional_take_index'])
                if got is not e:
                    f.append('block rb%02d: mapping did not resolve its literal entry' % seq)
            if not takes:
                f.append('block rb%02d has no frozen mapping entry' % seq)
        except (RequestRejected, UnknownFixtureRequest, KeyError, SelectorError) as e:
            f.append('block rb%02d: %s %s' % (seq, type(e).__name__, e))
            ok = False
        ctr['actual_block'] += 1
        _log(B, 'G27', {'id': 'rb%02d' % seq, 'class': 'actual_block', 'outcome': 'as_expected' if ok else 'UNEXPECTED'})
    # 2) baseline
    try:
        bp = select_projection(base['input_record'])
        if bp != base['projection'] or 'v1:' + H(cb(bp)) != base['hash'] or len(bp) != 11:
            f.append('baseline projection/hash does not reproduce (eleven fields)')
        check_ownership(base['input_record'], ctx)
        if base['hash'] != actual[base['block_sequence']]['base_request_hash']:
            f.append('vector baseline is not the actual block %s' % base['block_sequence'])
    except Exception as e:
        f.append('baseline failed: %s %s' % (type(e).__name__, e))
    records = {b['render_block_sequence']: b['input_record'] for b in blocks}
    # 3) vectors
    for v in V['vectors']:
        rec0 = records[v.get('base_block', base['block_sequence'])]
        try:
            rec = apply_mutations(rec0, v['mutations'])
        except SelectorError as e:
            f.append('SELECTOR FAILURE in TTS vector %s: %s' % (v['id'], e))
            _log(B, 'G27', {'id': v['id'], 'class': v['class'], 'outcome': 'SELECTOR_FAILURE'})
            continue
        ex = v['expect']
        h0 = 'v1:' + H(cb(select_projection(rec0)))
        ok = True
        if ex['relation'] in ('same', 'different'):
            try:
                h = request_hash(rec)
            except Exception as e:
                f.append('TTS vector %s: projection failed: %s %s' % (v['id'], type(e).__name__, e))
                ctr[v['class']] += 1
                _log(B, 'G27', {'id': v['id'], 'class': v['class'], 'outcome': 'UNEXPECTED'})
                continue
            rel = 'same' if h == h0 else 'different'
            if rel != ex['relation'] or h != ex['hash']:
                ok = False
                f.append('TTS vector %s (%s): expected %s %s, got %s %s' % (v['id'], v['description'][:60], ex['relation'], str(ex['hash'])[:14], rel, h[:14]))
        elif ex['relation'] == 'reject':
            try:
                check_ownership(rec, ctx)
                ok = False
                f.append('TTS vector %s was accepted; expected rejection %s' % (v['id'], ex['error']))
            except RequestRejected as e:
                if e.code != ex['error']:
                    ok = False
                    f.append('TTS vector %s rejected with %s, expected %s' % (v['id'], e.code, ex['error']))
        elif ex['relation'] == 'unknown_request':
            before = spy.calls
            try:
                adapter.synthesize(rec, v.get('take_index', rec.get('take_index', 0)))
                ok = False
                f.append('TTS vector %s resolved a frozen mapping; expected an unknown fixture request' % v['id'])
            except UnknownFixtureRequest:
                pass
            if spy.calls != before:
                ok = False
                f.append('TTS vector %s reached the provider' % v['id'])
        elif ex['relation'] == 'known_request':
            before = spy.calls
            try:
                got = adapter.synthesize(rec, v.get('take_index', 0))
                if got['wav_member_path'] not in B['pack'].data:
                    ok = False
                    f.append('TTS vector %s mapping entry names a missing WAV' % v['id'])
            except UnknownFixtureRequest:
                ok = False
                f.append('TTS vector %s did not resolve a frozen mapping' % v['id'])
            if spy.calls != before:
                ok = False
        ctr[v['class']] += 1
        _log(B, 'G27', {'id': v['id'], 'class': v['class'], 'outcome': 'as_expected' if ok else 'UNEXPECTED'})
    if spy.calls != 0:
        f.append('the closed fixture adapter reached the provider %d time(s)' % spy.calls)
    B['notes']['G27_counts'] = dict(ctr)
    B['notes']['G27_provider_calls'] = spy.calls
    return f


# ---------------------------------------------------------------- G28: claim / event conformance (offline reducer, append, cursor)
USAGE_ORDER = {'assertable': 0, 'hedged_only': 1, 'silent': 2}
STATUS_FOR = {'confirm': 'confirmed', 'contest': 'contested', 'demote': 'demoted', 'supersede': 'superseded', 'expire': 'expired', 'tombstone': 'tombstoned'}
EVENT_TYPES = set(STATUS_FOR) | {'usage_change'}
EV_KEYS = {'claim_state_event_id', 'claim_id', 'actor_id', 'occurred_at', 'event_type', 'event_sequence', 'event_payload'}


class ClaimEventError(Exception):
    def __init__(self, code, detail=''):
        super().__init__('%s %s' % (code, detail))
        self.code = code


class ClaimLog:
    """offline model of claim-local sequence rules; NOT database concurrency proof"""
    def __init__(self, claims):
        self.claims = claims
        self.events = {cid: [] for cid in claims}
        self.by_uuid = {}

    def append(self, ev):
        if not isinstance(ev, dict) or set(ev) != EV_KEYS:
            raise ClaimEventError('invalid_event_shape')
        cid = ev['claim_id']
        if cid not in self.claims:
            raise ClaimEventError('wrong_claim')
        if ev['event_type'] not in EVENT_TYPES:
            raise ClaimEventError('invalid_payload', 'unknown event_type')
        pl = ev['event_payload']
        if not isinstance(pl, dict) or not pl.get('reason_code') or not pl.get('reason'):
            raise ClaimEventError('invalid_payload', 'reason missing')
        if ev['event_type'] == 'usage_change' and pl.get('usage_class') not in USAGE_ORDER:
            raise ClaimEventError('invalid_payload', 'usage_change without a valid usage_class')
        seq = ev['event_sequence']
        if not isinstance(seq, int) or isinstance(seq, bool):
            raise ClaimEventError('sequence_not_integer')
        if seq <= 0:
            raise ClaimEventError('sequence_not_positive')
        prior = self.by_uuid.get(ev['claim_state_event_id'])
        if prior is not None:
            if prior == ev:
                return 'converged'      # an identical retry converges on the existing event; nothing is appended
            if prior['claim_id'] != cid or prior['event_payload'] != ev['event_payload'] or prior['event_type'] != ev['event_type']:
                raise ClaimEventError('duplicate_event_identity_conflict')
            raise ClaimEventError('retry_duplicate_transition', 'same authored event identity under a new sequence')
        log = self.events[cid]
        mx = max((e['event_sequence'] for e in log), default=0)
        if seq in {e['event_sequence'] for e in log}:
            raise ClaimEventError('duplicate_sequence')
        if not log and seq != 1:
            raise ClaimEventError('first_sequence_not_one')
        if log and seq <= mx:
            raise ClaimEventError('not_monotonic', 'earlier/gap insertion below the largest accepted sequence')
        log.append(copy.deepcopy(ev))
        self.by_uuid[ev['claim_state_event_id']] = copy.deepcopy(ev)
        return 'appended'

    def reduce(self, cid, through=None, events=None, ceiling='assertable'):
        c = self.claims[cid]
        evs = list(self.events[cid] if events is None else events)
        evs = sorted(evs, key=lambda e: e['event_sequence'])        # sequence order ONLY (never JSON / UUID / timestamp order)
        if through is not None:
            evs = [e for e in evs if e['event_sequence'] <= through]
        status, usage = c['initial_status'], c['initial_usage_class']
        for e in evs:
            if e['event_type'] == 'usage_change':
                usage = e['event_payload']['usage_class']
            else:
                status = STATUS_FOR[e['event_type']]
        eff = usage if USAGE_ORDER[usage] >= USAGE_ORDER[ceiling] else ceiling
        return {'state': status, 'reduced_usage_class': usage, 'effective_usage_class': eff}

    def check_cursor(self, cid, cursor, visible, prefix):
        """Evidence Package v0.2.2 s9.3: a non-null cursor names the SAME claim and the EXACT LAST event of the committed claim-local prefix
        VISIBLE AT FREEZE. `visible` = the immutable rows visible to the freeze; `prefix` = the rows the snapshot selected. Both must be exact
        accepted rows (no changed payloads, no duplicates); the cursor event must occur in `visible` (a later live event cannot serve as an old
        cursor); `visible` must itself contain every accepted earlier event through its maximum sequence."""
        for label, rows in (('visible', visible), ('prefix', prefix)):
            for e in rows:
                if not isinstance(e, dict) or set(e) != EV_KEYS or e['claim_id'] != cid:
                    raise ClaimEventError('%s_row_not_claim_local' % label)
                if not _strict_int(e['event_sequence']) or e['event_sequence'] < 1:
                    raise ClaimEventError('%s_row_sequence_invalid' % label)
            if len({e['claim_state_event_id'] for e in rows}) != len(rows) or len({e['event_sequence'] for e in rows}) != len(rows):
                raise ClaimEventError('duplicate_%s_row' % label)
        vis = sorted(visible, key=lambda e: e['event_sequence'])
        accepted = sorted(self.events.get(cid, []), key=lambda e: e['event_sequence'])
        if vis:
            want = [e for e in accepted if e['event_sequence'] <= vis[-1]['event_sequence']]
            if vis != want:
                have = {e['claim_state_event_id'] for e in vis}
                raise ClaimEventError('visible_omits_accepted_event' if any(e['claim_state_event_id'] not in have for e in want) else 'visible_row_not_an_accepted_row')
        if cursor is None:
            if vis:
                raise ClaimEventError('null_cursor_with_visible_events')
            if prefix:
                raise ClaimEventError('null_cursor_with_nonempty_prefix')
            return True
        if not isinstance(cursor, dict) or set(cursor) != {'claim_state_event_id', 'event_sequence'}:
            raise ClaimEventError('cursor_shape')
        if not _strict_int(cursor['event_sequence']):
            raise ClaimEventError('cursor_sequence_type')
        if cursor['event_sequence'] < 1:
            raise ClaimEventError('cursor_sequence_not_positive')
        ev = self.by_uuid.get(cursor['claim_state_event_id'])
        if ev is None:
            raise ClaimEventError('cursor_event_unknown')
        if ev['claim_id'] != cid:
            raise ClaimEventError('cursor_wrong_claim')
        if ev['event_sequence'] != cursor['event_sequence']:
            raise ClaimEventError('cursor_sequence_mismatch')
        if not vis:
            raise ClaimEventError('cursor_with_empty_visibility')
        if ev['claim_state_event_id'] not in {e['claim_state_event_id'] for e in vis}:
            raise ClaimEventError('cursor_not_in_visible_set')
        if ev['event_sequence'] != vis[-1]['event_sequence']:
            raise ClaimEventError('cursor_older_than_visible_event')
        pre = sorted(prefix, key=lambda e: e['event_sequence'])
        want = [e for e in vis if e['event_sequence'] <= cursor['event_sequence']]
        if pre != want:
            wid = {e['claim_state_event_id'] for e in want}
            raise ClaimEventError('omitted_prefix_event' if all(e in want for e in pre) and len(pre) < len(want) else 'prefix_row_differs_from_visible')
        return True


def _strict_int(x):
    return isinstance(x, int) and not isinstance(x, bool)


CLAIM_OPS = {'append', 'reduce', 'frozen_hash', 'snapshot', 'cursor'}
REDUCE_ORDERS = {'sequence', 'reverse_json', 'reverse_uuid', 'reverse_time'}


def preflight_claim_vector(v, claims):
    """static selector check BEFORE a claim vector executes: every operation, claim, snapshot name, referenced event id, order and
    ceiling must resolve. A failure is a HARNESS failure (SelectorError), never evidence of domain rejection."""
    snaps, ids = {}, set()
    for n, st in enumerate(v['steps'], 1):
        op = st.get('op')
        if op not in CLAIM_OPS:
            raise SelectorError('step %d: unknown op %r' % (n, op))
        if 'expect' not in st:
            raise SelectorError('step %d: no declared expectation' % n)
        if op == 'append':
            e = st.get('event')
            if not isinstance(e, dict) or 'claim_state_event_id' not in e:
                raise SelectorError('step %d: append has no event row' % n)
            if str(st['expect']).startswith('ok'):
                ids.add(e['claim_state_event_id'])
            continue
        if st.get('claim') not in claims:
            raise SelectorError('step %d: claim %r is not a declared vector claim' % (n, st.get('claim')))
        if op == 'snapshot':
            if not isinstance(st.get('name'), str) or st['name'] in snaps:
                raise SelectorError('step %d: snapshot name missing or reused' % n)
            snaps[st['name']] = set(ids)
        elif op == 'reduce':
            if 'order' in st and st['order'] not in REDUCE_ORDERS:
                raise SelectorError('step %d: unknown order %r' % (n, st['order']))
            if 'ceiling' in st and st['ceiling'] not in USAGE_ORDER:
                raise SelectorError('step %d: unknown ceiling %r' % (n, st['ceiling']))
            if 'through' in st and not _strict_int(st['through']):
                raise SelectorError('step %d: through is not an integer' % n)
        elif op == 'cursor':
            if 'visible' in st and st['visible'] not in snaps:
                raise SelectorError('step %d: visible snapshot %r was not taken earlier' % (n, st['visible']))
            pool = snaps[st['visible']] if 'visible' in st else ids
            refs = list(st.get('prefix', [])) + list(st.get('prefix_dup', [])) + list(st.get('prefix_edit', {})) + list(st.get('visible_drop', [])) + list(st.get('visible_dup', [])) + list(st.get('visible_edit', {}))
            for r in refs:
                if r not in ids:
                    raise SelectorError('step %d: referenced event id %r was never accepted by this vector' % (n, r))
            for r in list(st.get('visible_drop', [])) + list(st.get('visible_dup', [])) + list(st.get('visible_edit', {})):
                if r not in pool:
                    raise SelectorError('step %d: %r is not in the visibility set it is edited in' % (n, r))


def g_claim_event_vectors(B, f=None):
    f = [] if f is None else f
    V = B['v_claims']
    ctr = collections.Counter()
    # actual base: zero events, nine null cursors, states reproduce from initial fields
    if B['load']['claim_state_events']:
        f.append('base load contains claim state events')
    pk = B['members']['evidence_package']['manifest']['claims']
    if len(pk) != 9 or any(c['state_event_cursor'] is not None for c in pk):
        f.append('base package does not carry nine null cursors')
    claims = {c['claim_id']: {'initial_status': c['initial_status'], 'initial_usage_class': c['initial_usage_class']} for c in B['load']['claims']}
    log0 = ClaimLog(claims)
    for c in B['load']['claims']:
        red = log0.reduce(c['claim_id'])
        if red['state'] != c['initial_status'] or red['reduced_usage_class'] != c['initial_usage_class']:
            f.append('zero-event reduction does not start and end at the initial fields: %s' % c['claim_id'])
        pc = [x for x in pk if x['claim_id'] == c['claim_id']][0]
        fs = DH('claim-frozen-state-v1', {'claim_content_hash': c['content_hash'], 'state': red['state'], 'effective_usage_class': red['effective_usage_class']})
        if pc['frozen_state_hash'] != fs:
            f.append('package frozen_state_hash does not reproduce from initial fields: %s' % c['claim_id'])
        try:
            log0.check_cursor(c['claim_id'], pc['state_event_cursor'], [], [])
        except ClaimEventError as e:
            f.append('null cursor rejected: %s' % e.code)
    ctr['actual_base_claims'] = len(claims)
    # isolated usage-change scenario: sequence 1, status stays confirmed, live usage silent, frozen package unchanged
    sc = B['members']['scenarios']['scenarios']['usage_change']
    ev = sc['rows']['claim_state_events'][0]
    lg = ClaimLog(claims)
    try:
        lg.append(ev)
        red = lg.reduce(ev['claim_id'])
        ex = sc['expectations']
        if red['state'] != ex['live_status'] or red['reduced_usage_class'] != ex['live_usage'] or ev['event_sequence'] != 1 or ex['old_package_cursor'] is not None:
            f.append('isolated usage-change scenario does not reduce to confirmed/silent at sequence 1')
        c = [x for x in B['load']['claims'] if x['claim_id'] == ev['claim_id']][0]
        old = [x for x in pk if x['claim_id'] == ev['claim_id']][0]
        new_fs = DH('claim-frozen-state-v1', {'claim_content_hash': c['content_hash'], 'state': red['state'], 'effective_usage_class': red['effective_usage_class']})
        if new_fs == old['frozen_state_hash']:
            f.append('usage-change scenario does not differ materially from the frozen snapshot')
        lg.check_cursor(ev['claim_id'], None, [], [])     # the OLD package cursor (null) still binds its empty prefix
    except ClaimEventError as e:
        f.append('isolated usage-change scenario rejected: %s' % e)
    ctr['isolated_usage_change'] = 1
    # data-driven vectors
    base_claims = V['claims']
    for v in V['vectors']:
        lg = ClaimLog(base_claims)
        ok = True
        msg = ''
        snapshots = {}
        try:
            preflight_claim_vector(v, base_claims)
        except SelectorError as e:
            f.append('SELECTOR FAILURE in claim vector %s (preflight): %s' % (v['id'], e))
            ctr[v['class']] += 1
            _log(B, 'G28', {'id': v['id'], 'class': v['class'], 'outcome': 'SELECTOR_FAILURE'})
            continue
        for n, st in enumerate(v['steps'], 1):
            op, want = st['op'], st['expect']
            try:
                if op == 'append':
                    got = 'ok:' + lg.append(st['event'])
                elif op == 'reduce':
                    events = None
                    if 'order' in st:
                        evs = copy.deepcopy(lg.events[st['claim']])
                        if st['order'] == 'reverse_json':
                            evs = evs[::-1]
                        elif st['order'] == 'reverse_uuid':
                            evs = sorted(evs, key=lambda e: e['claim_state_event_id'], reverse=True)
                        elif st['order'] == 'reverse_time':
                            evs = sorted(evs, key=lambda e: e['occurred_at'], reverse=True)
                        elif st['order'] == 'sequence':
                            pass
                        else:
                            raise SelectorError('unknown order ' + st['order'])
                        events = evs
                    got = lg.reduce(st['claim'], through=st.get('through'), events=events, ceiling=st.get('ceiling', 'assertable'))
                    got = {k: got[k] for k in want}
                elif op == 'frozen_hash':
                    red = lg.reduce(st['claim'], through=st.get('through'), ceiling=st.get('ceiling', 'assertable'))
                    got = DH('claim-frozen-state-v1', {'claim_content_hash': base_claims[st['claim']]['claim_content_hash'], 'state': red['state'],
                                                       'effective_usage_class': red['effective_usage_class']})
                elif op == 'snapshot':      # freeze: record the visible events at this instant
                    snapshots[st['name']] = copy.deepcopy(lg.events[st['claim']])
                    got = 'ok'
                elif op == 'cursor':
                    vis = copy.deepcopy(snapshots[st['visible']] if 'visible' in st else lg.events[st['claim']])
                    live = {e['claim_state_event_id']: e for e in lg.by_uuid.values()}
                    rows = {e['claim_state_event_id']: e for e in vis}

                    def edit(row, ch):
                        r = copy.deepcopy(row)
                        r.update(copy.deepcopy(ch))
                        return r
                    for eid, ch in st.get('visible_edit', {}).items():
                        vis = [edit(e, ch) if e['claim_state_event_id'] == eid else e for e in vis]
                    vis = [e for e in vis if e['claim_state_event_id'] not in set(st.get('visible_drop', []))]
                    for eid in st.get('visible_dup', []):
                        vis.append(copy.deepcopy([e for e in vis if e['claim_state_event_id'] == eid][0]))
                    base = {e['claim_state_event_id']: e for e in vis}
                    if 'prefix' in st:
                        pre = [copy.deepcopy(base.get(i) or rows.get(i) or live[i]) for i in st['prefix']]
                    else:
                        pre = copy.deepcopy(vis)
                    for eid, ch in st.get('prefix_edit', {}).items():
                        pre = [edit(e, ch) if e['claim_state_event_id'] == eid else e for e in pre]
                    for eid in st.get('prefix_dup', []):
                        pre.append(copy.deepcopy([e for e in pre if e['claim_state_event_id'] == eid][0]))
                    got = 'ok:' + str(lg.check_cursor(st['claim'], st['cursor'], vis, pre))
                else:
                    raise SelectorError('unknown op ' + op)
            except ClaimEventError as e:
                got = 'reject:' + e.code
            except (SelectorError, KeyError) as e:
                f.append('SELECTOR FAILURE in claim vector %s step %d: %s %s' % (v['id'], n, type(e).__name__, e))
                ok = False
                break
            if got != want:
                ok = False
                msg = 'claim vector %s step %d (%s): expected %r, got %r' % (v['id'], n, op, want, got)
                f.append(msg)
                break
        ctr[v['class']] += 1
        _log(B, 'G28', {'id': v['id'], 'class': v['class'], 'outcome': 'as_expected' if ok else 'UNEXPECTED'})
    B['notes']['G28_counts'] = dict(ctr)
    return f


# ====================================================================== G29 / G30 (I2C additions)
SUPPORT_ROLES = {'supports_value', 'supports_attribution', 'qualifies', 'contradicts', 'context_only'}
TENOR_OBSERVATIONS = 4


def g_support_window_continuity(B, f=None):
    """G29: support roles and snapshot equality; five-match window proof; tenor and continuity carrier proofs (Claims v0.1.2 s4.3,
    Evidence Package v0.2.2, Hashing v0.1.4 s12.3-12.4). Deterministic structure checks over the shipped rows and payloads."""
    f = [] if f is None else f
    L = B['load']
    pk = B['members']['evidence_package']['manifest']
    rows_by_claim = collections.defaultdict(list)
    for s in L['claim_supports']:
        if s.get('support_role') not in SUPPORT_ROLES:
            f.append('support %s has a role outside the closed five-value vocabulary: %r' % (s['claim_support_id'], s.get('support_role')))
        rows_by_claim[s['claim_id']].append(s)
    ids = {c['claim_id'] for c in L['claims']}
    for cid in ids:
        if not any(s.get('support_role') == 'supports_value' for s in rows_by_claim[cid]):
            f.append('claim %s has no supports_value support (only supports_value establishes a voiceable value)' % cid)
    # package support snapshot equals the durable support rows (ids, kind, role, target, hash)
    cols = ('claim_support_id', 'derivation_run_id', 'evidence_unit_id', 'external_support_identity', 'support_hash', 'support_kind', 'support_role')
    for c in pk['claims']:
        want = sorted(({k: s[k] for k in cols} for s in rows_by_claim[c['claim_id']]), key=lambda x: x['claim_support_id'])
        got = sorted(c['support_refs'], key=lambda x: x['claim_support_id'])
        if want != got:
            f.append('package support snapshot differs from the support rows (ids/kind/role/target/hash) for claim %s' % c['claim_id'])
    # five-match window proof
    mw = pk['selection_provenance']['match_window_proof']
    sched = mw['ordered_prior_schedule']
    cur = mw['current_event']
    if [s['rank_before_current_event'] for s in sched] != list(range(1, len(sched) + 1)) or len(sched) != 6:
        f.append('prior schedule is not the complete ranked six most recent matches')
    done = [s['completed_at'] for s in sched]
    if done != sorted(done, reverse=True) or len(set(done)) != len(done):
        f.append('prior schedule is not strictly descending by completion time')
    if any(s['completion_status'] != 'final' or s['competition_identity'] != mw['competition_identity'] or s['entity_identity'] != mw['entity_identity'] for s in sched):
        f.append('a prior schedule entry is not a final league match of the scoped entity/competition')
    if not (done[0] < cur['completed_at'] <= mw['as_of']) or cur['completion_status'] != 'final' or mw['current_event_identity'] != cur['event_identity']:
        f.append('current event is not final and later than every prior match and not after the as-of time')
    if mw['complete_prior_schedule_assertion'] is not True:
        f.append('window proof does not assert a complete prior schedule')
    sel = mw['selected_event_identities']
    if sel != [s['event_identity'] for s in sched[:5]] or len(set(sel)) != 5:
        f.append('selected five-match window is not the five most recent prior matches in descending order')
    dr = L['derivation_runs'][0]
    refs = dr['exact_input_refs']
    if len(refs) != 5 or len({r['evidence_unit_id'] for r in refs}) != 5:
        f.append('derivation does not use five distinct evidence units')
    by_ev = {e['evidence_unit_id']: e for e in pk['evidence']}
    if sorted(by_ev[r['evidence_unit_id']]['event_identity'] for r in refs if r['evidence_unit_id'] in by_ev) != sorted(sel):
        f.append('derivation input events differ from the selected match window')
    comp = {s['event_identity']: s['completed_at'] for s in sched}
    for r in refs:
        sp = r['selected_provenance']
        if sp['event_identity'] not in comp or sp['event_completed_at'] != comp[sp['event_identity']] or sp['competition_identity'] != mw['competition_identity'] \
                or sp['entity_identity'] != mw['entity_identity'] or not sp['event_completed_at'] <= sp['as_of'] <= mw['as_of']:
            f.append('derivation input provenance disagrees with the window proof: %s' % r['evidence_unit_id'])
    par = dr.get('parameters')
    if par != {'after_minute': 80, 'window_matches': 5}:
        f.append('derivation parameters are not {after_minute: 80, window_matches: 5}')
    # supporter tenor carrier
    car = {a['artifact_id']: a['canonical_payload'] for a in L['artifacts'] if a['artifact_type'] in ('tenor_support', 'continuity_support')}
    tenor = [p for p in car.values() if p.get('support_kind') == 'signal']
    cont = [p for p in car.values() if p.get('support_kind') == 'continuity']
    if len(tenor) != 1 or len(cont) != 1:
        f.append('support carriers are not exactly one signal and one continuity')
        return f
    tp = tenor[0]['projection']
    obs = tp['observations']
    if tp['observation_count'] != len(obs) or len(obs) != TENOR_OBSERVATIONS or [o['observation_order'] for o in obs] != list(range(1, len(obs) + 1)):
        f.append('tenor observation count/order is not four ordered observations')
    evs = {e['evidence_unit_id']: e for e in L['evidence_units']}
    for o in obs:
        e = by_ev.get(o['evidence_unit_id'])
        if e is None or evs.get(o['evidence_unit_id']) is None or e['source_identity'] != o['source_identity'] or H(unicodedata.normalize('NFC', evs[o['evidence_unit_id']]['canonical_content']).encode('utf-8')) != o['content_hash']:
            f.append('tenor observation does not match its evidence row: %s' % o['evidence_unit_id'])
    if len({o['source_identity'] for o in obs}) != len(obs):
        f.append('tenor observations are not from four distinct supporter sources')
    # continuity carrier
    cp = cont[0]['projection']
    occ, att = cp['on_air_occurrence'], cp['publication_attestation']
    if cp['withdrawn'] is not False or att.get('state') != 'published' or att.get('synthetic') is not True:
        f.append('continuity carrier is withdrawn or lacks a published synthetic attestation')
    if not (occ['occurrence_time'] < att['published_at'] <= mw['as_of']):
        f.append('continuity occurrence/publication times are not prior to the freeze as-of time in order')
    for k in ('external_episode_ref', 'external_script_ref', 'external_script_version_ref'):
        if not isinstance(cp.get(k), str) or not cp[k].startswith('fixture-external:'):
            f.append('continuity carrier external ref %s is not a fixture-external reference' % k)
    if not occ.get('exact_text') or not occ.get('position') or not occ.get('semantic_turn_ref'):
        f.append('continuity carrier lacks the exact prior text/position/turn reference')
    cid = [a['artifact_id'] for a in L['artifacts'] if a['artifact_type'] == 'continuity_support'][0]
    pc = [c for c in pk['continuity'] if c['continuity_id'] == 'artifact:' + cid]
    if len(pc) != 1 or pc[0]['published_only'] is not True or pc[0]['withdrawn'] is not False or pc[0]['topic_thread_id'] != cp['topic_thread_id']:
        f.append('package continuity entry does not match the continuity carrier')
    # Brief comprehension targets: no production repetition-count / density optimisation field (predecessor NV20, deterministic)
    allowed = {'closing_synthesis_candidate', 'comprehension_target_id', 'forward_horizon', 'listener_question', 'priority', 'related_beat_ids',
               'supporting_claim_refs', 'useful_treatment_lenses'}
    for t in B['members']['showrunner_brief']['comprehension_targets']:
        if set(t) - allowed or any(re.search(r'reinforc|repeat|density|count', k) for k in t):
            f.append('comprehension target carries a repetition-count/density field: %s' % sorted(set(t) - allowed))
    # context candidates point at real, usable claims
    byc = {c['claim_id']: c for c in pk['claims']}
    for cc in pk['context_candidates']:
        c = byc.get(cc['claim_id'])
        if c is None or c['effective_usage_class'] == 'silent':
            f.append('context candidate %s does not reference a usable packaged claim' % cc['context_id'])
    return f


def _dec_parts(txt):
    m = re.fullmatch(r'(0|[1-9][0-9]*)(?:\.([0-9]+))?', txt if isinstance(txt, str) else '')
    if not m:
        return None
    return int(m.group(1) + (m.group(2) or '')), len(m.group(2) or '')


def g_exact_timing(B, f=None):
    """G30: exact decimal/frame timing (P&R v0.1.4 s30.1). duration_seconds is validated against frame_count / sample_rate at its
    declared precision by exact integer arithmetic; duration_ms = floor(seconds * 1000 + 0.5). No binary floating point anywhere."""
    f = [] if f is None else f
    L = B['load']
    arts = _arts(B)
    n = 0
    rows = {r['artifact_id']: r for r in L['audio_artifacts']}
    for a in arts.values():
        if not str(a['artifact_id']).startswith('66666666'):
            continue
        p = a['canonical_payload']
        n += 1
        parts = _dec_parts(p.get('duration_seconds'))
        if parts is None:
            f.append('duration_seconds is not nonnegative decimal text (no sign/exponent/non-finite): %s %r' % (a['artifact_id'], p.get('duration_seconds')))
            continue
        digits, prec = parts
        frames, rate = p['frame_count'], p['sample_rate_hz']
        if not (isinstance(frames, int) and isinstance(rate, int) and frames > 0 and rate > 0):
            f.append('frame_count/sample_rate_hz are not positive integers: %s' % a['artifact_id'])
            continue
        num = frames * 10 ** prec
        q, r = divmod(num, rate)
        if 2 * r >= rate:
            q += 1                                   # exact rational rounded to the declared precision, ties upward
        if q != digits:
            f.append('duration_seconds %s is not frame_count/sample_rate rounded to %d places: %s' % (p['duration_seconds'], prec, a['artifact_id']))
        ms = (2 * digits * 1000 + 10 ** prec) // (2 * 10 ** prec)    # floor(seconds*1000 + 0.5) in integers
        row = rows.get(a['artifact_id'])
        if row is None or row['duration_ms'] != ms:
            f.append('audio row duration_ms %s != floor(duration_seconds*1000+0.5)=%d: %s' % (None if row is None else row['duration_ms'], ms, a['artifact_id']))
        if 'duration_semantics' not in p:
            f.append('audio artifact lacks the duration_semantics statement: %s' % a['artifact_id'])
    if n != 12:
        f.append('not twelve audio artifacts for timing validation')
    mp = B['members']['master_assembly_map__successor']
    end = 0
    for sg in mp['segments']:
        if sg['start_frame'] != end or sg['end_frame'] <= sg['start_frame']:
            f.append('segment frames are not contiguous positive integers')
        end = sg['end_frame']
    if mp['sample_rate_hz'] != 48000 or end != 57119:
        f.append('master map does not end at the exact 57,119-frame position at 48 kHz')
    return f


# ====================================================================== G31 / G32 (R2): programming-configuration closure and the runtime-budget gate
CFG_PINS = {   # raw SHA-256 of the unchanged preserved predecessor / authority bytes (supervisory handoff section 3)
    'config/block_types.json': 'a6db53ee315437200bfadd76c988860512a9a36588e865dd8d78581c32dcfbb7',
    'config/episode_modes.json': 'b03b3889cdc1b1facf4be77d76e2212d3d166f7e406c589aae8a9e8bf1d06586',
    'config/rundown_template_post_event_launch_v2.json': '4c74bc6563680d907233921333a6528463ec5819a2375786ba77efbb15e3a9f6',
    'config/participant_profiles.json': '86fc33c6c4d9bb6c1226f4774815341716a677d8a04bfacea997658087440b61',
    'config/enum_registries.json': 'ba2d1ee8602b216d200cd5eec1cf1f20367e5a071f4509552d32afc47c64e4fd',
    'provenance/predecessor/config/voice_profile_versions.json': '0f3c6d4043220ee60eb5ed9c111142d804cef708dd865140f6783b9e094cccc7',
    'authority/02_ACTIVE_SPECS/The_Desk_Character_Bible_v0.1.4.md': '5e38c5163ffee8757e38fce14a1919caf000f7e2f7c3159b949351d6962b313c',
}
UNRESOLVED_BASE_GATES = set()    # CONFIG-330: the inherited runtime-budget gate is resolved (provenance/RUNTIME_BUDGET_RESOLUTION.md); every group failure is an ordinary failure


def _dups(seq):
    c = collections.Counter(seq)
    return sorted(k for k, n in c.items() if n > 1)


def g_programming_configuration(B, f=None):
    """G31: configuration closure. The Brief and the show configuration SELECT a mode/template/participants; those selections must resolve, uniquely and
    compatibly, against shipped registries/template/profiles (Showrunner Planning v0.1.3 s7, s23 gates 2/6/12). Derived from shipped data only."""
    f = [] if f is None else f
    pack, C = B['pack'], B['cfg']
    for name, want in CFG_PINS.items():
        b = pack.data.get(name)
        if b is None:
            f.append('configuration member missing: %s' % name)
        elif H(b) != want:
            f.append('configuration member differs from its pinned preserved bytes: %s' % name)
    modes, blocks, part, enums = C['modes'], C['blocks'], C['participants'], C['enums']
    mode_ids = [v.get('id') for v in (modes or {}).get('values', [])]
    block_ids = [v.get('id') for v in (blocks or {}).get('values', [])]
    for label, ids in (('episode-mode registry', mode_ids), ('block-type registry', block_ids)):
        if not ids or _dups(ids):
            f.append('%s is empty or has duplicate ids: %s' % (label, _dups(ids)))
    profiles = (part or {}).get('profiles', [])
    pids = [p.get('participant_id') for p in profiles]
    if not pids or _dups(pids) or _dups([p.get('participant_profile_version_id') for p in profiles]):
        f.append('participant profiles are empty or have duplicate participant/profile ids')
    bible = pack.data.get(PATH['bible'], b'').decode('utf-8', 'replace')
    bv = re.search(r'Character Bible v(\d+\.\d+\.\d+)', bible[:400])
    for p in profiles:
        if not bv or p.get('character_bible_version') != bv.group(1):
            f.append('participant profile %s names Character Bible %r but the shipped source is v%s' % (p.get('participant_id'), p.get('character_bible_version'), bv and bv.group(1)))
    cur = current_config(B)
    show = cur['canonical_payload']
    if B['members']['config_show_version'] != cur:
        f.append('show configuration member differs from the loaded current show_config_versions row')
    brief = B['members']['showrunner_brief']
    sel_id, sel_mode = brief.get('rundown_template_version_id'), brief.get('selected_mode')
    # exact, unique template selection (show default and Brief selection)
    tpls = C['templates']
    tids = [t.get('rundown_template_version_id') for _, t in tpls]
    if _dups(tids):
        f.append('template selection is not unique: duplicate template version ids %s' % _dups(tids))
    if show.get('default_rundown_template_version_id') != sel_id:
        f.append('Brief selects template %r but the show configuration selects %r' % (sel_id, show.get('default_rundown_template_version_id')))
    cand = [t for _, t in tpls if t.get('rundown_template_version_id') == sel_id]
    if len(cand) != 1:
        f.append('template selection is not unique: %d shipped templates match %r' % (len(cand), sel_id))
        return f
    tpl = cand[0]
    if tpl.get('status') != 'active':
        f.append('selected template is not active')
    # modes: show default and Brief selection exist in the registry and are compatible with the template
    for label, m in (('show default mode', show.get('default_episode_mode')), ('Brief selected mode', sel_mode)):
        if m not in mode_ids:
            f.append('%s %r is not in the episode-mode registry' % (label, m))
    if tpl.get('mode') != sel_mode:
        f.append('template mode %r is not compatible with the Brief selected mode %r' % (tpl.get('mode'), sel_mode))
    if show.get('default_episode_mode') != sel_mode:
        f.append('show default mode %r differs from the Brief selected mode %r' % (show.get('default_episode_mode'), sel_mode))
    # slots: unique ids/sequences, registry block types, required / optional
    slots = tpl.get('slots', [])
    sids = [s.get('slot_id') for s in slots]
    if _dups(sids) or _dups([s.get('sequence') for s in slots]) or [s.get('sequence') for s in slots] != sorted(s.get('sequence') for s in slots):
        f.append('template slots have duplicate ids/sequences or are not in sequence order')
    for s in slots:
        if s.get('block_type') not in block_ids:
            f.append('template slot %s names block type %r that is not in the block-type registry' % (s.get('slot_id'), s.get('block_type')))
        if not isinstance(s.get('required'), bool):
            f.append('template slot %s required flag is not boolean' % s.get('slot_id'))
    by_slot = {s.get('slot_id'): s for s in slots}
    used = [b.get('template_slot_id') for b in brief['program_blocks']]
    if _dups(used):
        f.append('Brief fills a template slot more than once: %s' % _dups(used))
    for b in brief['program_blocks']:
        s = by_slot.get(b.get('template_slot_id'))
        if s is None:
            f.append('Brief block %s names unknown template slot %r' % (b.get('program_block_id'), b.get('template_slot_id')))
            continue
        if b.get('block_type') != s.get('block_type'):
            f.append('Brief block for slot %s has block type %r, template says %r' % (s['slot_id'], b.get('block_type'), s.get('block_type')))
        if b.get('block_type') not in block_ids:
            f.append('Brief block type %r is not in the block-type registry' % b.get('block_type'))
    for s in slots:
        if s.get('slot_id') not in used and s.get('required') is True:
            f.append('required template slot %s is not filled by the Brief' % s.get('slot_id'))
    order = [by_slot[u]['sequence'] for u in used if u in by_slot]
    if order != sorted(order):
        f.append('Brief blocks are not in template slot order')
    if [b.get('sequence') for b in brief['program_blocks']] != list(range(1, len(brief['program_blocks']) + 1)):
        f.append('Brief block sequences are not contiguous from 1')
    # participants named anywhere in the Brief / scripts / voices exist in the participant configuration
    named = set()
    for b in brief['program_blocks']:
        named |= {l.get('participant_id') for l in b.get('participant_leads', [])}
        named |= {a.get('participant_id') for a in b.get('claim_evidence_assignments', [])}
    named |= {t['participant_id'] for t in B['load']['turns']}
    named |= {p['participant_identity'] for p in (B['src']['voice_profiles'] or {}).get('voice_profiles', [])}
    for n in sorted(x for x in named if x not in pids):
        f.append('participant %r is not in the participant configuration' % n)
    # runtime configuration applicable to the selection
    band = show.get('configured_runtime_seconds')
    if not (isinstance(band, dict) and set(band) == {'min', 'max', 'fixture_override'} and _strict_int(band['min']) and _strict_int(band['max']) and 0 < band['min'] < band['max']
            and isinstance(band['fixture_override'], bool)):
        f.append('configured_runtime_seconds is not {min < max positive integers, fixture_override boolean}')
    else:
        rt = tpl.get('runtime') or {}
        if band['fixture_override'] and rt.get('fixture_override_allowed') is not True:
            f.append('the show configuration uses fixture_override but the selected template does not allow it')
        rtt = brief.get('runtime_target')
        if not (isinstance(rtt, dict) and _strict_int(rtt.get('seconds')) and band['min'] <= rtt['seconds'] <= band['max']):
            f.append('Brief runtime_target is malformed or outside the configured runtime band')
        elif rtt.get('purpose') != 'evaluation_fixture':
            f.append('Brief runtime_target purpose is not evaluation_fixture (planning gate 14)')
    # preserved enum registry: only its declared closed fields are checked against the shipped data
    closed = (enums or {}).get('closed', {})
    for e in B['members']['evidence_package']['manifest']['evidence']:
        for fld in ('modality', 'origin', 'evidence_type'):
            if fld in closed and e.get(fld) not in closed[fld]:
                f.append('evidence %s %s %r is not in the closed registry' % (e.get('evidence_unit_id'), fld, e.get(fld)))
    for e in B['load']['evidence_units']:
        for fld in ('usage_class', 'evidence_type'):
            if fld in closed and e.get(fld) not in closed[fld]:
                f.append('evidence row %s %s %r is not in the closed registry' % (e.get('evidence_unit_id'), fld, e.get(fld)))
    for s in B['members']['evidence_package']['manifest'].get('source_attribution', []):
        if 'source_role' in closed and s.get('source_role') not in closed['source_role']:
            f.append('source %s role %r is not in the closed registry' % (s.get('source_id'), s.get('source_role')))
    for cl in B['load']['claims']:
        if 'usage_class' in closed and cl.get('initial_usage_class') not in closed['usage_class']:
            f.append('claim %s initial usage class %r is not in the closed registry' % (cl.get('claim_id'), cl.get('initial_usage_class')))
    # the old vp_* voice labels are evidence only: no active row may carry them as an identity
    if any(re.match(r'^vp_', str(r.get('voice_profile_version_id', ''))) for r in B['load']['voice_profile_versions']):
        f.append('an active voice row carries a predecessor vp_* label instead of its literal Foundation UUID')
    return f


# Showrunner Planning v0.1.3 s23 gate 7. No governing source states a tolerance (history: provenance/history/RUNTIME_BUDGET_FINDING_i2c_r2.md; resolution: provenance/RUNTIME_BUDGET_RESOLUTION.md): tolerance is exactly 0 here.
GOVERNED_RUNTIME_TOLERANCE_SECONDS = 0


def g_runtime_budget(B, f=None):
    """G32: planned block budgets must fit the configured runtime range/tolerance of the CURRENT configuration (Showrunner Planning v0.1.3 s23 gate 7).
    It never reads the Brief runtime_target: no equality between the authored budgets and the target is required."""
    f = [] if f is None else f
    show = current_config(B)['canonical_payload']
    brief = B['members']['showrunner_brief']
    band = show.get('configured_runtime_seconds')
    if not (isinstance(band, dict) and _strict_int(band.get('min')) and _strict_int(band.get('max')) and 0 < band['min'] < band['max']):
        return ['runtime band malformed: cannot evaluate the budget gate']
    total = 0
    for b in brief['program_blocks']:
        t = b.get('target_duration_or_words')
        if not (isinstance(t, dict) and set(t) == {'seconds'} and _strict_int(t['seconds']) and t['seconds'] > 0):
            f.append('block budget malformed for slot %s' % b.get('template_slot_id'))
        else:
            total += t['seconds']
    if f:
        return f
    lo, hi = band['min'] - GOVERNED_RUNTIME_TOLERANCE_SECONDS, band['max'] + GOVERNED_RUNTIME_TOLERANCE_SECONDS
    if not (lo <= total <= hi):
        f.append('RUNTIME BUDGET OUTSIDE THE CONFIGURED BAND (Showrunner Planning v0.1.3 s23 gate 7): the planned block budgets sum to %d s, outside the configured band [%d, %d] s by %d s '
                 '(no governed tolerance exists; tolerance is exactly 0)'
                 % (total, band['min'], band['max'], (total - band['max']) if total > band['max'] else (band['min'] - total)))
    return f


# ====================================================================== G34 (CONFIG-330): show-configuration lineage, ownership and READY/revalidation propagation
OLD_CFG_ID = 'd1250003-0000-4000-8000-000000000001'
OLD_CFG_HASH = '1d4e82bdc40571351f582aa0173ff55cf040f48bef7028fde958bd7b595c5683'
NEW_CFG_HASH = 'd1f022782d543d1b8d9a7fd3d56895b57ca1f2b8381457d84261508e75b36719'


def g_show_config_lineage(B, f=None):
    f = [] if f is None else f
    L = B['load']
    rows = L['show_config_versions']
    shows = {r['show_id'] for r in L['shows']}
    by_id = {r['show_config_version_id']: r for r in rows}
    if len(rows) != 2 or len(by_id) != 2 or sorted(r['version_number'] for r in rows) != [1, 2]:
        f.append('the load must hold exactly show-config versions 1 and 2')
        return f
    v1 = [r for r in rows if r['version_number'] == 1][0]
    v2 = [r for r in rows if r['version_number'] == 2][0]
    if v1['parent_version_id'] is not None or v2['parent_version_id'] != v1['show_config_version_id']:
        f.append('configuration parent chain is not version 2 -> version 1 -> none')
    if v1['show_id'] != v2['show_id'] or v1['show_id'] not in shows:
        f.append('configuration versions belong to different or unknown shows')
    if not (v1['created_at'] < v2['created_at']):
        f.append('configuration version 2 is not created after its parent')
    seen, cur = set(), v2
    while cur is not None:
        if cur['show_config_version_id'] in seen:
            f.append('configuration parent chain has a cycle')
            break
        seen.add(cur['show_config_version_id'])
        cur = by_id.get(cur['parent_version_id'])
    p1, p2 = v1['canonical_payload'], v2['canonical_payload']
    diff_keys = sorted(k for k in set(p1) | set(p2) if p1.get(k) != p2.get(k))
    band1, band2 = p1.get('configured_runtime_seconds'), p2.get('configured_runtime_seconds')
    if diff_keys != ['configured_runtime_seconds'] or set(p1) != set(p2) or not isinstance(band1, dict) or not isinstance(band2, dict) or set(band1) != set(band2) or \
            sorted(k for k in band1 if band1[k] != band2[k]) != ['max'] or (band1.get('max'), band2.get('max')) != (300, 330):
        f.append('payload differs from the parent beyond configured_runtime_seconds.max (300 -> 330)')
    for r in (v1, v2):
        if DH('show-config-v1', r['canonical_payload']) != r['config_hash']:
            f.append('configuration hash does not recompute: version %s' % r['version_number'])
        if r['pre_publish_review_required'] != r['canonical_payload'].get('pre_publish_review_required'):
            f.append('configuration row/payload review flag differ: version %s' % r['version_number'])
    if v1['config_hash'] != OLD_CFG_HASH or v2['config_hash'] != NEW_CFG_HASH or v1['show_config_version_id'] != OLD_CFG_ID:
        f.append('configuration identities/hashes differ from the accepted bindings')
    if v1['config_hash'] == v2['config_hash'] or (v1['show_id'], v1['version_number']) == (v2['show_id'], v2['version_number']):
        f.append('configuration DDL uniqueness (show, version) / (show, hash) violated')
    # the old row is immutable history: equal to the shipped history member and to the I2A source payload; bound by no attempt; named only as the parent
    if B['members'].get('config_show_version_v1_history') != v1:
        f.append('version 1 history member differs from the loaded row')
    if B['src_v2']['show']['show_config_version']['canonical_payload'] != p1:
        f.append('version 1 payload differs from the preserved I2A show configuration')
    holders = sorted((fam, r_[PK[fam]]) for fam, rs in L.items() for r_ in rs if v1['show_config_version_id'] in [x for x in r_.values() if isinstance(x, str)] and fam != 'show_config_versions')
    if holders:
        f.append('the old configuration id is held by loaded rows: %s' % holders[:3])
    # ownership: every attempt is bound to the NEW version only; runs stay unbound (inherited representation) and are fresh
    atts, runs = L['program_run_attempts'], L['program_runs']
    if len(atts) != 2 or {a['show_config_version_id'] for a in atts} != {v2['show_config_version_id']}:
        f.append('every loaded attempt must be bound to configuration version 2 and no other')
    if any(r_['show_config_version_id'] is not None for r_ in runs):
        f.append('a loaded run carries a configuration binding (the first attempt establishes it)')
    prop = {p['proposed_id'] for p in B['frozen_table']['proposals']}
    old_run_att = {r_[PK[fm]] for fm in ('program_runs', 'program_run_attempts') for r_ in B['src_tables'][fm]}
    for r_ in runs:
        if r_['program_run_id'] not in prop or r_['program_run_id'] in old_run_att:
            f.append('a loaded run is not a fresh identity from the frozen table: %s' % r_['program_run_id'])
    for a in atts:
        if a['attempt_id'] not in prop or a['attempt_id'] in old_run_att:
            f.append('a loaded attempt is not a fresh identity from the frozen table: %s' % a['attempt_id'])
    if {a['program_run_id'] for a in atts} != {r_['program_run_id'] for r_ in runs} or {r_['purpose'] for r_ in runs} != {'evaluation', 'production'}:
        f.append('runs/attempts do not form the evaluation + production-purpose pair')
    # nothing from the accepted v2 attempt/run set is co-loaded (archived history only)
    v2ids = {r_['v2_id'] for r_ in B['archive283'] if r_['family'] in ('program_runs', 'program_run_attempts', 'gate_results', 'provider_calls', 'model_runs')}
    loaded = {r_[PK[fm]] for fm, rs in L.items() for r_ in rs}
    if v2ids & loaded:
        f.append('accepted v2 attempt-owned rows are co-loaded with the successor')
    # READY / revalidation propagation
    R = source_chain(B)
    stg = stage_projections(B, R)[0]
    ready = stg['ready_candidate'][1]
    ra = B['members']['ready_expectations']
    if ready['show_config_version_hash'] != v2['config_hash'] or ready['show_config_version_hash'] == v1['config_hash']:
        f.append('READY candidate is not bound to the new show-config hash')
    if ra['show_config_version_id'] != v2['show_config_version_id'] or ra['program_run_id'] != ready['program_run_id'] or ra['attempt_id'] != ready['attempt_id']:
        f.append('READY expectations are not bound to the new configuration and the fresh run/attempt')
    if ready['attempt_id'] not in {a['attempt_id'] for a in atts} or ready['program_run_id'] not in {r_['program_run_id'] for r_ in runs}:
        f.append('READY candidate names a run/attempt that is not loaded')
    prod = [r_ for r_ in runs if r_['purpose'] == 'production']
    if len(prod) != 1 or ready['program_run_id'] != prod[0]['program_run_id']:
        f.append('READY candidate is not bound to the production-purpose run')
    rv = B['members']['revalidation_result__successor']
    if rv['ready_candidate_fingerprint'] != DH('ready-candidate-v1', ready) or rv['ready_candidate_fingerprint'] == '5179590fc930db43078ca00485dcd05d619761f48c4e1bf281786b7a22344267':
        f.append('revalidation result does not carry the recomputed new READY fingerprint')
    # isolated repair children inherit the parent configuration and run (never given another)
    sc = B['members']['scenarios']['scenarios']
    prod_att = [a for a in atts if a['program_run_id'] == ready['program_run_id']][0]
    for name in ('performance_repair', 'programming_repair'):
        ch = sc[name]['rows']['program_run_attempts'][0]
        if ch['show_config_version_id'] != v2['show_config_version_id'] or ch['program_run_id'] != prod_att['program_run_id'] or ch['parent_attempt_id'] != prod_att['attempt_id']:
            f.append('isolated repair child %s does not inherit the parent configuration/run/attempt' % name)
    # no rejected-v3 identity or hash is current anywhere in the load or the members
    deny = B['denylist'] or {}
    text = json.dumps(L) + json.dumps(B['members'])
    bad = sorted(u for u in deny.get('rejected_v3_ids', []) if u in text) + sorted(h_ for h_ in deny.get('rejected_v3_hashes', []) if h_ in text)
    if bad:
        f.append('a rejected-v3 identity/hash is presented as current: %s' % bad[:3])
    if len(deny.get('rejected_v3_ids', [])) < 100:
        f.append('the rejected-v3 denylist is missing or incomplete')
    # the Brief show_version label equals the configuration label (a second edit is not authorised)
    if B['members']['showrunner_brief'].get('show_version') != p2.get('show_version'):
        f.append('Brief show_version differs from the configuration payload label')
    return f


# ====================================================================== GROUP REGISTRY, STRICT SELECTORS, RUNNERS
GROUPS = [('G22_pack_integrity', g_pack_integrity), ('G23_reference_resolution', g_reference_resolution),
          ('G24_policy_authority_binding', g_policy_authority),
          ('G02_frozen_record_and_cycles', g_frozen_record),
          ('G03_plan_counts_fk', g_plan_counts_fk), ('G04_knowledge_hashes', g_knowledge), ('G05_package_scope', g_package_scope),
          ('G06_brief_writer_scripts', g_brief_writer_scripts), ('G07_prompts_models', g_prompts_models),
          ('G08_correction_direction', g_correction), ('G09_audit', g_audit), ('G10_render_contexts_tts', g_render),
          ('G11_ledger_takes', g_ledger), ('G12_audio_assembly_mapping', g_audio_assembly), ('G13_gates_ready', g_gates_ready),
          ('G14_obligations_nulls', g_obligations), ('G15_archive_historical', g_archive_hist),
          ('G16_scenarios_gap', g_scenarios_gaps), ('G17_member_copy_equality', g_copies), ('G18_artifact_consumers', g_artifact_consumers),
          ('G19_identity_totals_provenance', g_identity_provenance), ('G20_inherited_vectors', g_inherited_vectors),
          ('G21_repair_provenance_frozen_deps', g_repair_provenance),
          ('G25_complete_manifest_acceptance', g_manifest_acceptance), ('G26_manifest_hash_vectors', g_manifest_hash_vectors),
          ('G27_tts_request_vectors', g_tts_request_vectors), ('G28_claim_event_vectors', g_claim_event_vectors),
          ('G29_support_window_continuity', g_support_window_continuity), ('G30_exact_timing', g_exact_timing),
          ('G31_programming_configuration', g_programming_configuration), ('G32_runtime_budget', g_runtime_budget),
          ('G34_show_config_lineage', g_show_config_lineage)]
GROUP_NAMES = [g for g, _ in GROUPS]
ENVIRONMENT_G01 = {'status': 'NOT_APPLICABLE_IN_PACKAGE',
                   'note': 'G01 (I2B VM source/Git integrity) reads the live VM, workspaces and Git metadata. It is checkpoint/environment verification '
                           '(tools/verify_environment.py in the I2C area) and is deliberately not part of a package validator. It is reported here, not '
                           'counted as a pass, and its absence never turns a package result into a pass.'}


def run_checks(B, only=None):
    res = {}
    B['_log'] = {}
    for name, fn in GROUPS:
        if only and name not in only:
            continue
        acc = []
        try:
            res[name] = fn(B, acc)
        except Exception as e:  # a corruption may break structure; keep explicit messages found before the break
            res[name] = acc + ['EXCEPTION %s: %s' % (type(e).__name__, e)]
    return res


# ---------------------------------------------------------------- strict selectors (resolve uniquely BEFORE any mutation)
def S_row(B, table, **where):
    if table not in B['load']:
        raise SelectorError('no such table %r' % table)
    hits = [r for r in B['load'][table] if all(r.get(k, object()) == v for k, v in where.items())]
    if len(hits) != 1:
        raise SelectorError('row selector %s%r matched %d rows (need exactly 1)' % (table, where, len(hits)))
    return hits[0]


def S_at(B, table, index, pk_value):
    """positional selector that also DECLARES the literal primary key it must land on"""
    rows = B['load'].get(table)
    if rows is None or not (-len(rows) <= index < len(rows)):
        raise SelectorError('positional selector %s[%s] is out of range' % (table, index))
    got = rows[index].get(PK[table])
    if got != pk_value:
        raise SelectorError('positional selector %s[%s] landed on %r, declared %r' % (table, index, got, pk_value))
    return rows[index]


def S_art(B, artifact_id):
    return S_row(B, 'artifacts', artifact_id=artifact_id)


def S_member(B, name):
    if name not in B['members']:
        raise SelectorError('no member %r' % name)
    return B['members'][name]


def S_block(B, seq):
    hits = [b for b in B['members']['render_manifest__successor']['render_blocks'] if b['sequence'] == seq]
    if len(hits) != 1:
        raise SelectorError('render block selector sequence=%s matched %d' % (seq, len(hits)))
    return hits[0]


def S_ctx(B, seq):
    hits = [c for c in B['proj']['render_context_projections']['contexts'] if c['render_block_sequence'] == seq]
    if len(hits) != 1:
        raise SelectorError('context selector sequence=%s matched %d' % (seq, len(hits)))
    return hits[0]


def S_turn(B, anchor, source='script_pass2'):
    hits = [t for t in B['src'][source]['turns'] if t['semantic_turn_id'] == anchor]
    if len(hits) != 1:
        raise SelectorError('turn selector %s matched %d' % (anchor, len(hits)))
    return hits[0]


def S_path(obj, pointer):
    return ptr_resolve(obj, pointer)[2]


class Sel:
    """declarative selector constructors; resolved by the harness before the mutation callable runs"""
    row = staticmethod(lambda table, **w: ('row', table, w))
    at = staticmethod(lambda table, i, pk: ('at', table, i, pk))
    art = staticmethod(lambda aid: ('art', aid))
    member = staticmethod(lambda n: ('member', n))
    block = staticmethod(lambda s: ('block', s))
    ctx = staticmethod(lambda s: ('ctx', s))
    turn = staticmethod(lambda a, src='script_pass2': ('turn', a, src))


def resolve_selectors(B, decl):
    S = {}
    for name, d in (decl or {}).items():
        kind = d[0]
        if kind == 'row':
            S[name] = S_row(B, d[1], **d[2])
        elif kind == 'at':
            S[name] = S_at(B, d[1], d[2], d[3])
        elif kind == 'art':
            S[name] = S_art(B, d[1])
        elif kind == 'member':
            S[name] = S_member(B, d[1])
        elif kind == 'block':
            S[name] = S_block(B, d[1])
        elif kind == 'ctx':
            S[name] = S_ctx(B, d[1])
        elif kind == 'turn':
            S[name] = S_turn(B, d[1], d[2])
        else:
            raise SelectorError('unknown selector kind %r' % kind)
    return S


# ---------------------------------------------------------------- case runners
def load_cases_module(pack):
    src = pack.data.get(PATH['cases_py'])
    if src is None:
        raise PackUnusable(['conformance_cases.py is not a member of the pack'])
    mod = types.ModuleType('conformance_cases')
    mod.__dict__['V'] = sys.modules[__name__]      # the cases run against THIS validator module
    exec(compile(src, PATH['cases_py'], 'exec'), mod.__dict__)
    return mod


def run_domain_cases(B0, M, V):
    out = []
    for c in M.CASES:
        B = copy.deepcopy(B0)
        base = {'case': c['id'], 'description': c['description'], 'group': c['group'], 'category': c.get('category', 'added_domain'),
                'kind': c['kind']}
        try:
            S = resolve_selectors(B, c.get('selectors'))
        except SelectorError as e:
            out.append(dict(base, expected_group_failed=False, observed='SELECTOR_FAILURE', failed_groups=[], message=str(e)))
            continue
        try:
            c['fn'](B, V, S)
        except SelectorError as e:
            out.append(dict(base, expected_group_failed=False, observed='SELECTOR_FAILURE', failed_groups=[], message=str(e)))
            continue
        except Exception as e:  # a broken mutation is a harness error, never a pass
            out.append(dict(base, expected_group_failed=False, observed='HARNESS_ERROR', failed_groups=[], message='%s: %s' % (type(e).__name__, e)))
            continue
        groups = set(c['group'].split('+'))
        res = run_checks(B, only=groups)
        fails = [m for g in groups for m in res.get(g, [])]
        if c['kind'] == 'stable':
            ok = not fails
            out.append(dict(base, expected='ACCEPTED (invariant holds)', observed='ACCEPTED' if ok else 'REJECTED', expected_group_failed=ok,
                            failed_groups=[] if ok else sorted(groups), message=(fails or [''])[0][:240]))
            continue
        hit = [m for m in fails if c['needle'].lower() in m.lower()]
        out.append(dict(base, expected='REJECTED by %s (message contains %r)' % (c['group'], c['needle']),
                        observed='REJECTED' if fails else 'ACCEPTED', expected_group_failed=bool(hit),
                        failed_groups=sorted(groups) if fails else [], message=(hit or fails or ['<no failure>'])[0][:240]))
    return out


def run_g03_probes(B0, M, V):
    out = []
    needle = 'retained row changed beyond placeholder fill'
    for p in M.G03_PROBES:
        B = copy.deepcopy(B0)
        try:
            p['fn'](B, V)
        except Exception as e:
            out.append({'probe': p['name'], 'id': p['id'], 'as_expected': False, 'observed': 'HARNESS_ERROR', 'message': '%s: %s' % (type(e).__name__, e)})
            continue
        msgs = V.g_plan_counts_fk(B, [])
        hit = [m for m in msgs if needle in m]
        out.append({'probe': p['name'], 'id': p['id'], 'expected': 'REJECTED by G03' if p['reject'] else 'ACCEPTED by G03', 'observed': 'REJECTED' if hit else 'ACCEPTED',
                    'as_expected': bool(hit) == p['reject'], 'message': (hit or ['<no G03 finding>'])[0][:200]})
    return out


def run_selector_checks(B0, M, V):
    """deliberately invalid selectors MUST fail at selector resolution, before any mutation. A selector that unexpectedly resolves is an escape."""
    out = []
    for s in M.SELECTOR_CHECKS:
        B = copy.deepcopy(B0)
        snapshot = cj(B['load']) + cj(B['members'])
        try:
            if s['kind'] == 'declared':
                resolve_selectors(B, s['selectors'])
            elif s['kind'] == 'pointer':
                t = copy.deepcopy(s['target'](B))
                apply_mutation(t, s['mutation'](t) if callable(s['mutation']) else s['mutation'])
            else:
                raise RuntimeError('unknown selector check kind')
            observed = 'RESOLVED'
        except SelectorError as e:
            observed = 'SELECTOR_FAILURE'
            msg = str(e)
        except Exception as e:
            observed = 'HARNESS_ERROR'
            msg = '%s: %s' % (type(e).__name__, e)
        else:
            msg = ''
        untouched = snapshot == cj(B['load']) + cj(B['members'])
        out.append({'check': s['id'], 'description': s['description'], 'expected': s.get('expect', 'SELECTOR_FAILURE'), 'observed': observed,
                    'as_expected': observed == s.get('expect', 'SELECTOR_FAILURE') and untouched, 'nothing_mutated': untouched, 'message': msg[:200]})
    return out


# ---------------------------------------------------------------- package (ZIP) negative harness
def make_zip(entries):
    """entries: list of dicts {name, data, mode=0o644, create_system=3, attr=None, flag=0}; arbitrary order / duplicates allowed"""
    bio = io.BytesIO()
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        with zipfile.ZipFile(bio, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for e in entries:
                zi = zipfile.ZipInfo(e['name'], (1980, 1, 1, 0, 0, 0))
                zi.create_system = e.get('create_system', 3)
                zi.external_attr = e['attr'] if e.get('attr') is not None else ((stat.S_IFREG | e.get('mode', 0o644)) << 16)
                zi.compress_type = zipfile.ZIP_DEFLATED
                z.writestr(zi, e['data'])
    raw = bio.getvalue()
    flagged = {e['name']: e['flag'] for e in entries if e.get('flag')}
    if flagged:                      # writestr resets flag bits, so patch the local header and the central directory entry in place
        b = bytearray(raw)
        zz = zipfile.ZipFile(io.BytesIO(raw))
        for n, fl in flagged.items():
            ho = zz.getinfo(n).header_offset
            b[ho + 6] |= fl & 0xff
            pos = 0
            while True:
                pos = raw.find(b'PK\x01\x02', pos)
                if pos < 0:
                    break
                nl = int.from_bytes(raw[pos + 28:pos + 30], 'little')
                if raw[pos + 46:pos + 46 + nl] == n.encode():
                    b[pos + 8] |= fl & 0xff
                pos += 4
        raw = bytes(b)
    return raw


def entries_of(pack):
    return [{'name': n, 'data': pack.data[n], 'mode': pack.modes.get(n) or 0o644} for n in pack.order]


def refresh_inventory(entries):
    """consistent attacker: rewrite PACK_MEMBERS.json so its bytes/sha256 describe the (mutated) members exactly"""
    by = {e['name']: e for e in entries}
    pm = json.loads(by[PATH['pack_members']]['data'].decode('utf-8'))
    seen = set()
    for m in pm['members']:
        e = by.get(m['path'])
        if e is not None and m['path'] != PATH['pack_members']:
            m['bytes'], m['sha256'] = len(e['data']), H(e['data'])
            seen.add(m['path'])
    by[PATH['pack_members']]['data'] = (json.dumps(pm, indent=2, sort_keys=True, ensure_ascii=False) + '\n').encode('utf-8')
    return entries


def minimal_bundle(pack, expect):
    """just enough of a bundle for g_pack_integrity when the full loader cannot run (corrupt package)"""
    def jl(n):
        try:
            return json.loads(pack.data[n].decode('utf-8'))
        except Exception:
            return None
    lp = None
    try:
        lp = json.loads(pack.data[PATH['load']].decode('utf-8')).get('profile')
    except Exception:
        pass
    return {'pack': pack, 'expect': expect or {}, 'notes': {}, 'pack_members': jl(PATH['pack_members']), 'source_provenance': jl(PATH['source_provenance']), 'load_profile': lp}


def run_package_cases(B0, M, V):
    out = []
    base = B0['pack']
    for c in M.PACKAGE_CASES:
        rec = {'case': c['id'], 'description': c['description'], 'category': 'package_integrity', 'kind': 'reject'}
        try:
            entries = copy.deepcopy(entries_of(base))
            raw = c['build'](entries, V, base)       # returns ZIP bytes
            expect = dict(B0.get('expect') or {})
            if c.get('expect_override'):
                expect.update(c['expect_override'])
            p = open_zip_bytes(raw, 'mutated:' + c['id'])
        except Exception as e:
            out.append(dict(rec, observed='HARNESS_ERROR', expected_group_failed=False, message='%s: %s' % (type(e).__name__, e)))
            continue
        msgs = ['structure: ' + x for x in p.problems]
        stage = 'open'
        try:
            B = load_bundle(p, expect)
            stage = 'groups'
            res = run_checks(B)
            for g, fl in res.items():
                msgs += ['%s: %s' % (g, x) for x in fl]
        except PackUnusable as e:
            stage = 'loader'
            msgs += ['loader: ' + r for r in e.reasons]
            try:
                msgs += ['G22_pack_integrity: ' + x for x in g_pack_integrity(minimal_bundle(p, expect), [])]
            except Exception as e2:
                msgs.append('integrity check failed on the minimal bundle: %s: %s' % (type(e2).__name__, e2))
        except Exception as e:
            msgs.append('EXCEPTION %s: %s' % (type(e).__name__, e))
        hit = [m for m in msgs if c['needle'].lower() in m.lower()]
        out.append(dict(rec, expected='REJECTED (message contains %r)' % c['needle'], observed='REJECTED' if msgs else 'ACCEPTED',
                        stage=stage, expected_group_failed=bool(hit), message=(hit or msgs or ['<no failure>'])[0][:240]))
    return out


# ---------------------------------------------------------------- index / coverage, recorded evaluations
def verify_index(B, executed):
    """every deterministic obligation must name executed, as-expected cases/groups; non-deterministic classes are listed, never counted"""
    idx_ = B['index'] or {}
    f = []
    det = 0
    by_kind = collections.Counter()
    for o in idx_.get('obligations', []):
        by_kind[o['kind']] += 1
        if o['kind'] == 'unresolved_base_gate':
            for g in o.get('groups', []):
                if g not in UNRESOLVED_BASE_GATES:
                    f.append('obligation %s names %s which is not a declared unresolved base gate' % (o['id'], g))
                elif executed['groups'].get(g) is not False:
                    f.append('obligation %s says %s is unresolved but it did not report its failure (resolved? update the index with the governing citation)' % (o['id'], g))
            if not o.get('reason'):
                f.append('unresolved obligation %s lacks a reason' % o['id'])
            continue
        if o['kind'] != 'deterministic':
            if not o.get('reason'):
                f.append('non-deterministic obligation %s lacks a reason' % o['id'])
            continue
        det += 1
        if not o.get('cases') and not o.get('groups') and not o.get('vector_classes'):
            f.append('deterministic obligation %s names no executable proof' % o['id'])
        for cid in o.get('cases', []):
            if executed['cases'].get(cid) is not True:
                f.append('obligation %s: case %s was not executed as expected' % (o['id'], cid))
        for g in o.get('groups', []):
            if executed['groups'].get(g) is not True:
                f.append('obligation %s: group %s did not pass' % (o['id'], g))
        for vc in o.get('vector_classes', []):
            if executed['vector_classes'].get(vc, 0) < 1:
                f.append('obligation %s: vector class %s was not executed' % (o['id'], vc))
    nv = idx_.get('predecessor_negative_vectors', [])
    if len(nv) != 26 or sorted(x['id'] for x in nv) != ['NV%02d' % i for i in range(1, 27)]:
        f.append('conformance_index does not classify NV01..NV26')
    for x in nv:
        by_kind['nv:' + x['class']] += 1
        if x['class'] == 'deterministic':
            for cid in x.get('cases', []):
                if executed['cases'].get(cid) is not True:
                    f.append('%s: case %s was not executed as expected' % (x['id'], cid))
            for g in x.get('groups', []):
                if executed['groups'].get(g) is not True:
                    f.append('%s: group %s did not pass' % (x['id'], g))
            if not x.get('cases') and not x.get('groups'):
                f.append('%s is classified deterministic but names no case or group' % x['id'])
        elif x['class'] not in ('recorded_model_eval', 'runtime_deferred', 'adapter_deferred'):
            f.append('%s has an unknown class %r' % (x['id'], x['class']))
        elif x.get('cases'):
            f.append('%s is %s but names cases (a non-deterministic class must not be counted as a pass)' % (x['id'], x['class']))
    return f, dict(by_kind), det


def recorded_evaluations(B):
    rep = B['audit_report'] or {}
    nv = [x for x in (B['index'] or {}).get('predecessor_negative_vectors', []) if x['class'] == 'recorded_model_eval']
    return {'counted_as_deterministic_passes': 0,
            'items': [{'id': 'fixture_audit_report', 'member': PATH['audit_report'], 'kind': 'recorded synthetic structural/narrative audit',
                       'method_recorded': bool(rep.get('method')), 'limitations_recorded': bool(rep.get('limitations')),
                       'per_intent_reviews': len(rep.get('per_intent', [])), 'human_override': rep.get('human_override'),
                       'status': 'RECORDED_NOT_EXECUTED_AS_CHECK'}] +
                     [{'id': x['id'], 'class': 'recorded_model_eval', 'status': 'RECORDED_NOT_EXECUTED_AS_CHECK'} for x in nv]}


# ---------------------------------------------------------------- main
def _py_env():
    """runtime facts without spawning any process (platform.platform() would run `uname`)"""
    import platform
    try:
        import zlib
        zv = zlib.ZLIB_VERSION
    except Exception:
        zv = None
    return {'python': sys.version.split()[0], 'implementation': platform.python_implementation(), 'sys_platform': sys.platform, 'zlib': zv}


def main(argv=None):
    ap = argparse.ArgumentParser(description='Fixture v0.4.5 candidate - portable independent final validator')
    ap.add_argument('pack', nargs='?', help='the pack ZIP to validate (read in place, never extracted)')
    ap.add_argument('--dir', default=None, help='an unpacked copy of the pack (never repaired or rewritten)')
    ap.add_argument('--self-test', action='store_true')
    ap.add_argument('--json', default=None)
    ap.add_argument('--expect-zip-sha256', default=None)
    ap.add_argument('--expect-pack-members-sha256', default=None)
    a = ap.parse_args(argv)
    if bool(a.pack) == bool(a.dir):
        ap.error('give exactly one of PACK.zip or --dir FOLDER')
    expect = {}
    if a.expect_zip_sha256:
        expect['zip_sha256'] = a.expect_zip_sha256.lower()
    if a.expect_pack_members_sha256:
        expect['pack_members_sha256'] = a.expect_pack_members_sha256.lower()
    pack = open_zip(a.pack) if a.pack else open_dir(a.dir)
    out = {'validator': VALIDATOR_VERSION, 'runtime': _py_env(), 'pack': {'kind': pack.kind, 'label': os.path.basename(a.pack or a.dir),
                                                                          'members': len(pack.data), 'zip_sha256': pack.zip_sha256},
           'environment': {'G01_source_integrity': ENVIRONMENT_G01}}
    if pack.kind == 'dir':
        out['pack']['observed_frozen_record_mode_on_disk'] = None if pack.modes.get(PATH['record']) is None else '%04o' % pack.modes[PATH['record']]
        out['pack']['mode_note'] = 'unpacked copy: on-disk modes are informational (extraction tools may make files writable); archived mode evidence is the inventory value; bytes are always hash-checked'
    ok = True
    try:
        B = load_bundle(pack, expect)
    except PackUnusable as e:
        print('PACK UNUSABLE:')
        for r in e.reasons:
            print('  ' + r)
        for r in pack.problems:
            print('  structure: ' + r)
        out['status'] = 'FAIL'
        out['pack_unusable'] = e.reasons + pack.problems
        if a.json:
            with open(a.json, 'w', encoding='utf-8') as fh:
                json.dump(out, fh, indent=2, sort_keys=True, ensure_ascii=False)
                fh.write('\n')
        print('VALIDATOR STATUS: FAIL')
        return 1
    res = run_checks(B)
    unresolved = sorted(g for g, v in res.items() if v and g in UNRESOLVED_BASE_GATES)
    real_fail = sorted(g for g, v in res.items() if v and g not in UNRESOLVED_BASE_GATES)
    out['positive'] = {k: {'status': ('PASS' if not v else ('UNRESOLVED_BASE_GATE' if k in UNRESOLVED_BASE_GATES else 'FAIL')), 'failures': v} for k, v in res.items()}
    out['conformance_verdict'] = {'verdict': 'PASS' if not (unresolved or real_fail) else ('FAIL' if real_fail else 'NOT_PASSING_UNRESOLVED_BASE_GATE'),
                                  'unresolved_base_gates': unresolved, 'failed_groups': real_fail,
                                  'note': 'no unresolved base gate is declared in this candidate (the inherited runtime-budget gate is resolved by the CONFIG-330 configuration correction); every group failure is an ordinary failure'}
    ok = not (unresolved or real_fail)
    out['vector_outcomes_positive'] = B.get('_log', {})
    out['notes'] = {k: v for k, v in B['notes'].items()}
    print('POSITIVE CHECK GROUPS: %d/%d pass; %d unresolved base gate(s); %d failed   (G01 environment check: %s)' % (
        sum(1 for v in res.values() if not v), len(res), len(unresolved), len(real_fail), ENVIRONMENT_G01['status']))
    for k, v in res.items():
        tag = 'PASS' if not v else ('UNRESOLVED-BASE' if k in UNRESOLVED_BASE_GATES else 'FAIL')
        print('  %s %s' % (tag, k), ('' if not v else '\n      ' + '\n      '.join(v[:6])))
    anchors = B['notes'].get('anchors', {})
    print('  external trust anchors supplied: zip=%s pack_members=%s' % (anchors.get('zip_sha256_supplied'), anchors.get('pack_members_sha256_supplied')))
    if a.self_test:
        V = sys.modules[__name__]
        # the case module comes from the pack itself, verified against the inventory before it is executed
        inv = _members(B)
        if inv.get(PATH['cases_py'], {}).get('sha256') != H(pack.data[PATH['cases_py']]):
            print('conformance_cases.py does not match the inventory; refusing to execute it')
            out['status'] = 'FAIL'
            return 1
        M = load_cases_module(pack)
        dom = run_domain_cases(B, M, V)
        probes = run_g03_probes(B, M, V)
        sel = run_selector_checks(B, M, V)
        pkg = run_package_cases(B, M, V)
        out['cases'] = {'domain': dom, 'g03_probes': probes, 'selector_checks': sel, 'package_negatives': pkg}
        bad_dom = [n for n in dom if not n['expected_group_failed']]
        print('DOMAIN CASES: %d run, %d behaved as expected, %d unexpected' % (len(dom), len(dom) - len(bad_dom), len(bad_dom)))
        for n in bad_dom:
            print('  UNEXPECTED:', n['case'], n['observed'], n.get('message'))
        print('G03 EXCEPTION PROBES: %d/%d as expected' % (sum(1 for p in probes if p['as_expected']), len(probes)))
        inv_sel = [s for s in sel if s['expected'] == 'SELECTOR_FAILURE']
        print('SELECTOR CHECKS: %d/%d deliberately invalid selectors failed at selector resolution before any mutation; %d/%d valid control(s) resolved' % (
            sum(1 for s in inv_sel if s['as_expected']), len(inv_sel), sum(1 for s in sel if s['expected'] == 'RESOLVED' and s['as_expected']), len(sel) - len(inv_sel)))
        bad_pkg = [n for n in pkg if not n['expected_group_failed']]
        print('PACKAGE INTEGRITY NEGATIVES: %d run, %d rejected as expected, %d escaped' % (len(pkg), len(pkg) - len(bad_pkg), len(bad_pkg)))
        for n in bad_pkg:
            print('  ESCAPED/UNEXPECTED:', n['case'], n['observed'], n.get('stage'), n.get('message'))
        executed = {'cases': dict({n['case']: bool(n['expected_group_failed']) for n in dom + pkg}, **{s['check']: bool(s['as_expected']) for s in sel},
                                  **{p['id']: bool(p['as_expected']) for p in probes}), 'groups': {k: not v for k, v in res.items()},
                    'vector_classes': collections.Counter(r['class'] for lg in B.get('_log', {}).values() for r in lg if r['outcome'] == 'as_expected')}
        idx_f, idx_kinds, det = verify_index(B, executed)
        out['coverage'] = {'failures': idx_f, 'obligation_kinds': idx_kinds, 'deterministic_obligations': det}
        print('COVERAGE INDEX: %s (%s)' % ('PASS' if not idx_f else 'FAIL: ' + '; '.join(idx_f[:3]), idx_kinds))
        out['recorded_evaluations'] = recorded_evaluations(B)
        vec = collections.Counter()
        for g, lg in B.get('_log', {}).items():
            for r in lg:
                vec[(g, r['class'], r['outcome'])] += 1
        out['vector_outcome_counts'] = {'%s/%s/%s' % k: v for k, v in sorted(vec.items())}
        unexpected_vec = [r for lg in B.get('_log', {}).values() for r in lg if r['outcome'] != 'as_expected']
        by_cat = collections.Counter(n.get('category', 'added_domain') for n in dom)
        out['counts'] = {
            'positive_groups': len(res), 'positive_groups_passed': sum(1 for v in res.values() if not v), 'positive_groups_unresolved_base_gate': len(unresolved),
            'positive_groups_failed': len(real_fail),
            'domain_cases': len(dom), 'domain_cases_by_category': dict(by_cat),
            'domain_rejections_expected': sum(1 for n in dom if n['kind'] == 'reject'), 'domain_stability_cases': sum(1 for n in dom if n['kind'] == 'stable'),
            'harness_errors': sum(1 for n in dom + pkg if n['observed'] == 'HARNESS_ERROR'),
            'selector_failures_in_cases': sum(1 for n in dom if n['observed'] == 'SELECTOR_FAILURE'),
            'g03_probes': len(probes), 'selector_checks': len(sel), 'package_negatives': len(pkg),
            'vector_outcomes_executed': sum(len(lg) for lg in B.get('_log', {}).values()), 'vector_outcomes_unexpected': len(unexpected_vec),
            'skipped': 0, 'recorded_evaluations_counted_as_passes': 0}
        harness_ok = not bad_dom and not bad_pkg and all(p['as_expected'] for p in probes) and all(s['as_expected'] for s in sel) and not idx_f and not unexpected_vec
        out['self_test_harness'] = {'all_declared_outcomes_observed': harness_ok, 'harness_errors': out['counts']['harness_errors'], 'unexpected_vector_outcomes': len(unexpected_vec),
                                    'note': 'negative-test outcomes and harness status are reported separately from the base conformance verdict'}
        print('SELF-TEST HARNESS: %s (negative outcomes and harness status are independent of the base verdict)' % ('ALL DECLARED OUTCOMES OBSERVED' if harness_ok else 'UNEXPECTED OUTCOMES'))
        ok = ok and harness_ok
    cv = out['conformance_verdict']['verdict']
    out['status'] = 'PASS' if ok else ('NOT_PASSING' if cv == 'NOT_PASSING_UNRESOLVED_BASE_GATE' and out.get('self_test_harness', {'all_declared_outcomes_observed': True})['all_declared_outcomes_observed'] else 'FAIL')
    if a.json:
        with open(a.json, 'w', encoding='utf-8') as fh:
            json.dump(out, fh, indent=2, sort_keys=True, ensure_ascii=False)
            fh.write('\n')
    print('CONFORMANCE VERDICT:', cv, ('- unresolved base gate(s): %s' % ', '.join(out['conformance_verdict']['unresolved_base_gates'])) if out['conformance_verdict']['unresolved_base_gates'] else '')
    print('VALIDATOR STATUS:', out['status'])
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
