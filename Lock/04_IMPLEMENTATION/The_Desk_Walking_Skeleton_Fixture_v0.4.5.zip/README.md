# The Desk - Walking-Skeleton Fixture v0.4.5 (CANDIDATE, CONFIG-330 corrected successor)

**Status: I2C CANDIDATE - inactive, not an installed `/Lock` release.** A synthetic offline fixture and its conformance package.
It does not activate v1.2.5, does not change the active FINAL LOCK v1.2.4 selection (which still names Fixture v0.4.4), does not
implement Migration 002 or any SQL/runtime behavior, and proves nothing about live-provider behavior or audible audio fidelity.
No human approval and no human semantic override is represented anywhere in it. Supervisory acceptance is not claimed.

The SHA-256 of this ZIP and of `PACK_MEMBERS.json` are published **outside** the pack (external sidecar / checkpoint / report).
Nothing in the pack carries either hash, and this README lists no member hashes, so there is no checksum cycle.

## What this candidate corrects

The accepted I2C v2 candidate could not pass its runtime-budget gate: nine authored block budgets sum to 330 s but the fixture show configuration band was [60, 300].
This candidate appends a new immutable `show_config_versions` version (version 2, parent = version 1) changing only `configured_runtime_seconds.max` 300 -> 330. The
launch template (quiet 8 / standard 10 / big 12 minutes) and the fixture `runtime_target` (240 s, `evaluation_fixture`) are unchanged; no equality between the budgets
and the target is required. Attempts bind the configuration immutably, so the corrected load is a **standalone** successor: 274 rows are re-keyed by the frozen identity table
(two fresh root runs, two fresh attempts, fresh program blocks and everything that owns or names them) and the governed hashes that contain a fresh identity are recomputed.
Script words, participants, anchors, budgets, intent values, TTS preimages, render-context digests, WAV bytes and the assembly recipe are unchanged. See
`provenance/RUNTIME_BUDGET_RESOLUTION.md`.

## Run the validator (standard library only; developed and exercised on Python 3.14.2)

```
python3 validate_fixture.py The_Desk_Walking_Skeleton_Fixture_v0.4.5.zip               # positive groups; the ZIP is read in place
python3 validate_fixture.py The_Desk_Walking_Skeleton_Fixture_v0.4.5.zip --self-test   # + every vector, domain case, selector check and package-corruption case
python3 validate_fixture.py --dir <unpacked folder> [--self-test]                      # an unpacked copy (never repaired or rewritten)
    --expect-zip-sha256 HEX  --expect-pack-members-sha256 HEX                          # external trust anchors from the published sidecar
    --json results.json
```

The validator reads only members of the pack it is given. It opens no path under `/home`, no repository, no Git, no unshipped
predecessor and no scratch directory, and imports no author/generator code. The copy that ships in the ZIP is the file you run and
is hashed in `PACK_MEMBERS.json`. Without the external anchors the result states that the inventory is only self-consistent.
VM/environment checks (Git state, workspace inventories) are **not** part of a package validator: they are reported as
`NOT_APPLICABLE_IN_PACKAGE` and never counted as a pass.

## The one active load, and what is NOT loaded

| Object | Count | Where |
|---|---:|---|
| **Active load** `foundation_rows_398.json` | **398 rows in 40 families** | package root - the only loadable row set |
| retained source rows | 123 | 121 unchanged + 2 history (show-config version 1; the historical direction artifact) |
| fresh rows (literal v4 UUIDs from the frozen table) | 275 | 274 replacements + 1 new show-config version |
| Artifact rows in the load | 36 | **35 current conforming path + 1 retained historical direction artifact** (`d1250005-0000-4000-8000-000000000012`) |
| Archive-only I2A source rows (composed correspondence) | 273 | replaced or archived; never loaded |
| Accepted I2B v2 rows replaced or archived | 283 | `archive/V2_ARCHIVED_283.json` - never loaded |
| Original I2A source rows | 396 | `archive/i2a_source/foundation_rows.json` - archival input, never loaded |
| Distinct archival union (I2A 396 + v2 fresh 95) | 491 | an accounting figure, not a load; with the 283 proposals it is 774; 376 stay outside the load |

The 396-row source, the accepted 406-row v2 load (not shipped; its rows are archived) and the 398-row successor must never be co-loaded; the validator fails a pack with a second loadable row set outside
the declared archival roles. The accepted v2 and the successor cannot even coexist in one database (`artifacts` is unique on type + content hash, and a run's configuration binding is immutable).
`provenance/uuid_correspondence_composed_330.tsv` is frozen evidence of how identities were composed (I2A -> accepted v2 -> successor) - **not a runtime alias resolver**. Every primary key in the load is its literal Foundation UUID.

## How references resolve (no bookkeeping change was needed)

* `storage_uri` of every artifact row is a literal member name of this pack, carried exactly as accepted. Audio artifacts point at
  `fixture_audio/*.wav`; JSON artifacts point at a member whose content **is** the canonical payload.
* Two members are shared containers (`prompt_payloads.json`, five complete prompt manifests; `support_payloads.json`, the tenor and
  continuity carriers). Their payload is located by the literal `artifact_id` inside the container. `byte_size` stays `null` for the 24 JSON artifact rows exactly as accepted.
* Each complete prompt manifest's `rendered_request_ref` is `{member: "fixture_model_requests.json", specimen_key, bytes_status}`;
  the member is the five exact UTF-8 request specimens, byte-for-byte, and the raw SHA-256 of each equals the typed `rendered_request_hash`.
* `ARTIFACT_INVENTORY.json` lists each artifact's member/container resolution; `PACK_MEMBERS.json` lists every member with bytes,
  SHA-256, mode, role and who references it; `SOURCE_PROVENANCE.json` accounts for every member's source (or generator).

## Layout

| Path | Role |
|---|---|
| `foundation_rows_398.json` | the one active load |
| artifact payload members (`showrunner_brief.json`, `script_pass*.json`, `performance_direction*.json`, ...) | one member per `storage_uri` |
| `fixture_audio/*.wav`, `fixture_model_requests.json` | 12 WAVs (byte-identical to predecessor v0.4.4); five request specimens |
| `render_request_projections.json`, `fixture_persistence_conformance.json`, `gate_fingerprint_inputs.json` | nine TTS base projections; ten literal request-to-response entries (closed mapping); six stage projections |
| `ready_expectations.json`, `persistence_expectations.json`, `scenarios.json`, `config/*` | expectations, isolated scenarios, configuration (version 2 current; version 1 history) |
| `model_semantic_input_conformance.json`, `unicode_conformance.json` | the 24 original model vectors and the Unicode vectors, carried byte-for-byte |
| `prompt_manifest_conformance.json`, `base_request_hash_conformance.json`, `claim_event_conformance.json` | executable vectors |
| `conformance_index.json`, `conformance_cases.py`, `validate_fixture.py` | obligation matrix; executable cases; final validator |
| `archive/`, `provenance/`, `authority/` | archival inputs; frozen records (v1 history, v2 current; archived mode 0444), identity tables, provenance; exact bytes of the owning prospective specs |

## Configuration is prospective, not the active map

`config/policy_versions.json` binds each prospective policy version to the exact source bytes (shipped under `authority/`). It is
deliberately not the active v1.2.4 map (launch-policy-set-v3); the validator fails any obsolete active-profile version or hash and
any prompt-manifest policy hash that is not the raw SHA-256 of the shipped source file.

## Programming configuration

`config/block_types.json`, `config/episode_modes.json`, `config/rundown_template_post_event_launch_v2.json`, `config/participant_profiles.json` and
`config/enum_registries.json` are the **unchanged preserved predecessor bytes** (raw SHA-256 pinned in the validator). Group G31 checks that the selections - template/version and mode, slot fill,
block types, participants, runtime configuration and the preserved closed enums - resolve uniquely and compatibly against those shipped files, for the **current configuration version**
(the single version bound by every loaded attempt). G32 checks the nine authored budgets (30,30,30,60,30,60,30,30,30 s = 330 s) against that configuration's band [60, 330] with the only governed tolerance (0) and never reads
the 240 s target. G34 checks the configuration lineage: version chain and parentage, single-key payload diff, hash recomputation, old row immutability, fresh runs/attempts bound to the new configuration only, and READY/revalidation propagation.
The predecessor `voice_profile_versions.json` is shipped only as evidence; the literal Foundation voice rows in the load are the render authority. The Character Bible v0.1.4 is shipped as a **supporting** source, bound by no prompt manifest.

## Two kinds of manifest test, kept apart

Hash-function sensitivity vectors (`prompt_manifest_conformance.json`, group G26) prove what each field and nested leaf does to
`prompt-manifest-artifact-v1` and to the unchanged three-field `model-semantic-input-v1`. Valid-fixture acceptance (group G25) checks
the five actual manifests: unique artifact bindings, typed equality, ordered inputs/exposure, truthful specimen availability, no
rights-bearing excerpt, no hidden output provenance, complete retention.

## Judgments that are recorded, not computed

`provenance/FIXTURE_AUDIT_REPORT.json` and the predecessor vectors classified `recorded_model_eval` are recorded judgments of a
synthetic auditor / the executing model; they are listed, never counted as deterministic passes, and no human override is represented.

## Deferred (not claimed)

Migration 002 and its concurrency/retry enforcement, live-provider fidelity, audible performance, the repeated-manifest cached-take runtime gap (`provenance/DEFERRED_RUNTIME_GAP.md`), publication, and activation of any specification remain out of scope.
