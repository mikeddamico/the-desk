# The Desk - Frozen Walking-Skeleton Fixture v0.4.1

**Status:** ACTIVE EXECUTABLE CONTRACT FOR BUILD 1-2  
**Date:** September 27, 2026  
**Supersedes:** v0.4

This corrective fixture closes the implementation blockers found in the independent Codex and Claude dry runs without reopening Technical Architecture v1.0.

Key corrections:

- valid evidence-axis enums with `origin` kept separate from `source_role`;
- all nine required `post-event-launch-v2` slots represented in the Brief;
- required-attribution claims attributed on every spoken use;
- valid RFC 3339 timestamps and complete immutable repair request/plan/decision shapes;
- stage-specific gate fingerprints instead of binding SCRIPTED gates to later Performance Direction;
- explicit Unicode code-point span vectors;
- deterministic fixture TTS bytes and a materialized clean master;
- separate evaluation and production-purpose/publication-disabled review paths;
- a real READY candidate, Episode/GUID, durable review wait, and fixture revalidation result;
- confirmed READY repairs fork child attempts;
- one named mechanical reroll with durable trigger;
- `provider_calls` as the authoritative external-call/cost ledger;
- minimum fixture-grade claims/evidence/support/model/account records;
- writer payload no longer carries forbidden claim/evidence IDs.

Current canonical identities:

- Evidence Package: `22fa7218e2f820b3c3378fc083eae52d1a0b0259c43fcf555f9115afed4d0457`
- Showrunner Brief: `858e3029d17e490dd8b34f21905f21bf6e5b0daa508a44964097c8030ed6042c`
- Writer view: `27f397746133d7a3a8a32e613350a2d71231fefbc56a201a99ad8cd6f0d511d4`
- Pass 1: `2c28691be4a16c0bd5939459e1a31f783d35ddd860bad4713a514d0df8ec86fd`
- Craft review: `87fdfb0f4e8e4cd693cc4d4c10fd936694914400d3f2bd6d8e639011f3687717`
- Craft revision: `9f28c3618a792467637a70dad312738f64337d09332341c20a8339cc99168076`
- Final speech-texture script: `d6fca2178d65139b935157e28b1af01426ba9a00bbe7304824e5ac7a8125a830`
- Performance Direction: `2e613ae6c99851cad12171347cb11616dd2bbecb7e4e2083ac2dfb0aa0b6a454`
- Claims/Writing gate fingerprint: `ee3aed41605c846266d8df68e50fc769d3a3e99cc4df55cc7cb35943004f26a2`
- Performance gate fingerprint: `b026ed0655ce2cb92044baa0d653ebaf4b787f66704ca7a1954d3e040426097e`
- Semantic audit input fingerprint: `de4e027bd6d8599ecc047745023fe2545e0fcbdaace645528f7d99902f338657`
- Render Manifest: `a018bfd689e78041edd60795ed2131bdc0eeb8abfd9ae065affef5d23ed21a76`
- Render gate fingerprint: `e554aabb143b9cf8552347b8f18087d17456d9b1cd09d4d683d02dc06b122029`
- Clean master SHA-256: `a7ecd855ef8a9100b4252fadfadf366efb866b72a060e9484f64002568354d73`
- Assembly gate fingerprint: `20007027829775977fc89473865e4ba83178b4d7165139cddf2039b5bbbf22d2`
- READY candidate fingerprint: `d5d5efb46008aeadf60ae9e5f0a2168b0115be21433012592eee465c5ad03a70`

The primary artifact-writing chain is still built under the evaluation attempt and stops at VALIDATED for lifecycle purposes. The production-purpose review attempt reuses the exact immutable content-addressed artifacts, obtains its own gate/review lineage, enters READY, and remains publication-disabled.

No file grants live-search authority. Fixture audio is synthetic test material, not a product voice.
